﻿<#
.SYNOPSIS
    XaoInstaller - Instalador de software de Software Basico para Windows 10 y 11.
    Descarga e instala programas esenciales limpios, desde las fuentes seleccionadas.
.AUTHOR
    Xaoxay Labs
#>

# BEGIN XAO COMMON
# Xao shared runtime (embedded in every standalone script).
function Invoke-XaoNative {
    param([string]$FilePath,[string[]]$ArgumentList=@(),[int[]]$SuccessCodes=@(0),[switch]$CaptureOutput)
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $exe=Get-Command $FilePath -CommandType Application -ErrorAction Stop | Select-Object -First 1
    & $exe.Source @ArgumentList | ForEach-Object {
        if($CaptureOutput){Write-Output $_}
        elseif($XaoQueue){$XaoQueue.Enqueue([pscustomobject]@{Message=[string]$_;Type='INFO'})}
        else{Write-Host $_;Write-XaoLogRecord -Path $LogFile -Message ([string]$_)}
    }
    $code=$LASTEXITCODE
    if($code -notin $SuccessCodes){throw "$FilePath termino con codigo $code. Consulte la salida y el registro."}
    if($code -eq 3010){Write-Warning 'La operacion requiere reiniciar Windows.'}
    Test-XaoCancellation

    }
}

function Set-XaoRegistryValue {
    [CmdletBinding()]
    param([string]$Path,[string]$Name,$Value,[string]$Type,[switch]$Force)
    Invoke-XaoExclusive {
        $journal=Save-XaoRegistryValue -Path $Path -Name $Name
        if(-not $script:XaoBackupNoticeShown){$script:XaoBackupNoticeShown=$true;Write-Information "Copia de valores de registro: $journal" -InformationAction Continue}
        if(-not (Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force -ErrorAction Stop | Out-Null}
        if($Type){New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null}
        else{Set-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -Force -ErrorAction Stop}
    }
}

function Enable-XaoUltimatePower {
    Invoke-XaoExclusive {

    $template = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
    $target = '64b4b650-61fc-4a85-97c0-cb043335517e'
    $plans = (Invoke-XaoNative powercfg @('/list') -CaptureOutput) -join "`n"
    if ($plans -notmatch $target) { Invoke-XaoNative powercfg @('/duplicatescheme', $template, $target) | Out-Null }
    Invoke-XaoNative powercfg @('/setactive', $target) | Out-Null
    $active = (Invoke-XaoNative powercfg @('/getactivescheme') -CaptureOutput) -join "`n"
    if ($active -notmatch $target) { throw 'Windows no activo el plan solicitado. El equipo puede no admitirlo.' }

    }
}

function Reset-XaoWindowsUpdate {
    Invoke-XaoExclusive {

    $services = @('bits','wuauserv','cryptsvc')
    $running = @()
    $failures = [Collections.Generic.List[string]]::new()
    try {
        foreach ($name in $services) {
            $svc = Get-Service $name -ErrorAction Stop
            if ($svc.Status -ne 'Stopped') {
                $running += $name
                Stop-Service $name -Force -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
            }
        }
        foreach ($path in @("$env:SystemRoot\SoftwareDistribution", "$env:SystemRoot\System32\catroot2")) {
            if (Test-Path -LiteralPath $path) {
                $leaf = (Split-Path $path -Leaf) + '.xao-backup-' + [guid]::NewGuid().ToString('N')
                Rename-Item -LiteralPath $path -NewName $leaf -ErrorAction Stop
            }
        }
    } catch { $failures.Add($_.Exception.Message) }
    finally {
        foreach ($name in $running) {
            try {
                Start-Service $name -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
            } catch { $failures.Add("No se pudo restablecer ${name}: $($_.Exception.Message)") }
        }
    }
    if ($failures.Count) { throw ($failures -join ' | ') }

    }
}

function Reset-XaoPrintQueue {
    Invoke-XaoExclusive {

    $svc = Get-Service Spooler -ErrorAction Stop
    $wasRunning = $svc.Status -eq 'Running'
    try {
        Stop-Service Spooler -Force -ErrorAction Stop
        (Get-Service Spooler).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
        $folder = Join-Path $env:SystemRoot 'System32\spool\PRINTERS'
        # Only pending spool files, never recursively delete a computed directory.
        Get-ChildItem -LiteralPath $folder -File -Force -ErrorAction Stop |
            Where-Object { $_.Extension -in @('.SPL','.SHD') } |
            Remove-Item -Force -ErrorAction Stop
    } finally { if ($wasRunning) { Start-Service Spooler -ErrorAction Stop } }

    }
}

function Clear-XaoTemp {
    param([string[]]$Roots = @($env:TEMP, "$env:SystemRoot\Temp"), [int]$MinimumAgeDays = 7)
    Invoke-XaoExclusive {

    $bytes = 0L; $removed = 0; $skipped = 0
    $cutoff = (Get-Date).AddDays(-[Math]::Max(1, $MinimumAgeDays))
    foreach ($root in ($Roots | Select-Object -Unique)) {
        Test-XaoCancellation
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'Ruta temporal vacia.' }
        $full = [IO.Path]::GetFullPath($root).TrimEnd('\')
        if ($full -eq [IO.Path]::GetPathRoot($full).TrimEnd('\') -or $full -in @($env:USERPROFILE,$env:SystemRoot,$env:ProgramFiles)) {
            throw "Se rechazo una ruta de limpieza demasiado amplia: $full"
        }
        if (-not (Test-Path -LiteralPath $full)) { continue }
        $pending = [Collections.Generic.Stack[string]]::new()
        $pending.Push($full)
        while ($pending.Count) {
            Test-XaoCancellation
            $directory = $pending.Pop()
            try {
                $info = Get-Item -LiteralPath $directory -Force -ErrorAction Stop
                if ($info.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                foreach ($item in Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop) {
                    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                    if ($item.PSIsContainer) { $pending.Push($item.FullName); continue }
                    if ($item.LastWriteTime -ge $cutoff) { continue }
                    try {
                        $length = $item.Length
                        Remove-Item -LiteralPath $item.FullName -Force -ErrorAction Stop
                        $bytes += $length; $removed++
                    } catch { $skipped++ }
                }
            } catch { $skipped++ }
        }
    }
    [pscustomobject]@{ Removed=$removed; Skipped=$skipped; Bytes=$bytes }

    }
}

function Get-XaoRustDeskAsset {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod 'https://api.github.com/repos/rustdesk/rustdesk/releases/latest' -Headers @{'User-Agent'='XaoTools'} -TimeoutSec 30 -ErrorAction Stop
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'aarch64' } elseif ([Environment]::Is64BitOperatingSystem) { 'x86_64' } else { throw 'RustDesk: esta version requiere Windows de 64 bits.' }
    $asset = @($release.assets | Where-Object { $_.name -match "^rustdesk-[0-9.]+-$arch\.msi$" })
    if ($asset.Count -ne 1 -or $asset[0].digest -notmatch '^sha256:[a-fA-F0-9]{64}$') { throw 'No hay un instalador RustDesk con SHA-256 verificable para este equipo.' }
    if ($asset[0].browser_download_url -notmatch '^https://github\.com/rustdesk/rustdesk/releases/download/') { throw 'Origen de RustDesk inesperado.' }
    $asset[0]
}

function Install-XaoRustDesk {
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $asset = Get-XaoRustDeskAsset
    $folder = Join-Path $env:TEMP ('XaoRustDesk-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null
    $file = Join-Path $folder $asset.name
    try {
        Invoke-WebRequest $asset.browser_download_url -OutFile $file -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($hash -ne ($asset.digest -replace '^sha256:','')) { throw 'SHA-256 de RustDesk incorrecto. Se cancelo la instalacion.' }
        $signature=Get-AuthenticodeSignature -LiteralPath $file -ErrorAction Stop
        if($signature.Status -ne 'Valid'){throw "La firma digital de RustDesk no es valida ($($signature.Status)). No se ejecutara el instalador."}
        Test-XaoCancellation
        $msiLog = Join-Path $env:TEMP ('XaoRustDesk-' + (Get-Date -Format yyyyMMddHHmmss) + '.log')
        $process = Start-Process msiexec.exe -ArgumentList "/i `"$file`" /qn /norestart /L*v `"$msiLog`"" -Wait -PassThru -WindowStyle Hidden -ErrorAction Stop
        if ($process.ExitCode -notin @(0,3010)) { throw "RustDesk: MSI termino con codigo $($process.ExitCode). Registro: $msiLog" }
        [pscustomobject]@{ Status= $(if ($process.ExitCode -eq 3010) {'RebootRequired'} else {'Installed'}); Code=$process.ExitCode }
    } finally {
        if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue }
        # Non-recursive: never remove files outside this dedicated download folder.
        Remove-Item -LiteralPath $folder -ErrorAction SilentlyContinue
    }

    }
}

function Install-XaoPackage {
    param([string]$Id, [string]$Source = 'winget')
    Invoke-XaoExclusive {

    Test-XaoCancellation
    if ($Id -eq 'RustDesk.RustDesk') { return Install-XaoRustDesk }
    try { $exe = Get-Command winget.exe -CommandType Application -ErrorAction Stop }
    catch { throw 'Winget no esta disponible. Instale o actualice "Instalador de aplicaciones" desde Microsoft Store y vuelva a abrir la herramienta.' }
    $arguments = @('install','--id',$Id,'--exact','--source',$Source,'--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements')
    & $exe.Source @arguments | ForEach-Object { Write-Host $_ }
    $code = $LASTEXITCODE
    Test-XaoCancellation
    $status = switch ($code) {
        0 { 'Installed' }
        3010 { 'RebootRequired' }
        -1978335189 { 'NoUpdate' }
        -1978335135 { 'AlreadyInstalled' }
        default { throw "Winget no pudo instalar $Id (codigo $code). Revise la salida y los registros de Winget." }
    }
    [pscustomobject]@{ Status=$status; Code=$code }

    }
}

function Update-XaoPackages {
    Invoke-XaoExclusive {

    Invoke-XaoNative winget.exe @('upgrade','--all','--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements') -SuccessCodes @(0,3010,-1978335189)

    }
}


function Test-XaoCancellation {
    if ($XaoCancel -and $XaoCancel.IsCancellationRequested) {
        throw [OperationCanceledException]::new('Detenido entre pasos por solicitud del usuario. Los cambios ya realizados se conservan.')
    }
}

function Enter-XaoOperation {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $mutex = [Threading.Mutex]::new($false, "Local\XaoTools.Operations.$sid")
    try {
        try { $acquired = $mutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $acquired = $true }
        if (-not $acquired) { throw 'Otra herramienta Xao esta trabajando en esta sesion. Espere a que termine.' }
        return $mutex
    } catch { $mutex.Dispose(); throw }
}

function Invoke-XaoExclusive {
    param([scriptblock]$Action)
    Test-XaoCancellation
    $mutex = Enter-XaoOperation
    try { & $Action } finally { $mutex.ReleaseMutex(); $mutex.Dispose() }
}

function Initialize-XaoLog {
    param([string]$Tool)
    $folder = Join-Path $env:LOCALAPPDATA 'XaoTools\Logs'
    try { New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null }
    catch { $folder = [IO.Path]::GetTempPath() }
    $path = Join-Path $folder ("{0}-{1}-{2}.log" -f $Tool,(Get-Date -Format 'yyyyMMdd-HHmmss-fff'),$PID)
    try { [IO.File]::WriteAllText($path, "Xao v1.2 | $Tool | $(Get-Date -Format o)`r`n", [Text.UTF8Encoding]::new($false)) }
    catch { Write-Warning "No se pudo crear el registro: $($_.Exception.Message)"; return $null }
    return $path
}

function Write-XaoLogRecord {
    [CmdletBinding()]
    param([string]$Path,[string]$Message,[string]$Type='INFO')
    if (-not $Path) { return }
    try {
        # Console output is bounded in the GUI; the file keeps the complete record.
        $line = '[{0}] [{1}] {2}{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Type,$Message,[Environment]::NewLine
        [IO.File]::AppendAllText($Path,$line,[Text.UTF8Encoding]::new($false))
    } catch {
        # Logging must never recursively call itself or hide the original error.
        if (-not $script:XaoLogWarningShown) { $script:XaoLogWarningShown=$true; Write-Warning "Registro no disponible: $($_.Exception.Message)" }
    }
}

function Get-XaoSystemDisk {
    param([string]$DriveLetter = $env:SystemDrive.TrimEnd(':'))
    $type='Desconocido'; $name='No disponible'; $health='No disponible'
    try {
        $disk = Get-Partition -DriveLetter $DriveLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop | Select-Object -First 1
        if ($disk) {
            $name=$disk.FriendlyName; $health=[string]$disk.HealthStatus
            $physical = @(Get-PhysicalDisk -ErrorAction Stop | Where-Object {
                $_.UniqueId -and $disk.UniqueId -and $_.UniqueId.Trim() -eq $disk.UniqueId.Trim()
            })
            if ($physical.Count -eq 1 -and $physical[0].MediaType -in @('SSD','HDD','SCM')) { $type=[string]$physical[0].MediaType }
        }
    } catch { }
    [pscustomobject]@{ Drive=$DriveLetter+':'; Name=$name; MediaType=$type; HealthStatus=$health }
}

function Get-XaoRegistryJournalPath {
    if (-not $script:XaoRegistryJournal) {
        $folder=Join-Path $env:LOCALAPPDATA 'XaoTools\RegistryBackups'
        New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
        $script:XaoRegistryJournal=Join-Path $folder ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+[guid]::NewGuid().ToString('N')+'.jsonl')
    }
    return $script:XaoRegistryJournal
}

function Save-XaoRegistryValue {
    param([string]$Path,[string]$Name)
    $exists=$false; $kind=$null; $value=$null
    if (Test-Path -LiteralPath $Path) {
        $key=Get-Item -LiteralPath $Path -ErrorAction Stop
        if ($key.GetValueNames() -contains $Name) {
            $exists=$true
            $kind=$key.GetValueKind($Name).ToString()
            $value=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
    }
    $entry=[pscustomobject]@{ Version=1; Time=(Get-Date -Format o); Path=$Path; Name=$Name; Existed=$exists; Kind=$kind; Value=$value }
    $journal=Get-XaoRegistryJournalPath
    # Abort the mutation if its backup cannot be saved.
    [IO.File]::AppendAllText($journal,($entry | ConvertTo-Json -Compress -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
    return $journal
}

function Restore-XaoRegistryJournal {
    [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
    param([Parameter(Mandatory=$true)][string]$Path)
    $records=@(Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Where-Object { $_.Trim() } | ForEach-Object { $_ | ConvertFrom-Json -ErrorAction Stop })
    if (-not $records.Count) { throw 'La copia esta vacia.' }
    foreach ($record in $records) {
        if ($record.Version -ne 1 -or $record.Path -notmatch '^HK(CU|LM):\\' -or [string]::IsNullOrWhiteSpace($record.Name)) { throw 'Formato de copia no valido.' }
        if ($record.Existed -isnot [bool]) { throw 'Estado del valor no valido.' }
        if ($record.Existed -and $record.Kind -notin @('String','ExpandString','Binary','DWord','MultiString','QWord')) { throw 'Tipo de registro no admitido.' }
        if($record.Existed){
            $validated=switch($record.Kind){
                'Binary'{,([byte[]]$record.Value)}
                'MultiString'{,([string[]]$record.Value)}
                'DWord'{[int]$record.Value}
                'QWord'{[long]$record.Value}
                default{[string]$record.Value}
            }
            $record | Add-Member -NotePropertyName RestoredValue -NotePropertyValue $validated -Force
        }
    }
    if (-not $PSCmdlet.ShouldProcess($Path,'Restaurar los valores de registro guardados (no servicios ni archivos)')) { return }
    Invoke-XaoExclusive {
        for ($index=$records.Count-1; $index -ge 0; $index--) {
            $record=$records[$index]
            if ($record.Existed) {
                $value=$record.RestoredValue
                if (-not (Test-Path -LiteralPath $record.Path)) { New-Item -Path $record.Path -Force -ErrorAction Stop | Out-Null }
                New-ItemProperty -LiteralPath $record.Path -Name $record.Name -Value $value -PropertyType $record.Kind -Force -ErrorAction Stop | Out-Null
            } elseif (Test-Path -LiteralPath $record.Path) {
                $key=Get-Item -LiteralPath $record.Path -ErrorAction Stop
                if ($key.GetValueNames() -contains $record.Name) { Remove-ItemProperty -LiteralPath $record.Path -Name $record.Name -ErrorAction Stop }
            }
        }
    }
}

$script:XaoSharedFunctions = @('Invoke-XaoNative','Set-XaoRegistryValue','Enable-XaoUltimatePower','Reset-XaoWindowsUpdate','Reset-XaoPrintQueue','Clear-XaoTemp','Get-XaoRustDeskAsset','Install-XaoRustDesk','Install-XaoPackage','Update-XaoPackages','Test-XaoCancellation','Enter-XaoOperation','Invoke-XaoExclusive','Initialize-XaoLog','Write-XaoLogRecord','Get-XaoSystemDisk','Get-XaoRegistryJournalPath','Save-XaoRegistryValue','Restore-XaoRegistryJournal')
# END XAO COMMON

$ErrorActionPreference = "Stop"

# Asegurar codificacion UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Xao Installer v1.2 - Software Basico & Utilidades (Windows 10 / 11)"

# Configuracion de Logs
$LogFile = Initialize-XaoLog 'XaoInstaller'

function Write-Log {
    param([string]$Message,[string]$Type='INFO')
    Write-XaoLogRecord -Path $LogFile -Message $Message -Type $Type
    $color=switch($Type){'ERROR'{'Red'} 'WARNING'{'Yellow'} 'SUCCESS'{'Green'} 'HEADER'{'Cyan'} default{'Gray'}}
    Write-Host "[$Type] $Message" -ForegroundColor $color
}

function Disable-ConsoleQuickEdit {
    try {
        $signature = @'
[DllImport("kernel32.dll", SetLastError = true)]
public static extern IntPtr GetStdHandle(int nStdHandle);
[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
'@
        $type = Add-Type -MemberDefinition $signature -Name "Win32ConsoleHelperInstaller" -Namespace "XaoInstaller" -PassThru -ErrorAction SilentlyContinue
        if ($type) {
            $hStdIn = $type[0]::GetStdHandle(-10) # STD_INPUT_HANDLE = -10
            $mode = [uint32]0
            if ($type[0]::GetConsoleMode($hStdIn, [ref]$mode)) {
                $ENABLE_QUICK_EDIT_MODE = 0x004[uint32]0
                $newMode = $mode -band (-bnot $ENABLE_QUICK_EDIT_MODE)
                [void]$type[0]::SetConsoleMode($hStdIn, $newMode)
            }
        }
    } catch {
        # Si falla en alguna version especifica no interrumpe el script
    }
}

function Ensure-AdminPrivileges {
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        Write-Host "`n [!] Se requieren permisos de Administrador para instalar software en el sistema." -ForegroundColor Yellow
        Write-Host " [*] Solicitando elevacion automatica..." -ForegroundColor Cyan
        try {
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = "powershell.exe"
            $processInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            $processInfo.Verb = "runas"
            [System.Diagnostics.Process]::Start($processInfo) | Out-Null
            exit
        } catch {
            Write-Host " [ERROR] No se pudo obtener permisos de Administrador. Ejecute PowerShell como Administrador." -ForegroundColor Red
            Pause-Prompt
            exit
        }
    }
}

function Test-InternetConnection {
    try {
        $request = [Net.WebRequest]::Create('https://www.microsoft.com/')
        $request.Method = 'HEAD'; $request.Timeout = 4000
        $response = $request.GetResponse(); $response.Close()
        return $true
    } catch { return $false }
}

function Test-WingetAvailable {
    $cmd = Get-Command winget -ErrorAction SilentlyContinue
    return ($cmd -ne $null)
}

function Pause-Prompt {
    Write-Host "`n Presione [ENTER] para continuar..." -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}

function Install-SingleWingetApp {
    param([string]$AppId,[string]$AppName,[string]$Source='winget')
    try {
        Write-Log "Instalando $AppName..." 'INFO'
        $result = Install-XaoPackage -Id $AppId -Source $Source
        if ($result.Status -eq 'RebootRequired') { Write-Log "$AppName instalado; requiere reiniciar." 'WARNING' }
        elseif ($result.Status -in @('NoUpdate','AlreadyInstalled')) { Write-Log "$AppName ya esta instalado; no se aplicaron cambios." 'INFO' }
        else { Write-Log "$AppName instalado correctamente." 'SUCCESS' }
        return $true
    } catch { Write-Log "Fallo en ${AppName}: $($_.Exception.Message)" 'ERROR'; return $false }
}

function Install-AppBatch {
    param([array]$AppList)
    $ok=0; $failed=0
    foreach ($app in $AppList) {
        $source = if ($app.Source) { $app.Source } else { 'winget' }
        if (Install-SingleWingetApp -AppId $app.Id -AppName $app.Name -Source $source) { $ok++ } else { $failed++ }
    }
    $type = if ($failed) { 'WARNING' } else { 'SUCCESS' }
    Write-Log "Lote terminado: $ok correctos o ya instalados; $failed fallidos." $type
    Pause-Prompt
}

# -------------------------------------------------------------
# DEFINICION DEL CATALOGO DE PROGRAMAS
# -------------------------------------------------------------
$Catalog = @{
    # PACK BASICO ESENCIAL
    "PackBasico" = @(
        @{ Id = "Google.Chrome"; Name = "Google Chrome (Navegador rapido y seguro)"; Source = "winget" },
        @{ Id = "7zip.7zip"; Name = "7-Zip (Descompresor de archivos .zip y .rar)"; Source = "winget" },
        @{ Id = "VideoLAN.VLC"; Name = "VLC Media Player (Reproductor de musica y video)"; Source = "winget" },
        @{ Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader (Lector oficial de archivos PDF)"; Source = "winget" }
    );

    # NAVEGADORES
    "Navegadores" = @(
        @{ Key = "1"; Id = "Google.Chrome"; Name = "Google Chrome" },
        @{ Key = "2"; Id = "Mozilla.Firefox"; Name = "Mozilla Firefox (Enfocado en privacidad)" },
        @{ Key = "3"; Id = "Brave.Brave"; Name = "Brave Browser (Bloqueador nativo de publicidad)" },
        @{ Key = "4"; Id = "Opera.Opera"; Name = "Opera One" }
    );

    # COMPRESORES
    "Compresores" = @(
        @{ Key = "1"; Id = "7zip.7zip"; Name = "7-Zip (Gratuito, super liviano y rapido)" },
        @{ Key = "2"; Id = "RARLab.WinRAR"; Name = "WinRAR (Clasico descompresor de archivos)" }
    );

    # MULTIMEDIA
    "Multimedia" = @(
        @{ Key = "1"; Id = "VideoLAN.VLC"; Name = "VLC Media Player (Reproduce cualquier formato de video)" },
        @{ Key = "2"; Id = "9NCBCSZSJRSB"; Source = "msstore"; Name = "Spotify (Musica y podcasts)" },
        @{ Key = "3"; Id = "CodecGuide.K-LiteCodecPack.Standard"; Name = "K-Lite Codec Pack (Codecs para Windows)" }
    );

    # OFIMATICA Y LECTURA
    "Ofimatica" = @(
        @{ Key = "1"; Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader (Visualizador de documentos PDF)" },
        @{ Key = "2"; Id = "TheDocumentFoundation.LibreOffice"; Name = "LibreOffice (Word, Excel y PowerPoint gratis)" }
    );

    # COMUNICACION
    "Comunicacion" = @(
        @{ Key = "1"; Id = "Discord.Discord"; Name = "Discord (Comunidades, voz y chat)" },
        @{ Key = "2"; Id = "Telegram.TelegramDesktop"; Name = "Telegram Desktop (Mensajeria rapida y segura)" },
        @{ Key = "3"; Id = "9NKSQGP7F2NH"; Name = "WhatsApp Desktop (Oficial de Microsoft Store)"; Source = "msstore" },
        @{ Key = "4"; Id = "Zoom.Zoom"; Name = "Zoom Workplace (Reuniones y videollamadas)" }
    );

    # SOPORTE REMOTO
    "Soporte" = @(
        @{ Key = "1"; Id = "AnyDesk.AnyDesk"; Name = "AnyDesk (Conexion remota ligera y rapida)" },
        @{ Key = "2"; Id = "RustDesk.RustDesk"; Name = "RustDesk (Acceso remoto de codigo abierto)" }
    );

    # GAMING Y UTILIDADES
    "Gaming" = @(
        @{ Key = "1"; Id = "Valve.Steam"; Name = "Steam (Tienda y plataforma de videojuegos de PC)" },
        @{ Key = "2"; Id = "Notepad++.Notepad++"; Name = "Notepad++ (Editor de texto rapido y avanzado)" }
    )
}

function Show-CategoryMenu {
    param(
        [string]$Title,
        [array]$Items
    )

    do {
        Clear-Host
        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host "                      $Title                      " -ForegroundColor Yellow
        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host " Ingrese el numero del programa que desea instalar:`n" -ForegroundColor Gray

        foreach ($it in $Items) {
            Write-Host "  [$($it.Key)] $($it.Name)" -ForegroundColor White
        }
        Write-Host ""
        Write-Host "  [T] Instalar TODOS los programas de esta lista" -ForegroundColor Green
        Write-Host "  [0] Volver al menu principal" -ForegroundColor DarkGray
        Write-Host "================================================================================" -ForegroundColor Cyan

        $sel = (Read-Host " Ingrese una opcion").Trim().ToUpper()

        if ($sel -eq "0") {
            break
        } elseif ($sel -eq "T") {
            Install-AppBatch -AppList $Items
            break
        } else {
            $found = $Items | Where-Object { $_.Key -eq $sel }
            if ($found) {
                $src = if ($found.Source) { $found.Source } else { "winget" }
                [void](Install-SingleWingetApp -AppId $found.Id -AppName $found.Name -Source $src)
                Pause-Prompt
                break
            } else {
                Write-Host " Opcion no valida. Intente de nuevo." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

function Show-InstallerBanner {
    Clear-Host
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host "                XAO INSTALLER - PACK DE SOFTWARE BASICO & UTILIDADES            " -ForegroundColor Yellow
    Write-Host "                                   Xaoxay Labs                                  " -ForegroundColor DarkCyan
    Write-Host "================================================================================" -ForegroundColor Cyan

    if(-not $script:XaoConnectivityChecked -or ((Get-Date)-$script:XaoConnectivityChecked).TotalSeconds -gt 60){
        $script:XaoOnline=Test-InternetConnection
        $script:XaoConnectivityChecked=Get-Date
    }
    $online = $script:XaoOnline
    $netStatus = if ($online) { "Conectado a Internet (OK)" } else { "No se pudo verificar HTTPS (revise proxy/firewall/conexion)" }
    $netColor = if ($online) { "Green" } else { "Red" }

    Write-Host " Equipo: " -NoNewline -ForegroundColor Gray
    Write-Host "$env:COMPUTERNAME " -NoNewline -ForegroundColor White
    Write-Host "[$netStatus]" -ForegroundColor $netColor

    $wg = Test-WingetAvailable
    if (-not $wg) {
        Write-Host " [ALERTA] No se detecto 'winget' en este sistema. Revisa la opcion [W] para habilitarlo." -ForegroundColor Red
    }

    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host " [1] INSTALAR PACK BASICO ESENCIAL (Todo en 1 clic)" -ForegroundColor Green
    Write-Host "     -> Chrome + 7-Zip + VLC Media Player + Adobe Acrobat Reader" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " [2] Navegadores Web (Chrome, Firefox, Brave, Opera)" -ForegroundColor White
    Write-Host " [3] Compresores de Archivos (7-Zip, WinRAR)" -ForegroundColor White
    Write-Host " [4] Multimedia y Entretenimiento (VLC, Spotify, Codecs)" -ForegroundColor White
    Write-Host " [5] Ofimatica y Lectura de Documentos (Adobe PDF, LibreOffice)" -ForegroundColor White
    Write-Host " [6] Comunicacion y Llamadas (Discord, Telegram, WhatsApp, Zoom)" -ForegroundColor White
    Write-Host " [7] Soporte Remoto Tecnico (AnyDesk, RustDesk)" -ForegroundColor White
    Write-Host " [8] Gaming y Utilidades (Steam, Notepad++)" -ForegroundColor White
    Write-Host "--------------------------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host " [U] ACTUALIZAR TODOS LOS PROGRAMAS DE TU PC EN 1 CLIC" -ForegroundColor Yellow
    Write-Host " [L] Ver lista de programas de tu PC con actualizaciones pendientes" -ForegroundColor DarkYellow
    Write-Host " [W] Informacion y solucion si 'winget' no esta instalado" -ForegroundColor DarkGray
    Write-Host " [R] Abrir registro de esta sesion" -ForegroundColor Gray
    Write-Host " [0] Salir" -ForegroundColor Red
    Write-Host "================================================================================" -ForegroundColor Cyan
}

# --- INICIO DEL SCRIPT ---
# Winget solicita elevacion cuando el instalador la necesita.
Disable-ConsoleQuickEdit

do {
    Show-InstallerBanner
    $op = (Read-Host " Ingrese una opcion (0-8, U, L, W)").Trim().ToUpper()

    try {
    switch ($op) {
        "0" { }
        "R" { if($LogFile){Start-Process notepad.exe -ArgumentList "`"$LogFile`""} }
        default { Write-Host "Opcion no valida." -ForegroundColor Yellow; Start-Sleep -Milliseconds 500 }
        "1" {
            # PACK BASICO ESENCIAL
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Green
            Write-Host "                     INSTALANDO PACK BASICO ESENCIAL (1-CLIC)                   " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Green
            Write-Host " Se van a instalar de forma limpia y oficial:`n"
            Write-Host "  1. Google Chrome (Navegador Web)" -ForegroundColor Cyan
            Write-Host "  2. 7-Zip (Descompresor de archivos)" -ForegroundColor Cyan
            Write-Host "  3. VLC Media Player (Reproductor de musica y video)" -ForegroundColor Cyan
            Write-Host "  4. Adobe Acrobat Reader (Lector de PDF oficial)" -ForegroundColor Cyan
            Write-Host "`n Presione [ENTER] para comenzar la instalacion automatica..." -ForegroundColor White
            [void][System.Console]::ReadLine()

            Install-AppBatch -AppList $Catalog["PackBasico"]
        }
        "2" {
            Show-CategoryMenu -Title "NAVEGADORES WEB" -Items $Catalog["Navegadores"]
        }
        "3" {
            Show-CategoryMenu -Title "COMPRESORES DE ARCHIVOS" -Items $Catalog["Compresores"]
        }
        "4" {
            Show-CategoryMenu -Title "MULTIMEDIA Y ENTRETENIMIENTO" -Items $Catalog["Multimedia"]
        }
        "5" {
            Show-CategoryMenu -Title "OFIMATICA Y LECTURA DE DOCUMENTOS" -Items $Catalog["Ofimatica"]
        }
        "6" {
            Show-CategoryMenu -Title "COMUNICACION Y LLAMADAS" -Items $Catalog["Comunicacion"]
        }
        "7" {
            Show-CategoryMenu -Title "SOPORTE REMOTO Y ASISTENCIA" -Items $Catalog["Soporte"]
        }
        "8" {
            Show-CategoryMenu -Title "GAMING Y UTILIDADES" -Items $Catalog["Gaming"]
        }
        "U" {
            # ACTUALIZAR TODO
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host "                 ACTUALIZANDO TODOS LOS PROGRAMAS DE TU COMPUTADORA             " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host " Windows buscara nuevas versiones de todos los programas instalados y los" -ForegroundColor Gray
            Write-Host " actualizara en silencio a la version mas reciente y segura.`n" -ForegroundColor Gray

            Update-XaoPackages
            Write-Host "`n================================================================================" -ForegroundColor Green
            Write-Log "Actualizacion general completada." -Type "SUCCESS"
            Pause-Prompt
        }
        "L" {
            # LISTAR ACTUALIZACIONES
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host "                 BUSCANDO ACTUALIZACIONES DISPONIBLES EN TU PC                  " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host " Consultando repositorio oficial de software...`n" -ForegroundColor Gray

            Invoke-XaoNative winget.exe @('upgrade','--accept-source-agreements','--disable-interactivity') -SuccessCodes @(0,-1978335189)
            Write-Host ""
            Pause-Prompt
        }
        "W" {
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Cyan
            Write-Host "                       ¿QUE ES 'WINGET' Y COMO SE HABILITA?                     " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Cyan
            Write-Host " 'winget' (Windows Package Manager) es la herramienta oficial de Microsoft que" -ForegroundColor White
            Write-Host " viene integrada en Windows 10 y Windows 11 para descargar programas oficiales" -ForegroundColor White
            Write-Host " directamente desde sus creadores, usando los manifiestos del catalogo seleccionado." -ForegroundColor White
            Write-Host "`n Si tu Windows es muy viejo y no lo tiene activo:" -ForegroundColor Yellow
            Write-Host " 1. Abre Microsoft Store en tu computadora." -ForegroundColor Gray
            Write-Host " 2. Busca 'Instalador de aplicaciones' (App Installer) de Microsoft." -ForegroundColor Gray
            Write-Host " 3. Presiona 'Actualizar' o 'Instalar'." -ForegroundColor Gray
            Write-Host " Al terminar, vuelve a abrir Xao Installer y funcionara inmediatamente." -ForegroundColor Green
            Pause-Prompt
        }
    }
    } catch { Write-Log $_.Exception.Message "ERROR"; Pause-Prompt }
} while ($op -ne "0")

Write-Host "`n Gracias por utilizar Xao Installer. ¡Hasta luego!`n" -ForegroundColor Green
Start-Sleep -Seconds 1
