﻿<# :
@echo off
setlocal EnableDelayedExpansion
title Xao Installer - Inicializando...

:: Comprobar permisos de Administrador
net session >nul 2>&1
if %errorlevel% NEQ 0 (
    echo.
    echo  [!] Solicitando permisos de Administrador para Xao Installer...
    echo.
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \"\"%~dpnx0\"\"' -Verb RunAs"
    exit /b
)

:: Cambiar al directorio del script
cd /d "%~dp0"

:: Ejecutar PowerShell incrustado con Bypass y codificacion UTF-8
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Expression ([System.IO.File]::ReadAllText('%~f0', [System.Text.Encoding]::UTF8))"

if %errorlevel% NEQ 0 (
    echo.
    echo  [!] La sesion de Xao Installer ha finalizado.
    pause
)
exit /b
#>
<#
.SYNOPSIS
    XaoInstaller - Instalador Oficial y Seguro de Software Basico para Windows 10 y 11.
    Descarga e instala programas esenciales limpios, sin publicidad ni barras no deseadas.
.AUTHOR
    Xaoxay Labs
#>

# Asegurar codificacion UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Xao Installer v1.0 - Software Basico & Utilidades (Windows 10 / 11)"

# Configuracion de Logs
$LogDir = Join-Path $env:TEMP "XaoInstaller_Logs"
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$LogFile = Join-Path $LogDir "XaoInstaller_$(Get-Date -Format 'yyyyMMdd').log"

function Write-Log {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,
        [ValidateSet("INFO", "SUCCESS", "WARNING", "ERROR", "HEADER")]
        [string]$Type = "INFO"
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] [$Type] $Message"
    Add-Content -Path $LogFile -Value $logLine -Encoding UTF8 -ErrorAction SilentlyContinue

    switch ($Type) {
        "INFO"    { Write-Host " [*] $Message" -ForegroundColor Gray }
        "SUCCESS" { Write-Host " [OK] $Message" -ForegroundColor Green }
        "WARNING" { Write-Host " [!] $Message" -ForegroundColor Yellow }
        "ERROR"   { Write-Host " [ERROR] $Message" -ForegroundColor Red }
        "HEADER"  {
            Write-Host "`n================================================================================" -ForegroundColor Cyan
            Write-Host " $Message" -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Cyan
        }
    }
}

function Disable-ConsoleQuickEdit {
    try {
        $signature = @'
[DllImport("kernel32.dll", SetLastError = true)]
public static extern IntPtr GetStdHandle(int nStdHandle);
[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
'@
        $type = Add-Type -MemberDefinition $signature -Name "Win32ConsoleHelperInstaller" -Namespace "XaoInstaller" -PassThru -ErrorAction SilentlyContinue
        if ($type) {
            $hStdIn = $type[0]::GetStdHandle(-10) # STD_INPUT_HANDLE = -10
            $mode = 0u
            if ($type[0]::GetConsoleMode($hStdIn, [ref]$mode)) {
                $ENABLE_QUICK_EDIT_MODE = 0x0040u
                $newMode = $mode -band (-bnot $ENABLE_QUICK_EDIT_MODE)
                [void]$type[0]::SetConsoleMode($hStdIn, $newMode)
            }
        }
    } catch {
        # Si falla en alguna version especifica no interrumpe el script
    }
}

function Ensure-AdminPrivileges {
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        Write-Host "`n [!] Se requieren permisos de Administrador para instalar software en el sistema." -ForegroundColor Yellow
        Write-Host " [*] Solicitando elevacion automatica..." -ForegroundColor Cyan
        try {
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = "powershell.exe"
            $processInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            $processInfo.Verb = "runas"
            [System.Diagnostics.Process]::Start($processInfo) | Out-Null
            exit
        } catch {
            Write-Host " [ERROR] No se pudo obtener permisos de Administrador. Ejecute PowerShell como Administrador." -ForegroundColor Red
            Pause-Prompt
            exit
        }
    }
}

function Test-InternetConnection {
    try {
        $ping = Test-Connection -ComputerName 1.1.1.1 -Count 1 -Quiet -ErrorAction SilentlyContinue
        return $ping
    } catch {
        return $false
    }
}

function Test-WingetAvailable {
    $cmd = Get-Command winget -ErrorAction SilentlyContinue
    return ($cmd -ne $null)
}

function Pause-Prompt {
    Write-Host "`n Presione [ENTER] para continuar..." -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}

function Install-SingleWingetApp {
    param(
        [string]$AppId,
        [string]$AppName,
        [string]$Source = "winget"
    )

    Write-Log "Iniciando instalacion de: $AppName" -Type "INFO"
    Write-Host "`n ----------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host " [*] Descargando e instalando $AppName de forma segura..." -ForegroundColor Cyan
    Write-Host "      Origen oficial: $Source | Identificador: $AppId" -ForegroundColor DarkGray
    Write-Host "      (Sin publicidad, sin barras de navegacion, sin malware)" -ForegroundColor DarkGray
    Write-Host " ----------------------------------------------------------------" -ForegroundColor DarkCyan

    $prevTitle = $Host.UI.RawUI.WindowTitle
    $Host.UI.RawUI.WindowTitle = "[Instalando: $AppName] - Xao Installer"

    $wingetArgs = @("install", "--id", $AppId, "--silent", "--accept-source-agreements", "--accept-package-agreements", "--force")
    if ($Source -ne "winget") {
        $wingetArgs += @("-s", $Source)
    }

    & winget @wingetArgs

    $code = $LASTEXITCODE
    $Host.UI.RawUI.WindowTitle = $prevTitle

    if ($code -eq 0) {
        Write-Log "$AppName se instalo con EXITO en tu equipo." -Type "SUCCESS"
    } elseif ($code -eq -1978335189 -or $code -eq 2316632107) {
        # Package already installed / up to date
        Write-Log "$AppName ya se encuentra instalado y actualizado." -Type "SUCCESS"
    } elseif ($code -eq 3010) {
        Write-Log "$AppName se instalo correctamente (requiere reiniciar el equipo para completar)." -Type "WARNING"
    } else {
        Write-Log "Aviso al procesar $AppName (Codigo de salida: $code). Es posible que ya exista o requiera abrir el programa para finalizar configuracion." -Type "WARNING"
    }
    Start-Sleep -Seconds 1
}

function Install-AppBatch {
    param(
        [array]$AppList
    )

    $total = $AppList.Count
    $idx = 1

    foreach ($app in $AppList) {
        Clear-Host
        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host "                 INSTALACION EN CURSO (Lote $idx de $total)                     " -ForegroundColor Yellow
        Write-Host "================================================================================" -ForegroundColor Cyan

        $source = if ($app.Source) { $app.Source } else { "winget" }
        Install-SingleWingetApp -AppId $app.Id -AppName $app.Name -Source $source
        $idx++
    }

    Write-Host "`n================================================================================" -ForegroundColor Green
    Write-Host " [OK] PROCESO DE INSTALACION FINALIZADO ($total programas procesados)" -ForegroundColor Green
    Write-Host "================================================================================" -ForegroundColor Green
    Pause-Prompt
}

# -------------------------------------------------------------
# DEFINICION DEL CATALOGO DE PROGRAMAS
# -------------------------------------------------------------
$Catalog = @{
    # PACK BASICO ESENCIAL
    "PackBasico" = @(
        @{ Id = "Google.Chrome"; Name = "Google Chrome (Navegador rapido y seguro)"; Source = "winget" },
        @{ Id = "7zip.7zip"; Name = "7-Zip (Descompresor de archivos .zip y .rar)"; Source = "winget" },
        @{ Id = "VideoLAN.VLC"; Name = "VLC Media Player (Reproductor de musica y video)"; Source = "winget" },
        @{ Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader (Lector oficial de archivos PDF)"; Source = "winget" }
    );

    # NAVEGADORES
    "Navegadores" = @(
        @{ Key = "1"; Id = "Google.Chrome"; Name = "Google Chrome" },
        @{ Key = "2"; Id = "Mozilla.Firefox"; Name = "Mozilla Firefox (Enfocado en privacidad)" },
        @{ Key = "3"; Id = "Brave.Brave"; Name = "Brave Browser (Bloqueador nativo de publicidad)" },
        @{ Key = "4"; Id = "Opera.Opera"; Name = "Opera One" }
    );

    # COMPRESORES
    "Compresores" = @(
        @{ Key = "1"; Id = "7zip.7zip"; Name = "7-Zip (Gratuito, super liviano y rapido)" },
        @{ Key = "2"; Id = "RARLab.WinRAR"; Name = "WinRAR (Clasico descompresor de archivos)" }
    );

    # MULTIMEDIA
    "Multimedia" = @(
        @{ Key = "1"; Id = "VideoLAN.VLC"; Name = "VLC Media Player (Reproduce cualquier formato de video)" },
        @{ Key = "2"; Id = "Spotify.Spotify"; Name = "Spotify (Musica y podcasts)" },
        @{ Key = "3"; Id = "CodecGuide.K-LiteCodecPack.Standard"; Name = "K-Lite Codec Pack (Codecs para Windows)" }
    );

    # OFIMATICA Y LECTURA
    "Ofimatica" = @(
        @{ Key = "1"; Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader (Visualizador de documentos PDF)" },
        @{ Key = "2"; Id = "TheDocumentFoundation.LibreOffice"; Name = "LibreOffice (Word, Excel y PowerPoint gratis)" }
    );

    # COMUNICACION
    "Comunicacion" = @(
        @{ Key = "1"; Id = "Discord.Discord"; Name = "Discord (Comunidades, voz y chat)" },
        @{ Key = "2"; Id = "Telegram.TelegramDesktop"; Name = "Telegram Desktop (Mensajeria rapida y segura)" },
        @{ Key = "3"; Id = "9NKSQGP7F2NH"; Name = "WhatsApp Desktop (Oficial de Microsoft Store)"; Source = "msstore" },
        @{ Key = "4"; Id = "Zoom.Zoom"; Name = "Zoom Workplace (Reuniones y videollamadas)" }
    );

    # SOPORTE REMOTO
    "Soporte" = @(
        @{ Key = "1"; Id = "AnyDesk.AnyDesk"; Name = "AnyDesk (Conexion remota ligera y rapida)" },
        @{ Key = "2"; Id = "RustDesk.RustDesk"; Name = "RustDesk (Acceso remoto de codigo abierto)" }
    );

    # GAMING Y UTILIDADES
    "Gaming" = @(
        @{ Key = "1"; Id = "Valve.Steam"; Name = "Steam (Tienda y plataforma de videojuegos de PC)" },
        @{ Key = "2"; Id = "Notepad++.Notepad++"; Name = "Notepad++ (Editor de texto rapido y avanzado)" }
    )
}

function Show-CategoryMenu {
    param(
        [string]$Title,
        [array]$Items
    )

    do {
        Clear-Host
        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host "                      $Title                      " -ForegroundColor Yellow
        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host " Ingrese el numero del programa que desea instalar:`n" -ForegroundColor Gray

        foreach ($it in $Items) {
            Write-Host "  [$($it.Key)] $($it.Name)" -ForegroundColor White
        }
        Write-Host ""
        Write-Host "  [T] Instalar TODOS los programas de esta lista" -ForegroundColor Green
        Write-Host "  [0] Volver al menu principal" -ForegroundColor DarkGray
        Write-Host "================================================================================" -ForegroundColor Cyan

        $sel = (Read-Host " Ingrese una opcion").Trim().ToUpper()

        if ($sel -eq "0") {
            break
        } elseif ($sel -eq "T") {
            Install-AppBatch -AppList $Items
            break
        } else {
            $found = $Items | Where-Object { $_.Key -eq $sel }
            if ($found) {
                $src = if ($found.Source) { $found.Source } else { "winget" }
                Install-SingleWingetApp -AppId $found.Id -AppName $found.Name -Source $src
                Pause-Prompt
                break
            } else {
                Write-Host " Opcion no valida. Intente de nuevo." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

function Show-InstallerBanner {
    Clear-Host
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host "                XAO INSTALLER - PACK DE SOFTWARE BASICO & UTILIDADES            " -ForegroundColor Yellow
    Write-Host "                                   Xaoxay Labs                                  " -ForegroundColor DarkCyan
    Write-Host "================================================================================" -ForegroundColor Cyan

    $online = Test-InternetConnection
    $netStatus = if ($online) { "Conectado a Internet (OK)" } else { "SIN CONEXION A INTERNET" }
    $netColor = if ($online) { "Green" } else { "Red" }

    Write-Host " Equipo: " -NoNewline -ForegroundColor Gray
    Write-Host "$env:COMPUTERNAME " -NoNewline -ForegroundColor White
    Write-Host "[$netStatus]" -ForegroundColor $netColor

    $wg = Test-WingetAvailable
    if (-not $wg) {
        Write-Host " [ALERTA] No se detecto 'winget' en este sistema. Revisa la opcion [W] para habilitarlo." -ForegroundColor Red
    }

    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host " [1] INSTALAR PACK BASICO ESENCIAL (Todo en 1 clic)" -ForegroundColor Green
    Write-Host "     -> Chrome + 7-Zip + VLC Media Player + Adobe Acrobat Reader" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host " [2] Navegadores Web (Chrome, Firefox, Brave, Opera)" -ForegroundColor White
    Write-Host " [3] Compresores de Archivos (7-Zip, WinRAR)" -ForegroundColor White
    Write-Host " [4] Multimedia y Entretenimiento (VLC, Spotify, Codecs)" -ForegroundColor White
    Write-Host " [5] Ofimatica y Lectura de Documentos (Adobe PDF, LibreOffice)" -ForegroundColor White
    Write-Host " [6] Comunicacion y Llamadas (Discord, Telegram, WhatsApp, Zoom)" -ForegroundColor White
    Write-Host " [7] Soporte Remoto Tecnico (AnyDesk, RustDesk)" -ForegroundColor White
    Write-Host " [8] Gaming y Utilidades (Steam, Notepad++)" -ForegroundColor White
    Write-Host "--------------------------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host " [U] ACTUALIZAR TODOS LOS PROGRAMAS DE TU PC EN 1 CLIC" -ForegroundColor Yellow
    Write-Host " [L] Ver lista de programas de tu PC con actualizaciones pendientes" -ForegroundColor DarkYellow
    Write-Host " [W] Informacion y solucion si 'winget' no esta instalado" -ForegroundColor DarkGray
    Write-Host " [0] Salir" -ForegroundColor Red
    Write-Host "================================================================================" -ForegroundColor Cyan
}

# --- INICIO DEL SCRIPT ---
Ensure-AdminPrivileges
Disable-ConsoleQuickEdit

do {
    Show-InstallerBanner
    $op = (Read-Host " Ingrese una opcion (0-8, U, L, W)").Trim().ToUpper()

    switch ($op) {
        "1" {
            # PACK BASICO ESENCIAL
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Green
            Write-Host "                     INSTALANDO PACK BASICO ESENCIAL (1-CLIC)                   " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Green
            Write-Host " Se van a instalar de forma limpia y oficial:`n"
            Write-Host "  1. Google Chrome (Navegador Web)" -ForegroundColor Cyan
            Write-Host "  2. 7-Zip (Descompresor de archivos)" -ForegroundColor Cyan
            Write-Host "  3. VLC Media Player (Reproductor de musica y video)" -ForegroundColor Cyan
            Write-Host "  4. Adobe Acrobat Reader (Lector de PDF oficial)" -ForegroundColor Cyan
            Write-Host "`n Presione [ENTER] para comenzar la instalacion automatica..." -ForegroundColor White
            [void][System.Console]::ReadLine()

            Install-AppBatch -AppList $Catalog["PackBasico"]
        }
        "2" {
            Show-CategoryMenu -Title "NAVEGADORES WEB" -Items $Catalog["Navegadores"]
        }
        "3" {
            Show-CategoryMenu -Title "COMPRESORES DE ARCHIVOS" -Items $Catalog["Compresores"]
        }
        "4" {
            Show-CategoryMenu -Title "MULTIMEDIA Y ENTRETENIMIENTO" -Items $Catalog["Multimedia"]
        }
        "5" {
            Show-CategoryMenu -Title "OFIMATICA Y LECTURA DE DOCUMENTOS" -Items $Catalog["Ofimatica"]
        }
        "6" {
            Show-CategoryMenu -Title "COMUNICACION Y LLAMADAS" -Items $Catalog["Comunicacion"]
        }
        "7" {
            Show-CategoryMenu -Title "SOPORTE REMOTO Y ASISTENCIA" -Items $Catalog["Soporte"]
        }
        "8" {
            Show-CategoryMenu -Title "GAMING Y UTILIDADES" -Items $Catalog["Gaming"]
        }
        "U" {
            # ACTUALIZAR TODO
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host "                 ACTUALIZANDO TODOS LOS PROGRAMAS DE TU COMPUTADORA             " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host " Windows buscara nuevas versiones de todos los programas instalados y los" -ForegroundColor Gray
            Write-Host " actualizara en silencio a la version mas reciente y segura.`n" -ForegroundColor Gray

            & winget upgrade --all --silent --accept-source-agreements --accept-package-agreements --force
            Write-Host "`n================================================================================" -ForegroundColor Green
            Write-Log "Actualizacion general completada." -Type "SUCCESS"
            Pause-Prompt
        }
        "L" {
            # LISTAR ACTUALIZACIONES
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host "                 BUSCANDO ACTUALIZACIONES DISPONIBLES EN TU PC                  " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Yellow
            Write-Host " Consultando repositorio oficial de software...`n" -ForegroundColor Gray

            & winget upgrade --accept-source-agreements
            Write-Host ""
            Pause-Prompt
        }
        "W" {
            Clear-Host
            Write-Host "================================================================================" -ForegroundColor Cyan
            Write-Host "                       ¿QUE ES 'WINGET' Y COMO SE HABILITA?                     " -ForegroundColor Yellow
            Write-Host "================================================================================" -ForegroundColor Cyan
            Write-Host " 'winget' (Windows Package Manager) es la herramienta oficial de Microsoft que" -ForegroundColor White
            Write-Host " viene integrada en Windows 10 y Windows 11 para descargar programas oficiales" -ForegroundColor White
            Write-Host " directamente desde sus creadores, garantizando que esten limpios de virus." -ForegroundColor White
            Write-Host "`n Si tu Windows es muy viejo y no lo tiene activo:" -ForegroundColor Yellow
            Write-Host " 1. Abre Microsoft Store en tu computadora." -ForegroundColor Gray
            Write-Host " 2. Busca 'Instalador de aplicaciones' (App Installer) de Microsoft." -ForegroundColor Gray
            Write-Host " 3. Presiona 'Actualizar' o 'Instalar'." -ForegroundColor Gray
            Write-Host " Al terminar, vuelve a abrir Xao Installer y funcionara inmediatamente." -ForegroundColor Green
            Pause-Prompt
        }
    }
} while ($op -ne "0")

Write-Host "`n Gracias por utilizar Xao Installer. ¡Hasta luego!`n" -ForegroundColor Green
Start-Sleep -Seconds 1
