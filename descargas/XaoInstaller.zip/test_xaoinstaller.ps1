﻿<#
.SYNOPSIS
    Suite de pruebas automatizadas para XaoInstaller
#>
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$scriptRoot = $PSScriptRoot
$ps1Path = Join-Path $scriptRoot "XaoInstaller.ps1"
$batPath = Join-Path $scriptRoot "XaoInstaller.bat"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "       SUITE DE PRUEBAS AUTOMATIZADAS: XAO INSTALLER      " -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan

$passed = 0
$failed = 0

function Assert-Test {
    param(
        [string]$Name,
        [scriptblock]$Condition
    )
    Write-Host -NoNewline " [*] Probando: $Name... "
    try {
        $result = & $Condition
        if ($result -eq $true) {
            Write-Host "[PASO]" -ForegroundColor Green
            $script:passed++
        } else {
            Write-Host "[FALLO]" -ForegroundColor Red
            $script:failed++
        }
    } catch {
        Write-Host "[ERROR]: $_" -ForegroundColor Red
        $script:failed++
    }
}

# 1. Test de Sintaxis de XaoInstaller.ps1
Assert-Test "Sintaxis de XaoInstaller.ps1" {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($ps1Path, [ref]$tokens, [ref]$errors)
    return ($errors.Count -eq 0)
}

# 2. Test de Sintaxis de XaoInstaller.bat
Assert-Test "Sintaxis de XaoInstaller.bat (Hibrido)" {
    $content = [System.IO.File]::ReadAllText($batPath, [System.Text.Encoding]::UTF8)
    $hasHeader = $content.StartsWith("<# :")
    $hasCloser = $content.Contains("exit /b %XAO_EXIT%`r`n#>") -or $content.Contains("exit /b %XAO_EXIT%`n#>")
    return ($hasHeader -and $hasCloser)
}

# Cargar funciones del script en memoria sin el bucle interactivo
$psCode = Get-Content -Path $ps1Path -Raw -Encoding UTF8
$functionBlock = $psCode.Substring(0, $psCode.IndexOf('# --- INICIO DEL SCRIPT ---'))
. ([scriptblock]::Create($functionBlock))

# 3. Test de Funciones Críticas
$expectedFunctions = @(
    "Write-Log",
    "Disable-ConsoleQuickEdit",
    "Ensure-AdminPrivileges",
    "Test-InternetConnection",
    "Test-WingetAvailable",
    "Install-SingleWingetApp",
    "Install-AppBatch",
    "Show-CategoryMenu",
    "Show-InstallerBanner"
)

foreach ($fn in $expectedFunctions) {
    Assert-Test "Existencia de funcion '$fn'" {
        return (Get-Command -Name $fn -ErrorAction SilentlyContinue) -ne $null
    }
}

# 4. Test de Estructura del Catalogo
Assert-Test "Consistencia del Catalogo de Aplicaciones" {
    $hasPackBasico = ($Catalog["PackBasico"] -ne $null -and $Catalog["PackBasico"].Count -eq 4)
    $hasNavegadores = ($Catalog["Navegadores"] -ne $null -and $Catalog["Navegadores"].Count -gt 0)
    $hasCompresores = ($Catalog["Compresores"] -ne $null -and $Catalog["Compresores"].Count -gt 0)
    $hasMultimedia = ($Catalog["Multimedia"] -ne $null -and $Catalog["Multimedia"].Count -gt 0)
    $hasOfimatica = ($Catalog["Ofimatica"] -ne $null -and $Catalog["Ofimatica"].Count -gt 0)
    return ($hasPackBasico -and $hasNavegadores -and $hasCompresores -and $hasMultimedia -and $hasOfimatica)
}

# 5. Test de Disponibilidad de Winget
Assert-Test "Verificacion de disponibilidad de Winget" {
    $isAvailable = Test-WingetAvailable
    return ($isAvailable -eq $true)
}

# 6. Test de Verificacion de Conectividad
Assert-Test "Ejecucion de Test-InternetConnection" {
    $net = Test-InternetConnection
    return ($net -eq $true -or $net -eq $false)
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " RESULTADOS DE LAS PRUEBAS:" -ForegroundColor Yellow
Write-Host "  Pruebas superadas : $passed" -ForegroundColor Green
Write-Host "  Pruebas fallidas  : $failed" -ForegroundColor $(if ($failed -gt 0) { "Red" } else { "Green" })
Write-Host "==========================================================" -ForegroundColor Cyan

if ($failed -eq 0) {
    Write-Host " [PRUEBAS BASICAS OK] Estas pruebas no certifican instalaciones ni reparaciones reales.`n" -ForegroundColor Green
    exit 0
} else {
    Write-Host " [ALERTA] Se encontraron errores en los tests de XaoInstaller.`n" -ForegroundColor Red
    exit 1
}
