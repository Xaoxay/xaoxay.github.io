﻿<#
.SYNOPSIS
    Suite de pruebas automatizadas para XaoToolbox
#>
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$scriptRoot = $PSScriptRoot
$ps1Path = Join-Path $scriptRoot "XaoToolbox.ps1"
$batPath = Join-Path $scriptRoot "XaoToolbox.bat"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "       SUITE DE PRUEBAS AUTOMATIZADAS: XAO TOOLBOX        " -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan

$passed = 0
$failed = 0

function Assert-Test {
    param(
        [string]$Name,
        [scriptblock]$Condition
    )
    Write-Host -NoNewline " [*] Probando: $Name... "
    try {
        $result = & $Condition
        if ($result -eq $true) {
            Write-Host "[PASO]" -ForegroundColor Green
            $script:passed++
        } else {
            Write-Host "[FALLO]" -ForegroundColor Red
            $script:failed++
        }
    } catch {
        Write-Host "[ERROR]: $_" -ForegroundColor Red
        $script:failed++
    }
}

# 1. Test de Sintaxis de XaoToolbox.ps1
Assert-Test "Sintaxis de XaoToolbox.ps1" {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($ps1Path, [ref]$tokens, [ref]$errors)
    if ($errors.Count -gt 0) {
        foreach ($e in $errors) {
            Write-Host "`n   [!] Error en linea $($e.Extent.StartLineNumber): $($e.Message)" -ForegroundColor Red
        }
    }
    return ($errors.Count -eq 0)
}

# 2. Test de Parseo de XAML (WPF GUI)
Assert-Test "Parseo y validacion de interfaz grafica XAML" {
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
    $code = Get-Content -Path $ps1Path -Raw -Encoding UTF8
    $startTag = '$xamlString = @'''
    $endTag = '''@'
    $startIndex = $code.IndexOf($startTag) + $startTag.Length
    $endIndex = $code.IndexOf($endTag, $startIndex)
    $xaml = $code.Substring($startIndex, $endIndex - $startIndex)

    $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xaml))
    $win = [System.Windows.Markup.XamlReader]::Load($reader)
    return ($win -ne $null -and $win.GetType().Name -eq "Window")
}

# 3. Test de Controles Esenciales en XAML
Assert-Test "Existencia y enlace de controles de UI en XAML" {
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
    $code = Get-Content -Path $ps1Path -Raw -Encoding UTF8
    $startTag = '$xamlString = @'''
    $endTag = '''@'
    $startIndex = $code.IndexOf($startTag) + $startTag.Length
    $endIndex = $code.IndexOf($endTag, $startIndex)
    $xaml = $code.Substring($startIndex, $endIndex - $startIndex)

    $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xaml))
    $win = [System.Windows.Markup.XamlReader]::Load($reader)

    $essential = @(
        "BtnSelectEssential", "BtnInstallSelected", "BtnUpgradeAll",
        "ChkChrome", "Chk7Zip", "ChkVLC", "ChkAdobe",
        "BtnPresetDesktop", "BtnPresetLaptop", "BtnPresetGaming", "BtnApplyTweaks",
        "BtnFixDISM", "BtnFixWindowsUpdate", "BtnFixNetwork", "BtnFixStore",
        "BtnDarkMode", "BtnLightMode",
        "LblSysPC", "LblSysCPU", "LblSysRAM", "TxtConsoleLog", "TxtStatus"
    )

    $missing = @()
    foreach ($ctrl in $essential) {
        if (-not $win.FindName($ctrl)) {
            $missing += $ctrl
        }
    }

    if ($missing.Count -gt 0) {
        Write-Host "`n   [!] Controles faltantes: $($missing -join ', ')" -ForegroundColor Red
        return $false
    }
    return $true
}

# 4. Test de Sintaxis de XaoToolbox.bat (Hibrido para USB)
Assert-Test "Sintaxis y estructura de XaoToolbox.bat" {
    if (-not (Test-Path $batPath)) { return $false }
    $content = [System.IO.File]::ReadAllText($batPath, [System.Text.Encoding]::UTF8)
    $hasHeader = $content.StartsWith("<# :")
    $hasCloser = $content.Contains("exit /b %XAO_EXIT%`r`n#>") -or $content.Contains("exit /b %XAO_EXIT%`n#>")
    return ($hasHeader -and $hasCloser)
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " RESULTADOS DE LAS PRUEBAS:" -ForegroundColor Yellow
Write-Host "  Pruebas superadas : $passed" -ForegroundColor Green
Write-Host "  Pruebas fallidas  : $failed" -ForegroundColor $(if ($failed -gt 0) { "Red" } else { "Green" })
Write-Host "==========================================================" -ForegroundColor Cyan

if ($failed -eq 0) {
    Write-Host " [PRUEBAS BASICAS OK] Estas pruebas no certifican instalaciones ni reparaciones reales.`n" -ForegroundColor Green
    exit 0
} else {
    Write-Host " [ALERTA] Se encontraron errores en los tests de XaoToolbox.`n" -ForegroundColor Red
    exit 1
}
