﻿<# :
@echo off
setlocal EnableDelayedExpansion
title XaoToolbox - Inicializando...

:: Comprobar permisos de Administrador
net session >nul 2>&1
if %errorlevel% NEQ 0 (
    echo.
    echo  [!] Solicitando permisos de Administrador para XaoToolbox...
    echo.
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \"\"%~dpnx0\"\"' -Verb RunAs"
    exit /b
)

:: Cambiar al directorio del script
cd /d "%~dp0"

:: Ejecutar PowerShell incrustado en modo STA con Bypass y codificacion UTF-8
powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Expression ([System.IO.File]::ReadAllText('%~f0', [System.Text.Encoding]::UTF8))"

if %errorlevel% NEQ 0 (
    echo.
    echo  [!] La sesion de XaoToolbox ha finalizado.
    pause
)
exit /b
#>
<#
.SYNOPSIS
    XaoToolbox - Suite Grafica Integral de Optimizacion, Instalacion y Reparacion para Windows 10 y 11.
    Inspirado en la estetica de Chris Titus Tech WinUtil, adaptado y mejorado para todos en español.
.AUTHOR
    Xaoxay Labs
#>

# Forzar STA Mode si es necesario para WPF
if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne [System.Threading.ApartmentState]::STA) {
    Start-Process powershell.exe -ArgumentList "-STA -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

# Asegurar codificacion UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Elevacion automatica de Administrador
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        Start-Process powershell.exe -ArgumentList "-STA -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
        exit
    } catch {
        Write-Host "Se requieren permisos de Administrador para ejecutar XaoToolbox." -ForegroundColor Red
        exit
    }
}

# Cargar librerias de interfaz grafica WPF
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ------------------------------------------------------------------------------
# DEFINICION DEL DISENO VISUAL XAML (ESTILO DARK MODE ELEGANTE)
# ------------------------------------------------------------------------------
$xamlString = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="XaoToolbox v1.0 - Xaoxay Labs"
        Height="760" Width="1100" MinHeight="680" MinWidth="980"
        WindowStartupLocation="CenterScreen"
        Background="#18181b" Foreground="#f4f4f5"
        FontFamily="Segoe UI, Segoe UI Variable Text, Arial">

    <Window.Resources>
        <!-- Estilo de Botones Principales -->
        <Style x:Key="ModernButton" TargetType="Button">
            <Setter Property="Background" Value="#27272a"/>
            <Setter Property="Foreground" Value="#f4f4f5"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="14,8"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="BorderBrush" Value="#3f3f46"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border" Background="{TemplateBinding Background}"
                                BorderBrush="{TemplateBinding BorderBrush}"
                                BorderThickness="{TemplateBinding BorderThickness}"
                                CornerRadius="6" SnapsToDevicePixels="True">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"
                                              Margin="{TemplateBinding Padding}"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#3f3f46"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#52525b"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="border" Property="Opacity" Value="0.5"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- Boton de Accion Verde -->
        <Style x:Key="ActionButtonGreen" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#059669"/>
            <Setter Property="BorderBrush" Value="#10b981"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Boton de Accion Celeste/Azul -->
        <Style x:Key="ActionButtonCyan" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#0284c7"/>
            <Setter Property="BorderBrush" Value="#38bdf8"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Boton de Accion Violeta -->
        <Style x:Key="ActionButtonPurple" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#7c3aed"/>
            <Setter Property="BorderBrush" Value="#a78bfa"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Estilo de Tarjetas (Cards) -->
        <Style x:Key="CardBorder" TargetType="Border">
            <Setter Property="Background" Value="#27272a"/>
            <Setter Property="BorderBrush" Value="#3f3f46"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="CornerRadius" Value="8"/>
            <Setter Property="Padding" Value="14"/>
            <Setter Property="Margin" Value="6"/>
        </Style>

        <!-- Estilo de CheckBoxes -->
        <Style TargetType="CheckBox">
            <Setter Property="Foreground" Value="#f4f4f5"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Margin" Value="0,4,0,4"/>
            <Setter Property="Cursor" Value="Hand"/>
        </Style>

        <!-- Estilo de Pestañas (TabControl) -->
        <Style TargetType="TabItem">
            <Setter Property="Foreground" Value="#a1a1aa"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="18,10"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TabItem">
                        <Border x:Name="tabBorder" Background="Transparent"
                                BorderBrush="Transparent" BorderThickness="0,0,0,3"
                                Margin="4,0" Padding="{TemplateBinding Padding}">
                            <ContentPresenter ContentSource="Header"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsSelected" Value="True">
                                <Setter TargetName="tabBorder" Property="BorderBrush" Value="#06b6d4"/>
                                <Setter Property="Foreground" Value="#22d3ee"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Foreground" Value="#ffffff"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/> <!-- Cabecera / Header -->
            <RowDefinition Height="*"/>    <!-- Contenido de Pestanas -->
            <RowDefinition Height="140"/>  <!-- Consola de Log en vivo -->
            <RowDefinition Height="Auto"/> <!-- Barra de Estado inferior -->
        </Grid.RowDefinitions>

        <!-- CABECERA PRINCIPAL -->
        <Border Grid.Row="0" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,0,0,1" Padding="20,12">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <StackPanel Grid.Column="0" VerticalAlignment="Center">
                    <StackPanel Orientation="Horizontal">
                        <TextBlock Text="XAOWIN TOOLBOX" FontSize="20" FontWeight="Bold" Foreground="#38bdf8"/>
                        <Border Background="#06b6d4" CornerRadius="4" Margin="10,0,0,0" Padding="6,2" VerticalAlignment="Center">
                            <TextBlock Text="v1.0" FontSize="11" FontWeight="Bold" Foreground="#000000"/>
                        </Border>
                    </StackPanel>
                    <TextBlock Text="Xaoxay Labs  •  Instalador de Software, Optimizador &amp; Reparador de Windows"
                               FontSize="12" Foreground="#71717a" Margin="0,2,0,0"/>
                </StackPanel>

                <!-- Resumen rapido del equipo -->
                <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgePCName" Text="Equipo: Windows PC" FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgeRAM" Text="RAM: ..." FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgeDisk" Text="Disco C: ..." FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                </StackPanel>
            </Grid>
        </Border>

        <!-- PESTANAS (TAB CONTROL) -->
        <TabControl Grid.Row="1" Background="#18181b" BorderThickness="0" Margin="12,6,12,0">

            <!-- PESTANA 1: INSTALAR PROGRAMAS -->
            <TabItem Header="📦 Instalar Programas">
                <Grid Margin="0,10,0,0">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/> <!-- Barra de Presets -->
                        <RowDefinition Height="*"/>    <!-- Tarjetas de Programas -->
                        <RowDefinition Height="Auto"/> <!-- Botones de Accion -->
                    </Grid.RowDefinitions>

                    <!-- Barra de Seleccion Rapida -->
                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="6,0,6,10">
                        <Button x:Name="BtnSelectEssential" Content="⭐ Marcar Pack Basico (Chrome, 7-Zip, VLC, Adobe PDF)"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnSelectAllApps" Content="Seleccionar Todo"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnClearApps" Content="Desmarcar Todo"
                                Style="{StaticResource ModernButton}"/>
                    </StackPanel>

                    <!-- Tarjetas de Categorias (Scrollable) -->
                    <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                        <UniformGrid Columns="3" Margin="0,0,0,10">

                            <!-- Tarjeta 1: Navegadores -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🌐 Navegadores Web" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkChrome" Content="Google Chrome"/>
                                    <CheckBox x:Name="ChkFirefox" Content="Mozilla Firefox"/>
                                    <CheckBox x:Name="ChkBrave" Content="Brave Browser (Anti-Ads)"/>
                                    <CheckBox x:Name="ChkOpera" Content="Opera One"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 2: Compresores y Archivos -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="📦 Compresores &amp; Archivos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="Chk7Zip" Content="7-Zip (Gratis &amp; Liviano)"/>
                                    <CheckBox x:Name="ChkWinRAR" Content="WinRAR"/>
                                    <CheckBox x:Name="ChkNotepadPP" Content="Notepad++ (Editor util)"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 3: Multimedia -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🎬 Multimedia &amp; Musica" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkVLC" Content="VLC Media Player"/>
                                    <CheckBox x:Name="ChkSpotify" Content="Spotify"/>
                                    <CheckBox x:Name="ChkKLite" Content="K-Lite Codec Pack"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 4: Ofimatica y Lectura -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="📄 Documentos &amp; Oficina" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkAdobe" Content="Adobe Acrobat Reader (PDF)"/>
                                    <CheckBox x:Name="ChkLibreOffice" Content="LibreOffice (Ofimatica Gratis)"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 5: Comunicacion -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="💬 Comunicacion &amp; Redes" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkDiscord" Content="Discord"/>
                                    <CheckBox x:Name="ChkTelegram" Content="Telegram Desktop"/>
                                    <CheckBox x:Name="ChkWhatsApp" Content="WhatsApp Desktop"/>
                                    <CheckBox x:Name="ChkZoom" Content="Zoom Workplace"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 6: Soporte & Gaming -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🎮 Gaming &amp; Soporte Remoto" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkAnyDesk" Content="AnyDesk (Soporte Remoto)"/>
                                    <CheckBox x:Name="ChkRustDesk" Content="RustDesk"/>
                                    <CheckBox x:Name="ChkSteam" Content="Steam"/>
                                    <CheckBox x:Name="ChkVSCode" Content="Visual Studio Code"/>
                                </StackPanel>
                            </Border>

                        </UniformGrid>
                    </ScrollViewer>

                    <!-- Botones de Accion Inferiores -->
                    <Border Grid.Row="2" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="0,10,0,6">
                        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
                            <Button x:Name="BtnUpgradeAll" Content="🔄 ACTUALIZAR TODOS MIS PROGRAMAS"
                                    Style="{StaticResource ActionButtonCyan}" Margin="0,0,10,0"/>
                            <Button x:Name="BtnInstallSelected" Content="🚀 INSTALAR PROGRAMAS MARCADOS"
                                    Style="{StaticResource ActionButtonGreen}"/>
                        </StackPanel>
                    </Border>
                </Grid>
            </TabItem>

            <!-- PESTANA 2: OPTIMIZACIONES & TWEAKS -->
            <TabItem Header="⚡ Optimizaciones (Tweaks)">
                <Grid Margin="0,10,0,0">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/> <!-- Presets -->
                        <RowDefinition Height="*"/>    <!-- Casillas de Tweaks -->
                        <RowDefinition Height="Auto"/> <!-- Boton Aplicar -->
                    </Grid.RowDefinitions>

                    <!-- Botones de Presets -->
                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="6,0,6,10">
                        <Button x:Name="BtnPresetDesktop" Content="💻 Recomendado PC Escritorio"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnPresetLaptop" Content="🔋 Recomendado Notebook"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnPresetGaming" Content="🎮 Modo Gaming (Maximos FPS)"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnClearTweaks" Content="Desmarcar Todo"
                                Style="{StaticResource ModernButton}"/>
                    </StackPanel>

                    <!-- Contenedores de Opciones -->
                    <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                        <UniformGrid Columns="3" Margin="0,0,0,10">

                            <!-- Privacidad y Telemetria -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🛡️ Privacidad &amp; Telemetria" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkRestorePoint" Content="Crear Punto de Restauracion previo" IsChecked="True"/>
                                    <CheckBox x:Name="ChkDisableTelemetry" Content="Desactivar Telemetria de Microsoft"/>
                                    <CheckBox x:Name="ChkDisableStartAds" Content="Quitar Publicidad del Menu Inicio"/>
                                    <CheckBox x:Name="ChkDisableActivityHistory" Content="Desactivar Historial de Actividad"/>
                                    <CheckBox x:Name="ChkDisableWifiSense" Content="Desactivar Wi-Fi Sense"/>
                                </StackPanel>
                            </Border>

                            <!-- Rendimiento y Juegos -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="⚡ Rendimiento &amp; Juegos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkDisableGameDVR" Content="Desactivar GameDVR (Menos tirones)"/>
                                    <CheckBox x:Name="ChkDisableMouseAccel" Content="Desactivar Aceleracion del Mouse (1:1)"/>
                                    <CheckBox x:Name="ChkNetworkLatency" Content="Optimizar Latencia de Red (Nagle OFF)"/>
                                    <CheckBox x:Name="ChkMaxPerformancePlan" Content="Activar Plan 'Maximo Rendimiento'"/>
                                    <CheckBox x:Name="ChkDisableHibernation" Content="Desactivar Hibernacion (Libera disco)"/>
                                </StackPanel>
                            </Border>

                            <!-- Limpieza y Servicios -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🧹 Limpieza &amp; Servicios" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkServicesManual" Content="Pasar Servicios Innecesarios a Manual"/>
                                    <CheckBox x:Name="ChkCleanTemp" Content="Limpiar Archivos Temporales de Windows"/>
                                    <CheckBox x:Name="ChkEmptyRecycle" Content="Vaciar Papelera de Reciclaje"/>
                                </StackPanel>
                            </Border>

                        </UniformGrid>
                    </ScrollViewer>

                    <!-- Boton Aplicar -->
                    <Border Grid.Row="2" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="0,10,0,6">
                        <Button x:Name="BtnApplyTweaks" Content="⚡ APLICAR OPTIMIZACIONES SELECCIONADAS"
                                Style="{StaticResource ActionButtonPurple}" HorizontalAlignment="Right"/>
                    </Border>
                </Grid>
            </TabItem>

            <!-- PESTANA 3: REPARACIONES DEL SISTEMA -->
            <TabItem Header="🛠️ Reparaciones (Fixes)">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <UniformGrid Columns="2" Margin="0,0,0,10">

                        <!-- Reparacion DISM / SFC -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🔧 Reparar Archivos de Sistema (DISM + SFC)" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Escanea todos los archivos de Windows y reemplaza de forma segura cualquier archivo roto o dañado por un corte de luz o virus."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixDISM" Content="Ejecutar DISM + SFC" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion Windows Update -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🔄 Reparar Windows Update Trabado" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Detiene los servicios, purga la carpeta SoftwareDistribution de actualizaciones corruptas y reinicia la descarga limpia."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixWindowsUpdate" Content="Reparar Actualizaciones" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion de Red e Internet -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🌐 Reparar Red, Internet &amp; DNS" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Reinicia la pila TCP/IP, resetea el catalogo Winsock, vacia la cache DNS y renueva los adaptadores de red."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixNetwork" Content="Restablecer Red" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion Microsoft Store -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🏪 Reparar Microsoft Store &amp; Apps Nativas" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Ejecuta wsreset para reiniciar la tienda oficial y registra nuevamente las aplicaciones del sistema que no abren."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixStore" Content="Reparar Tienda" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparar Iconos y Explorer -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🗂️ Reparar Explorador &amp; Cache de Iconos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Borra la memoria temporal de iconos en blanco, miniaturas corruptas y reinicia el explorador en 1 segundo."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixExplorer" Content="Reparar Iconos" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Desatascar Impresion -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🖨️ Desatascar Cola de Impresion" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Elimina trabajos y documentos trabados en la memoria de la impresora que impiden imprimir nuevos archivos."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixSpooler" Content="Desatascar Impresora" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                    </UniformGrid>
                </ScrollViewer>
            </TabItem>

            <!-- PESTANA 4: CONFIGURACION & UTILIDADES -->
            <TabItem Header="⚙️ Configuracion &amp; Accesos">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <StackPanel Margin="0,0,0,10">

                        <!-- Personalizacion Rapida -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🎨 Personalizacion de Windows" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnDarkMode" Content="🌙 Activar Modo Oscuro" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnLightMode" Content="☀️ Activar Modo Claro" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnShowExtensions" Content="👁️ Mostrar Extensiones (.exe, .txt)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnShowHidden" Content="📂 Mostrar Archivos Ocultos" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                        <!-- Componentes Opcionales -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🧩 Componentes de Windows" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnEnableDotNet" Content="📦 Habilitar .NET 3.5" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnEnableWSL" Content="🐧 Habilitar WSL (Linux)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnEnableSandbox" Content="🛡️ Habilitar Windows Sandbox" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                        <!-- Accesos Directos Clasicos -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🛠️ Herramientas Administrativas Nativas" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnToolDevMgmt" Content="Administrador de Dispositivos" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolTaskMgr" Content="Administrador de Tareas" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolNCPA" Content="Conexiones de Red (ncpa.cpl)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolServices" Content="Servicios de Windows" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolRegedit" Content="Editor de Registro (regedit)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolMSConfig" Content="Configuracion de Sistema" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                    </StackPanel>
                </ScrollViewer>
            </TabItem>

            <!-- PESTANA 5: DIAGNOSTICO DE MI PC -->
            <TabItem Header="📊 Mi PC (Diagnostico)">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <UniformGrid Columns="2" Margin="0,0,0,10">

                        <!-- Tarjeta Sistema & Chasis -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="💻 Informacion General" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysPC" Text="Equipo: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysOS" Text="Sistema: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysFormFactor" Text="Tipo: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Hardware CPU & RAM -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="⚡ Procesador &amp; Memoria" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysCPU" Text="CPU: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysRAM" Text="RAM: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysSlots" Text="Ranuras de RAM: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Almacenamiento -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="💾 Disco Principal" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysDiskType" Text="Tipo: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysDiskSpace" Text="Espacio: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Bateria / Energia -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🔋 Bateria &amp; Energia" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysBattery" Text="Bateria: ..." FontSize="13" Margin="0,3"/>
                                <Button x:Name="BtnBatteryReport" Content="Generar Reporte de Salud de Bateria"
                                        Style="{StaticResource ModernButton}" Margin="0,10,0,0" HorizontalAlignment="Left"/>
                            </StackPanel>
                        </Border>

                    </UniformGrid>
                </ScrollViewer>
            </TabItem>

        </TabControl>

        <!-- CONSOLA DE REGISTRO EN TIEMPO REAL -->
        <Border Grid.Row="2" Background="#09090b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="14,8">
            <Grid>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="*"/>
                </Grid.RowDefinitions>

                <!-- Cabecera de la consola -->
                <Grid Grid.Row="0" Margin="0,0,0,4">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Text=">_ REGISTRO DE ACTIVIDAD EN VIVO" FontSize="11" FontWeight="Bold" Foreground="#71717a" VerticalAlignment="Center"/>
                    <StackPanel Grid.Column="1" Orientation="Horizontal">
                        <Button x:Name="BtnClearLog" Content="Limpiar" Style="{StaticResource ModernButton}" Padding="8,2" FontSize="11" Margin="0,0,6,0"/>
                        <Button x:Name="BtnCopyLog" Content="Copiar" Style="{StaticResource ModernButton}" Padding="8,2" FontSize="11"/>
                    </StackPanel>
                </Grid>

                <!-- Cuadro de Texto de la Consola -->
                <TextBox Grid.Row="1" x:Name="TxtConsoleLog" Background="#09090b" Foreground="#22c55e"
                         BorderThickness="0" FontFamily="Consolas, Lucida Console, Courier New" FontSize="12"
                         IsReadOnly="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"
                         TextWrapping="Wrap"/>
            </Grid>
        </Border>

        <!-- BARRA DE ESTADO INFERIOR -->
        <Border Grid.Row="3" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="14,4">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock x:Name="TxtStatus" Text="Listo. Selecciona una opcion para comenzar." FontSize="11" Foreground="#a1a1aa"/>
                <TextBlock Grid.Column="1" Text="Xaoxay Labs" FontSize="11" Foreground="#52525b"/>
            </Grid>
        </Border>
    </Grid>
</Window>
'@

# ------------------------------------------------------------------------------
# PARSEAR XAML Y OBTENER VENTANA
# ------------------------------------------------------------------------------
$reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xamlString))
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# ------------------------------------------------------------------------------
# MAPEO AUTOMATICO DE CONTROLES
# ------------------------------------------------------------------------------
$controls = @(
    "BadgePCName", "BadgeRAM", "BadgeDisk",
    "BtnSelectEssential", "BtnSelectAllApps", "BtnClearApps",
    "ChkChrome", "ChkFirefox", "ChkBrave", "ChkOpera",
    "Chk7Zip", "ChkWinRAR", "ChkNotepadPP",
    "ChkVLC", "ChkSpotify", "ChkKLite",
    "ChkAdobe", "ChkLibreOffice",
    "ChkDiscord", "ChkTelegram", "ChkWhatsApp", "ChkZoom",
    "ChkAnyDesk", "ChkRustDesk", "ChkSteam", "ChkVSCode",
    "BtnInstallSelected", "BtnUpgradeAll",
    "BtnPresetDesktop", "BtnPresetLaptop", "BtnPresetGaming", "BtnClearTweaks",
    "ChkRestorePoint", "ChkDisableTelemetry", "ChkDisableStartAds", "ChkDisableActivityHistory", "ChkDisableWifiSense",
    "ChkDisableGameDVR", "ChkDisableMouseAccel", "ChkNetworkLatency", "ChkMaxPerformancePlan", "ChkDisableHibernation",
    "ChkServicesManual", "ChkCleanTemp", "ChkEmptyRecycle",
    "BtnApplyTweaks",
    "BtnFixDISM", "BtnFixWindowsUpdate", "BtnFixNetwork", "BtnFixStore", "BtnFixExplorer", "BtnFixSpooler",
    "BtnDarkMode", "BtnLightMode", "BtnShowExtensions", "BtnShowHidden",
    "BtnEnableDotNet", "BtnEnableWSL", "BtnEnableSandbox",
    "BtnToolDevMgmt", "BtnToolTaskMgr", "BtnToolNCPA", "BtnToolServices", "BtnToolRegedit", "BtnToolMSConfig",
    "LblSysPC", "LblSysOS", "LblSysFormFactor", "LblSysCPU", "LblSysRAM", "LblSysSlots", "LblSysDiskType", "LblSysDiskSpace", "LblSysBattery", "BtnBatteryReport",
    "BtnClearLog", "BtnCopyLog", "TxtConsoleLog", "TxtStatus"
)

$UI = @{}
foreach ($ctrlName in $controls) {
    $UI[$ctrlName] = $window.FindName($ctrlName)
}

# ------------------------------------------------------------------------------
# LOGGING Y ESTADO THREAD-SAFE (DISPATCHER)
# ------------------------------------------------------------------------------
function Log {
    param(
        [string]$Message,
        [string]$Type = "INFO"
    )
    $ts = Get-Date -Format "HH:mm:ss"
    $prefix = switch ($Type) {
        "SUCCESS" { "[OK]" }
        "WARNING" { "[AVISO]" }
        "ERROR"   { "[ERROR]" }
        default   { "[*]" }
    }
    $line = "[$ts] $prefix $Message"

    $window.Dispatcher.Invoke([Action]{
        $UI["TxtConsoleLog"].AppendText($line + "`r`n")
        $UI["TxtConsoleLog"].ScrollToEnd()
        $UI["TxtStatus"].Text = $Message
    })
}

# ------------------------------------------------------------------------------
# EJECUCION EN SEGUNDO PLANO PARA NO CONGELAR LA VENTANA
# ------------------------------------------------------------------------------
function Run-Async {
    param(
        [scriptblock]$Action
    )

    $worker = New-Object System.ComponentModel.BackgroundWorker
    $worker.add_DoWork({
        param($s, $e)
        & $Action
    })
    $worker.add_RunWorkerCompleted({
        param($s, $e)
        $window.Dispatcher.Invoke([Action]{
            $UI["TxtStatus"].Text = "Operacion completada."
        })
    })
    $worker.RunWorkerAsync()
}

# ------------------------------------------------------------------------------
# DETECCION Y CARGA DE HARDWARE (TAB 5 Y HEADER)
# ------------------------------------------------------------------------------
function Load-HardwareInfo {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
        $drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -eq "C" }
        $disks = Get-PhysicalDisk -ErrorAction SilentlyContinue
        $diskType = "Disco"
        if ($disks) {
            $cDisk = $disks | Select-Object -First 1
            $diskType = if ($cDisk.MediaType) { $cDisk.MediaType } else { "SSD" }
        }
        $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue

        $totalRAM = [Math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        $freeRAM = [Math]::Round($os.FreePhysicalMemory / 1MB, 1)
        $totalDisk = [Math]::Round(($drives.Used + $drives.Free) / 1GB, 1)
        $freeDisk = [Math]::Round($drives.Free / 1GB, 1)

        $isLaptop = ($cs.PCSystemType -eq 2) -or ($battery -ne $null)
        $chassis = if ($isLaptop) { "Notebook / Laptop" } else { "PC de Escritorio" }

        # Ranuras de memoria
        $memDevices = Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue
        $memArray = Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue
        $slotsUsed = if ($memDevices) { $memDevices.Count } else { 1 }
        $slotsTotal = if ($memArray) { $memArray.MemoryDevices } else { $slotsUsed }

        # Asignar a la interfaz
        $UI["BadgePCName"].Text = "PC: $($cs.Name)"
        $UI["BadgeRAM"].Text = "RAM: $totalRAM GB ($freeRAM GB libres)"
        $UI["BadgeDisk"].Text = "Disco C: $freeDisk GB libres"

        $UI["LblSysPC"].Text = "Equipo: $($cs.Name) ($($cs.Manufacturer) $($cs.Model))"
        $UI["LblSysOS"].Text = "Sistema: $($os.Caption) (Build $($os.BuildNumber))"
        $UI["LblSysFormFactor"].Text = "Form Factor: $chassis"
        $UI["LblSysCPU"].Text = "Procesador: $($cpu.Name) ($($cpu.NumberOfCores) Nucleos, $($cpu.NumberOfLogicalProcessors) Hilos)"
        $UI["LblSysRAM"].Text = "Memoria RAM: $totalRAM GB instalados ($freeRAM GB libres)"
        $UI["LblSysSlots"].Text = "Ranuras de RAM: $slotsUsed de $slotsTotal ocupadas"
        $UI["LblSysDiskType"].Text = "Tecnologia de Disco: $diskType"
        $UI["LblSysDiskSpace"].Text = "Espacio Disco C: $freeDisk GB libres de $totalDisk GB totales"

        if ($battery) {
            $UI["LblSysBattery"].Text = "Bateria: $($battery.EstimatedChargeRemaining)% de carga (Conectado a corriente: $($battery.BatteryStatus -eq 2))"
        } else {
            $UI["LblSysBattery"].Text = "Bateria: No aplicable (Equipo de escritorio conectado a red electrica)"
        }

        Log "Informacion de hardware cargada exitosamente: $($cs.Name) [$chassis]" "SUCCESS"
    } catch {
        Log "Aviso al cargar info de hardware: $_" "WARNING"
    }
}

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 1: INSTALADOR DE SOFTWARE (WINGET)
# ------------------------------------------------------------------------------
$appMap = @{
    "ChkChrome"      = @{ Id = "Google.Chrome"; Name = "Google Chrome" };
    "ChkFirefox"     = @{ Id = "Mozilla.Firefox"; Name = "Mozilla Firefox" };
    "ChkBrave"       = @{ Id = "Brave.Brave"; Name = "Brave Browser" };
    "ChkOpera"       = @{ Id = "Opera.Opera"; Name = "Opera One" };
    "Chk7Zip"        = @{ Id = "7zip.7zip"; Name = "7-Zip" };
    "ChkWinRAR"      = @{ Id = "RARLab.WinRAR"; Name = "WinRAR" };
    "ChkNotepadPP"   = @{ Id = "Notepad++.Notepad++"; Name = "Notepad++" };
    "ChkVLC"         = @{ Id = "VideoLAN.VLC"; Name = "VLC Media Player" };
    "ChkSpotify"     = @{ Id = "Spotify.Spotify"; Name = "Spotify" };
    "ChkKLite"       = @{ Id = "CodecGuide.K-LiteCodecPack.Standard"; Name = "K-Lite Codec Pack" };
    "ChkAdobe"       = @{ Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader" };
    "ChkLibreOffice" = @{ Id = "TheDocumentFoundation.LibreOffice"; Name = "LibreOffice" };
    "ChkDiscord"     = @{ Id = "Discord.Discord"; Name = "Discord" };
    "ChkTelegram"    = @{ Id = "Telegram.TelegramDesktop"; Name = "Telegram Desktop" };
    "ChkWhatsApp"    = @{ Id = "9NKSQGP7F2NH"; Name = "WhatsApp Desktop"; Source = "msstore" };
    "ChkZoom"        = @{ Id = "Zoom.Zoom"; Name = "Zoom Workplace" };
    "ChkAnyDesk"     = @{ Id = "AnyDesk.AnyDesk"; Name = "AnyDesk" };
    "ChkRustDesk"    = @{ Id = "RustDesk.RustDesk"; Name = "RustDesk" };
    "ChkSteam"       = @{ Id = "Valve.Steam"; Name = "Steam" };
    "ChkVSCode"      = @{ Id = "Microsoft.VisualStudioCode"; Name = "Visual Studio Code" }
}

# Boton Marcar Pack Basico
$UI["BtnSelectEssential"].Add_Click({
    $UI["BtnClearApps"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkChrome"].IsChecked = $true
    $UI["Chk7Zip"].IsChecked = $true
    $UI["ChkVLC"].IsChecked = $true
    $UI["ChkAdobe"].IsChecked = $true
    Log "Pack Basico marcado: Chrome, 7-Zip, VLC, Adobe Acrobat Reader" "INFO"
})

# Boton Seleccionar Todo
$UI["BtnSelectAllApps"].Add_Click({
    foreach ($k in $appMap.Keys) {
        if ($UI[$k]) { $UI[$k].IsChecked = $true }
    }
})

# Boton Desmarcar Todo
$UI["BtnClearApps"].Add_Click({
    foreach ($k in $appMap.Keys) {
        if ($UI[$k]) { $UI[$k].IsChecked = $false }
    }
})

# Boton Instalar Programas Marcados
$UI["BtnInstallSelected"].Add_Click({
    $selected = @()
    foreach ($k in $appMap.Keys) {
        if ($UI[$k] -and $UI[$k].IsChecked) {
            $selected += $appMap[$k]
        }
    }

    if ($selected.Count -eq 0) {
        [System.Windows.MessageBox]::Show("Por favor marca al menos un programa para instalar.", "XaoToolbox", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information)
        return
    }

    Run-Async {
        Log "Iniciando instalacion por lotes de $($selected.Count) programas..." "INFO"
        foreach ($app in $selected) {
            Log "Descargando e instalando $($app.Name)..." "INFO"
            $wingetArgs = @("install", "--id", $app.Id, "--silent", "--accept-source-agreements", "--accept-package-agreements", "--force")
            if ($app.Source) {
                $wingetArgs += @("-s", $app.Source)
            }
            & winget @wingetArgs
            if ($LASTEXITCODE -eq 0 -or $LASTEXITCODE -eq -1978335189) {
                Log "$($app.Name) instalado o actualizado correctamente." "SUCCESS"
            } else {
                Log "Aviso en $($app.Name) (Codigo de salida: $LASTEXITCODE)." "WARNING"
            }
        }
        Log "Proceso de instalacion por lotes finalizado!" "SUCCESS"
    }
})

# Boton Actualizar Todos los Programas
$UI["BtnUpgradeAll"].Add_Click({
    Run-Async {
        Log "Buscando y actualizando TODOS los programas instalados en la PC..." "INFO"
        & winget upgrade --all --silent --accept-source-agreements --accept-package-agreements --force
        Log "Actualizacion general completada con exito." "SUCCESS"
    }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 2: OPTIMIZACIONES (TWEAKS)
# ------------------------------------------------------------------------------

# Presets de Tweaks
$UI["BtnPresetDesktop"].Add_Click({
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkDisableStartAds"].IsChecked = $true
    $UI["ChkDisableActivityHistory"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $true
    $UI["ChkMaxPerformancePlan"].IsChecked = $true
    $UI["ChkDisableHibernation"].IsChecked = $true
    $UI["ChkServicesManual"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $true
    Log "Preset 'PC de Escritorio' seleccionado." "INFO"
})

$UI["BtnPresetLaptop"].Add_Click({
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkDisableStartAds"].IsChecked = $true
    $UI["ChkDisableActivityHistory"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $true
    $UI["ChkServicesManual"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $true
    # Para laptop mantenemos hibernacion activa
    $UI["ChkDisableHibernation"].IsChecked = $false
    Log "Preset 'Notebook' seleccionado (Cuidado de bateria activado)." "INFO"
})

$UI["BtnPresetGaming"].Add_Click({
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkDisableMouseAccel"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $true
    $UI["ChkMaxPerformancePlan"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $true
    Log "Preset 'Modo Gaming' seleccionado (FPS optimos y latencia minima)." "INFO"
})

$UI["BtnClearTweaks"].Add_Click({
    $tweaksList = @(
        "ChkRestorePoint", "ChkDisableTelemetry", "ChkDisableStartAds", "ChkDisableActivityHistory", "ChkDisableWifiSense",
        "ChkDisableGameDVR", "ChkDisableMouseAccel", "ChkNetworkLatency", "ChkMaxPerformancePlan", "ChkDisableHibernation",
        "ChkServicesManual", "ChkCleanTemp", "ChkEmptyRecycle"
    )
    foreach ($t in $tweaksList) {
        if ($UI[$t]) { $UI[$t].IsChecked = $false }
    }
})

# Aplicar Optimizaciones Marcadas
$UI["BtnApplyTweaks"].Add_Click({
    Run-Async {
        # 1. Punto de Restauracion
        if ($UI["ChkRestorePoint"].IsChecked) {
            Log "Creando punto de restauracion de seguridad..." "INFO"
            try {
                Checkpoint-Computer -Description "XaoToolbox_PreTweaks" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
                Log "Punto de restauracion creado con exito." "SUCCESS"
            } catch {
                Log "Aviso: No se pudo crear punto de restauracion (Restauracion desactivada en Windows)." "WARNING"
            }
        }

        # 2. Telemetria
        if ($UI["ChkDisableTelemetry"].IsChecked) {
            Log "Desactivando telemetria y diagnosticos de Windows..." "INFO"
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Stop-Service -Name "DiagTrack" -Force -ErrorAction SilentlyContinue
            Set-Service -Name "DiagTrack" -StartupType Disabled -ErrorAction SilentlyContinue
            Log "Telemetria desactivada." "SUCCESS"
        }

        # 3. Publicidad en Inicio
        if ($UI["ChkDisableStartAds"].IsChecked) {
            Log "Quitando sugerencias y publicidad del Menu Inicio..." "INFO"
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SystemPaneSuggestionsEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338388Enabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Log "Publicidad del Menu Inicio eliminada." "SUCCESS"
        }

        # 4. Historial de Actividad
        if ($UI["ChkDisableActivityHistory"].IsChecked) {
            Log "Desactivando historial de actividad..." "INFO"
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableActivityFeed" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "PublishUserActivities" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Log "Historial de actividad desactivado." "SUCCESS"
        }

        # 5. Wi-Fi Sense
        if ($UI["ChkDisableWifiSense"].IsChecked) {
            Log "Desactivando Wi-Fi Sense..." "INFO"
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting" -Name "value" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Log "Wi-Fi Sense desactivado." "SUCCESS"
        }

        # 6. GameDVR
        if ($UI["ChkDisableGameDVR"].IsChecked) {
            Log "Desactivando GameDVR (Grabacion en segundo plano de juegos)..." "INFO"
            Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Log "GameDVR desactivado (Menos caidas de FPS)." "SUCCESS"
        }

        # 7. Aceleracion de Mouse (1:1)
        if ($UI["ChkDisableMouseAccel"].IsChecked) {
            Log "Configurando precision de puntero de mouse 1:1..." "INFO"
            Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseSpeed" -Value "0" -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold1" -Value "0" -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold2" -Value "0" -Force -ErrorAction SilentlyContinue
            Log "Precision de mouse optimizada para gaming." "SUCCESS"
        }

        # 8. Latencia de Red (Nagle)
        if ($UI["ChkNetworkLatency"].IsChecked) {
            Log "Optimizando latencia de paquetes TCP de red..." "INFO"
            $interfaces = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" -ErrorAction SilentlyContinue
            foreach ($iface in $interfaces) {
                Set-ItemProperty -Path $iface.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
                Set-ItemProperty -Path $iface.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
            }
            Log "Algoritmo de Nagle desactivado (Ping reducido)." "SUCCESS"
        }

        # 9. Plan Maximo Rendimiento
        if ($UI["ChkMaxPerformancePlan"].IsChecked) {
            Log "Activando plan de energia de Maximo Rendimiento..." "INFO"
            & powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 | Out-Null
            & powercfg /setactive e9a42b02-d5df-448d-aa00-03f14749eb61 | Out-Null
            Log "Plan Maximo Rendimiento activado en el sistema." "SUCCESS"
        }

        # 10. Desactivar Hibernacion
        if ($UI["ChkDisableHibernation"].IsChecked) {
            Log "Desactivando hibernacion para liberar espacio en disco..." "INFO"
            & powercfg /hibernate off | Out-Null
            Log "Archivo hiberfil.sys eliminado (Gigabytes liberados en disco C:)." "SUCCESS"
        }

        # 11. Servicios a Manual
        if ($UI["ChkServicesManual"].IsChecked) {
            Log "Ajustando servicios innecesarios a inicio manual..." "INFO"
            $services = @("XblAuthManager", "XblGameSave", "XboxNetApiSvc", "MapsBroker", "Fax")
            foreach ($s in $services) {
                Set-Service -Name $s -StartupType Manual -ErrorAction SilentlyContinue
            }
            Log "Servicios ajustados a manual." "SUCCESS"
        }

        # 12. Limpieza de Temporales
        if ($UI["ChkCleanTemp"].IsChecked) {
            Log "Limpiando archivos temporales..." "INFO"
            $tempPaths = @($env:TEMP, "$env:SystemRoot\Temp")
            foreach ($p in $tempPaths) {
                if (Test-Path $p) {
                    Get-ChildItem -Path $p -Recurse -Force -ErrorAction SilentlyContinue |
                        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
            Log "Archivos temporales eliminados." "SUCCESS"
        }

        # 13. Vaciar Papelera
        if ($UI["ChkEmptyRecycle"].IsChecked) {
            Log "Vaciando papelera de reciclaje..." "INFO"
            try {
                Clear-RecycleBin -Force -ErrorAction SilentlyContinue
                Log "Papelera vaciada." "SUCCESS"
            } catch { }
        }

        Log "¡Todas las optimizaciones seleccionadas fueron aplicadas con exito!" "SUCCESS"
    }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 3: REPARACIONES DEL SISTEMA (FIXES)
# ------------------------------------------------------------------------------

# DISM + SFC
$UI["BtnFixDISM"].Add_Click({
    Run-Async {
        Log "Iniciando reparacion de archivos de sistema con DISM y SFC..." "INFO"
        Log "Paso 1/2: Analizando y reparando imagen de Windows (DISM RestoreHealth)..." "INFO"
        & dism.exe /Online /Cleanup-Image /RestoreHealth
        Log "DISM completado. Paso 2/2: Verificando integridad de archivos (SFC Scannow)..." "INFO"
        & sfc.exe /scannow
        Log "Reparacion de archivos de sistema (DISM + SFC) finalizada." "SUCCESS"
    }
})

# Windows Update Fix
$UI["BtnFixWindowsUpdate"].Add_Click({
    Run-Async {
        Log "Deteniendo servicios de Windows Update..." "INFO"
        Stop-Service -Name wuauserv -Force -ErrorAction SilentlyContinue
        Stop-Service -Name bits -Force -ErrorAction SilentlyContinue
        Stop-Service -Name cryptsvc -Force -ErrorAction SilentlyContinue

        Log "Purgando descargas incompletas de SoftwareDistribution..." "INFO"
        $sd = "$env:SystemRoot\SoftwareDistribution"
        if (Test-Path $sd) {
            Get-ChildItem -Path $sd -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }

        Log "Reiniciando servicios de actualizacion..." "INFO"
        Start-Service -Name cryptsvc -ErrorAction SilentlyContinue
        Start-Service -Name bits -ErrorAction SilentlyContinue
        Start-Service -Name wuauserv -ErrorAction SilentlyContinue
        Log "Windows Update reparado y listo para descargar limpiamente." "SUCCESS"
    }
})

# Red e Internet Fix
$UI["BtnFixNetwork"].Add_Click({
    Run-Async {
        Log "Restableciendo catalogo Winsock..." "INFO"
        & netsh winsock reset | Out-Null
        Log "Restableciendo protocolo TCP/IP..." "INFO"
        & netsh int ip reset | Out-Null
        Log "Vaciando cache de resolucion DNS..." "INFO"
        & ipconfig /flushdns | Out-Null
        Log "Red e Internet restablecidos exitosamente (Se recomienda reiniciar la PC)." "SUCCESS"
    }
})

# Microsoft Store Fix
$UI["BtnFixStore"].Add_Click({
    Run-Async {
        Log "Reiniciando Microsoft Store (wsreset)..." "INFO"
        Start-Process "wsreset.exe" -Wait -WindowStyle Hidden
        Log "Microsoft Store y cache de aplicaciones restablecidas." "SUCCESS"
    }
})

# Iconos y Explorer Fix
$UI["BtnFixExplorer"].Add_Click({
    Run-Async {
        Log "Deteniendo proceso del Explorador de Windows..." "INFO"
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Log "Purgando base de datos de cache de iconos..." "INFO"
        $iconCache = "$env:LOCALAPPDATA\IconCache.db"
        if (Test-Path $iconCache) { Remove-Item $iconCache -Force -ErrorAction SilentlyContinue }
        Log "Reiniciando Explorador de Windows..." "INFO"
        Start-Process explorer.exe
        Log "Explorador de Windows e iconos restaurados." "SUCCESS"
    }
})

# Cola de Impresion Fix
$UI["BtnFixSpooler"].Add_Click({
    Run-Async {
        Log "Deteniendo Cola de Impresion..." "INFO"
        Stop-Service -Name Spooler -Force -ErrorAction SilentlyContinue
        Log "Borrando trabajos trabados en la impresora..." "INFO"
        $printSpool = "$env:SystemRoot\System32\spool\PRINTERS\*"
        Remove-Item $printSpool -Force -Recurse -ErrorAction SilentlyContinue
        Log "Reiniciando servicio de impresion..." "INFO"
        Start-Service -Name Spooler -ErrorAction SilentlyContinue
        Log "Cola de impresion desatascada exitosamente." "SUCCESS"
    }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 4: CONFIGURACION Y UTILIDADES
# ------------------------------------------------------------------------------

# Modo Oscuro
$UI["BtnDarkMode"].Add_Click({
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "AppsUseLightTheme" -Value 0 -Type DWord -Force
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "SystemUsesLightTheme" -Value 0 -Type DWord -Force
    Log "Modo Oscuro de Windows activado." "SUCCESS"
})

# Modo Claro
$UI["BtnLightMode"].Add_Click({
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "AppsUseLightTheme" -Value 1 -Type DWord -Force
    Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "SystemUsesLightTheme" -Value 1 -Type DWord -Force
    Log "Modo Claro de Windows activado." "SUCCESS"
})

# Mostrar Extensiones
$UI["BtnShowExtensions"].Add_Click({
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -Value 0 -Type DWord -Force
    Log "Extensiones de archivo visibles (.exe, .pdf, .txt, etc.)." "SUCCESS"
})

# Mostrar Ocultos
$UI["BtnShowHidden"].Add_Click({
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Hidden" -Value 1 -Type DWord -Force
    Log "Archivos y carpetas ocultas ahora son visibles." "SUCCESS"
})

# Componentes Opcionales
$UI["BtnEnableDotNet"].Add_Click({
    Run-Async {
        Log "Habilitando .NET Framework 3.5..." "INFO"
        & dism.exe /Online /Enable-Feature /FeatureName:NetFx3 /All
        Log ".NET Framework 3.5 completado." "SUCCESS"
    }
})

$UI["BtnEnableWSL"].Add_Click({
    Run-Async {
        Log "Instalando / Habilitando Windows Subsystem for Linux (WSL)..." "INFO"
        & wsl --install --no-distribution
        Log "WSL configurado." "SUCCESS"
    }
})

$UI["BtnEnableSandbox"].Add_Click({
    Run-Async {
        Log "Habilitando Windows Sandbox..." "INFO"
        & dism.exe /Online /Enable-Feature /FeatureName:"Containers-DisposableClientVM" -All
        Log "Windows Sandbox habilitado." "SUCCESS"
    }
})

# Herramientas Clasicas
$UI["BtnToolDevMgmt"].Add_Click({ Start-Process "devmgmt.msc" })
$UI["BtnToolTaskMgr"].Add_Click({ Start-Process "taskmgr.exe" })
$UI["BtnToolNCPA"].Add_Click({ Start-Process "ncpa.cpl" })
$UI["BtnToolServices"].Add_Click({ Start-Process "services.msc" })
$UI["BtnToolRegedit"].Add_Click({ Start-Process "regedit.exe" })
$UI["BtnToolMSConfig"].Add_Click({ Start-Process "msconfig.exe" })

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 5: DIAGNOSTICO Y REPORTE DE BATERIA
# ------------------------------------------------------------------------------
$UI["BtnBatteryReport"].Add_Click({
    $reportPath = Join-Path $env:TEMP "BatteryReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
    Run-Async {
        Log "Generando reporte de salud de bateria..." "INFO"
        & powercfg /batteryreport /output "$reportPath" | Out-Null
        if (Test-Path $reportPath) {
            Log "Reporte de bateria generado: $reportPath" "SUCCESS"
            Start-Process "$reportPath"
        } else {
            Log "No se pudo generar reporte (Solo disponible en Notebooks con bateria)." "WARNING"
        }
    }
})

# Botones de Log
$UI["BtnClearLog"].Add_Click({
    $UI["TxtConsoleLog"].Clear()
    Log "Consola de registro limpiada." "INFO"
})

$UI["BtnCopyLog"].Add_Click({
    [System.Windows.Clipboard]::SetText($UI["TxtConsoleLog"].Text)
    Log "Registro copiado al portapapeles." "SUCCESS"
})

# Iniciar carga de info de hardware y mostrar ventana
Load-HardwareInfo
Log "XaoToolbox v1.0 listo. Selecciona una opcion o pestana para comenzar." "SUCCESS"

[void]$window.ShowDialog()
