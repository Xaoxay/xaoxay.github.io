﻿<#
.SYNOPSIS
    XaoToolbox - Suite Grafica Integral de Optimizacion, Instalacion y Reparacion para Windows 10 y 11.
    Inspirado en la estetica de Chris Titus Tech WinUtil, adaptado y mejorado para todos en español.
.AUTHOR
    Xaoxay Labs
#>

# WPF requiere Windows PowerShell STA.
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    if (-not $PSCommandPath) { throw 'Abra Windows PowerShell en modo STA para ejecutar la version en memoria.' }
    $child=Start-Process powershell.exe -ArgumentList "-STA -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Wait -PassThru
    exit $child.ExitCode
}

# BEGIN XAO COMMON
# Xao shared runtime (embedded in every standalone script).
function Invoke-XaoNative {
    param([string]$FilePath,[string[]]$ArgumentList=@(),[int[]]$SuccessCodes=@(0),[switch]$CaptureOutput)
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $exe=Get-Command $FilePath -CommandType Application -ErrorAction Stop | Select-Object -First 1
    & $exe.Source @ArgumentList | ForEach-Object {
        if($CaptureOutput){Write-Output $_}
        elseif($XaoQueue){$XaoQueue.Enqueue([pscustomobject]@{Message=[string]$_;Type='INFO'})}
        else{Write-Host $_;Write-XaoLogRecord -Path $LogFile -Message ([string]$_)}
    }
    $code=$LASTEXITCODE
    if($code -notin $SuccessCodes){throw "$FilePath termino con codigo $code. Consulte la salida y el registro."}
    if($code -eq 3010){Write-Warning 'La operacion requiere reiniciar Windows.'}
    Test-XaoCancellation

    }
}

function Set-XaoRegistryValue {
    [CmdletBinding()]
    param([string]$Path,[string]$Name,$Value,[string]$Type,[switch]$Force)
    Invoke-XaoExclusive {
        $journal=Save-XaoRegistryValue -Path $Path -Name $Name
        if(-not $script:XaoBackupNoticeShown){$script:XaoBackupNoticeShown=$true;Write-Information "Copia de valores de registro: $journal" -InformationAction Continue}
        if(-not (Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force -ErrorAction Stop | Out-Null}
        if($Type){New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null}
        else{Set-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -Force -ErrorAction Stop}
    }
}

function Enable-XaoUltimatePower {
    Invoke-XaoExclusive {

    $template = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
    $target = '64b4b650-61fc-4a85-97c0-cb043335517e'
    $plans = (Invoke-XaoNative powercfg @('/list') -CaptureOutput) -join "`n"
    if ($plans -notmatch $target) { Invoke-XaoNative powercfg @('/duplicatescheme', $template, $target) | Out-Null }
    Invoke-XaoNative powercfg @('/setactive', $target) | Out-Null
    $active = (Invoke-XaoNative powercfg @('/getactivescheme') -CaptureOutput) -join "`n"
    if ($active -notmatch $target) { throw 'Windows no activo el plan solicitado. El equipo puede no admitirlo.' }

    }
}

function Reset-XaoWindowsUpdate {
    Invoke-XaoExclusive {

    $services = @('bits','wuauserv','cryptsvc')
    $running = @()
    $failures = [Collections.Generic.List[string]]::new()
    try {
        foreach ($name in $services) {
            $svc = Get-Service $name -ErrorAction Stop
            if ($svc.Status -ne 'Stopped') {
                $running += $name
                Stop-Service $name -Force -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
            }
        }
        foreach ($path in @("$env:SystemRoot\SoftwareDistribution", "$env:SystemRoot\System32\catroot2")) {
            if (Test-Path -LiteralPath $path) {
                $leaf = (Split-Path $path -Leaf) + '.xao-backup-' + [guid]::NewGuid().ToString('N')
                Rename-Item -LiteralPath $path -NewName $leaf -ErrorAction Stop
            }
        }
    } catch { $failures.Add($_.Exception.Message) }
    finally {
        foreach ($name in $running) {
            try {
                Start-Service $name -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
            } catch { $failures.Add("No se pudo restablecer ${name}: $($_.Exception.Message)") }
        }
    }
    if ($failures.Count) { throw ($failures -join ' | ') }

    }
}

function Reset-XaoPrintQueue {
    Invoke-XaoExclusive {

    $svc = Get-Service Spooler -ErrorAction Stop
    $wasRunning = $svc.Status -eq 'Running'
    try {
        Stop-Service Spooler -Force -ErrorAction Stop
        (Get-Service Spooler).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
        $folder = Join-Path $env:SystemRoot 'System32\spool\PRINTERS'
        # Only pending spool files, never recursively delete a computed directory.
        Get-ChildItem -LiteralPath $folder -File -Force -ErrorAction Stop |
            Where-Object { $_.Extension -in @('.SPL','.SHD') } |
            Remove-Item -Force -ErrorAction Stop
    } finally { if ($wasRunning) { Start-Service Spooler -ErrorAction Stop } }

    }
}

function Clear-XaoTemp {
    param([string[]]$Roots = @($env:TEMP, "$env:SystemRoot\Temp"), [int]$MinimumAgeDays = 7)
    Invoke-XaoExclusive {

    $bytes = 0L; $removed = 0; $skipped = 0
    $cutoff = (Get-Date).AddDays(-[Math]::Max(1, $MinimumAgeDays))
    foreach ($root in ($Roots | Select-Object -Unique)) {
        Test-XaoCancellation
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'Ruta temporal vacia.' }
        $full = [IO.Path]::GetFullPath($root).TrimEnd('\')
        if ($full -eq [IO.Path]::GetPathRoot($full).TrimEnd('\') -or $full -in @($env:USERPROFILE,$env:SystemRoot,$env:ProgramFiles)) {
            throw "Se rechazo una ruta de limpieza demasiado amplia: $full"
        }
        if (-not (Test-Path -LiteralPath $full)) { continue }
        $pending = [Collections.Generic.Stack[string]]::new()
        $pending.Push($full)
        while ($pending.Count) {
            Test-XaoCancellation
            $directory = $pending.Pop()
            try {
                $info = Get-Item -LiteralPath $directory -Force -ErrorAction Stop
                if ($info.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                foreach ($item in Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop) {
                    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                    if ($item.PSIsContainer) { $pending.Push($item.FullName); continue }
                    if ($item.LastWriteTime -ge $cutoff) { continue }
                    try {
                        $length = $item.Length
                        Remove-Item -LiteralPath $item.FullName -Force -ErrorAction Stop
                        $bytes += $length; $removed++
                    } catch { $skipped++ }
                }
            } catch { $skipped++ }
        }
    }
    [pscustomobject]@{ Removed=$removed; Skipped=$skipped; Bytes=$bytes }

    }
}

function Get-XaoRustDeskAsset {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod 'https://api.github.com/repos/rustdesk/rustdesk/releases/latest' -Headers @{'User-Agent'='XaoTools'} -TimeoutSec 30 -ErrorAction Stop
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'aarch64' } elseif ([Environment]::Is64BitOperatingSystem) { 'x86_64' } else { throw 'RustDesk: esta version requiere Windows de 64 bits.' }
    $asset = @($release.assets | Where-Object { $_.name -match "^rustdesk-[0-9.]+-$arch\.msi$" })
    if ($asset.Count -ne 1 -or $asset[0].digest -notmatch '^sha256:[a-fA-F0-9]{64}$') { throw 'No hay un instalador RustDesk con SHA-256 verificable para este equipo.' }
    if ($asset[0].browser_download_url -notmatch '^https://github\.com/rustdesk/rustdesk/releases/download/') { throw 'Origen de RustDesk inesperado.' }
    $asset[0]
}

function Install-XaoRustDesk {
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $asset = Get-XaoRustDeskAsset
    $folder = Join-Path $env:TEMP ('XaoRustDesk-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null
    $file = Join-Path $folder $asset.name
    try {
        Invoke-WebRequest $asset.browser_download_url -OutFile $file -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($hash -ne ($asset.digest -replace '^sha256:','')) { throw 'SHA-256 de RustDesk incorrecto. Se cancelo la instalacion.' }
        $signature=Get-AuthenticodeSignature -LiteralPath $file -ErrorAction Stop
        if($signature.Status -ne 'Valid'){throw "La firma digital de RustDesk no es valida ($($signature.Status)). No se ejecutara el instalador."}
        Test-XaoCancellation
        $msiLog = Join-Path $env:TEMP ('XaoRustDesk-' + (Get-Date -Format yyyyMMddHHmmss) + '.log')
        $process = Start-Process msiexec.exe -ArgumentList "/i `"$file`" /qn /norestart /L*v `"$msiLog`"" -Wait -PassThru -WindowStyle Hidden -ErrorAction Stop
        if ($process.ExitCode -notin @(0,3010)) { throw "RustDesk: MSI termino con codigo $($process.ExitCode). Registro: $msiLog" }
        [pscustomobject]@{ Status= $(if ($process.ExitCode -eq 3010) {'RebootRequired'} else {'Installed'}); Code=$process.ExitCode }
    } finally {
        if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue }
        # Non-recursive: never remove files outside this dedicated download folder.
        Remove-Item -LiteralPath $folder -ErrorAction SilentlyContinue
    }

    }
}

function Install-XaoPackage {
    param([string]$Id, [string]$Source = 'winget')
    Invoke-XaoExclusive {

    Test-XaoCancellation
    if ($Id -eq 'RustDesk.RustDesk') { return Install-XaoRustDesk }
    try { $exe = Get-Command winget.exe -CommandType Application -ErrorAction Stop }
    catch { throw 'Winget no esta disponible. Instale o actualice "Instalador de aplicaciones" desde Microsoft Store y vuelva a abrir la herramienta.' }
    $arguments = @('install','--id',$Id,'--exact','--source',$Source,'--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements')
    & $exe.Source @arguments | ForEach-Object { Write-Host $_ }
    $code = $LASTEXITCODE
    Test-XaoCancellation
    $status = switch ($code) {
        0 { 'Installed' }
        3010 { 'RebootRequired' }
        -1978335189 { 'NoUpdate' }
        -1978335135 { 'AlreadyInstalled' }
        default { throw "Winget no pudo instalar $Id (codigo $code). Revise la salida y los registros de Winget." }
    }
    [pscustomobject]@{ Status=$status; Code=$code }

    }
}

function Update-XaoPackages {
    Invoke-XaoExclusive {

    Invoke-XaoNative winget.exe @('upgrade','--all','--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements') -SuccessCodes @(0,3010,-1978335189)

    }
}


function Test-XaoCancellation {
    if ($XaoCancel -and $XaoCancel.IsCancellationRequested) {
        throw [OperationCanceledException]::new('Detenido entre pasos por solicitud del usuario. Los cambios ya realizados se conservan.')
    }
}

function Enter-XaoOperation {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $mutex = [Threading.Mutex]::new($false, "Local\XaoTools.Operations.$sid")
    try {
        try { $acquired = $mutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $acquired = $true }
        if (-not $acquired) { throw 'Otra herramienta Xao esta trabajando en esta sesion. Espere a que termine.' }
        return $mutex
    } catch { $mutex.Dispose(); throw }
}

function Invoke-XaoExclusive {
    param([scriptblock]$Action)
    Test-XaoCancellation
    $mutex = Enter-XaoOperation
    try { & $Action } finally { $mutex.ReleaseMutex(); $mutex.Dispose() }
}

function Initialize-XaoLog {
    param([string]$Tool)
    $folder = Join-Path $env:LOCALAPPDATA 'XaoTools\Logs'
    try { New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null }
    catch { $folder = [IO.Path]::GetTempPath() }
    $path = Join-Path $folder ("{0}-{1}-{2}.log" -f $Tool,(Get-Date -Format 'yyyyMMdd-HHmmss-fff'),$PID)
    try { [IO.File]::WriteAllText($path, "Xao v1.2 | $Tool | $(Get-Date -Format o)`r`n", [Text.UTF8Encoding]::new($false)) }
    catch { Write-Warning "No se pudo crear el registro: $($_.Exception.Message)"; return $null }
    return $path
}

function Write-XaoLogRecord {
    [CmdletBinding()]
    param([string]$Path,[string]$Message,[string]$Type='INFO')
    if (-not $Path) { return }
    try {
        # Console output is bounded in the GUI; the file keeps the complete record.
        $line = '[{0}] [{1}] {2}{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Type,$Message,[Environment]::NewLine
        [IO.File]::AppendAllText($Path,$line,[Text.UTF8Encoding]::new($false))
    } catch {
        # Logging must never recursively call itself or hide the original error.
        if (-not $script:XaoLogWarningShown) { $script:XaoLogWarningShown=$true; Write-Warning "Registro no disponible: $($_.Exception.Message)" }
    }
}

function Get-XaoSystemDisk {
    param([string]$DriveLetter = $env:SystemDrive.TrimEnd(':'))
    $type='Desconocido'; $name='No disponible'; $health='No disponible'
    try {
        $disk = Get-Partition -DriveLetter $DriveLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop | Select-Object -First 1
        if ($disk) {
            $name=$disk.FriendlyName; $health=[string]$disk.HealthStatus
            $physical = @(Get-PhysicalDisk -ErrorAction Stop | Where-Object {
                $_.UniqueId -and $disk.UniqueId -and $_.UniqueId.Trim() -eq $disk.UniqueId.Trim()
            })
            if ($physical.Count -eq 1 -and $physical[0].MediaType -in @('SSD','HDD','SCM')) { $type=[string]$physical[0].MediaType }
        }
    } catch { }
    [pscustomobject]@{ Drive=$DriveLetter+':'; Name=$name; MediaType=$type; HealthStatus=$health }
}

function Get-XaoRegistryJournalPath {
    if (-not $script:XaoRegistryJournal) {
        $folder=Join-Path $env:LOCALAPPDATA 'XaoTools\RegistryBackups'
        New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
        $script:XaoRegistryJournal=Join-Path $folder ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+[guid]::NewGuid().ToString('N')+'.jsonl')
    }
    return $script:XaoRegistryJournal
}

function Save-XaoRegistryValue {
    param([string]$Path,[string]$Name)
    $exists=$false; $kind=$null; $value=$null
    if (Test-Path -LiteralPath $Path) {
        $key=Get-Item -LiteralPath $Path -ErrorAction Stop
        if ($key.GetValueNames() -contains $Name) {
            $exists=$true
            $kind=$key.GetValueKind($Name).ToString()
            $value=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
    }
    $entry=[pscustomobject]@{ Version=1; Time=(Get-Date -Format o); Path=$Path; Name=$Name; Existed=$exists; Kind=$kind; Value=$value }
    $journal=Get-XaoRegistryJournalPath
    # Abort the mutation if its backup cannot be saved.
    [IO.File]::AppendAllText($journal,($entry | ConvertTo-Json -Compress -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
    return $journal
}

function Restore-XaoRegistryJournal {
    [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
    param([Parameter(Mandatory=$true)][string]$Path)
    $records=@(Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Where-Object { $_.Trim() } | ForEach-Object { $_ | ConvertFrom-Json -ErrorAction Stop })
    if (-not $records.Count) { throw 'La copia esta vacia.' }
    foreach ($record in $records) {
        if ($record.Version -ne 1 -or $record.Path -notmatch '^HK(CU|LM):\\' -or [string]::IsNullOrWhiteSpace($record.Name)) { throw 'Formato de copia no valido.' }
        if ($record.Existed -isnot [bool]) { throw 'Estado del valor no valido.' }
        if ($record.Existed -and $record.Kind -notin @('String','ExpandString','Binary','DWord','MultiString','QWord')) { throw 'Tipo de registro no admitido.' }
        if($record.Existed){
            $validated=switch($record.Kind){
                'Binary'{,([byte[]]$record.Value)}
                'MultiString'{,([string[]]$record.Value)}
                'DWord'{[int]$record.Value}
                'QWord'{[long]$record.Value}
                default{[string]$record.Value}
            }
            $record | Add-Member -NotePropertyName RestoredValue -NotePropertyValue $validated -Force
        }
    }
    if (-not $PSCmdlet.ShouldProcess($Path,'Restaurar los valores de registro guardados (no servicios ni archivos)')) { return }
    Invoke-XaoExclusive {
        for ($index=$records.Count-1; $index -ge 0; $index--) {
            $record=$records[$index]
            if ($record.Existed) {
                $value=$record.RestoredValue
                if (-not (Test-Path -LiteralPath $record.Path)) { New-Item -Path $record.Path -Force -ErrorAction Stop | Out-Null }
                New-ItemProperty -LiteralPath $record.Path -Name $record.Name -Value $value -PropertyType $record.Kind -Force -ErrorAction Stop | Out-Null
            } elseif (Test-Path -LiteralPath $record.Path) {
                $key=Get-Item -LiteralPath $record.Path -ErrorAction Stop
                if ($key.GetValueNames() -contains $record.Name) { Remove-ItemProperty -LiteralPath $record.Path -Name $record.Name -ErrorAction Stop }
            }
        }
    }
}

$script:XaoSharedFunctions = @('Invoke-XaoNative','Set-XaoRegistryValue','Enable-XaoUltimatePower','Reset-XaoWindowsUpdate','Reset-XaoPrintQueue','Clear-XaoTemp','Get-XaoRustDeskAsset','Install-XaoRustDesk','Install-XaoPackage','Update-XaoPackages','Test-XaoCancellation','Enter-XaoOperation','Invoke-XaoExclusive','Initialize-XaoLog','Write-XaoLogRecord','Get-XaoSystemDisk','Get-XaoRegistryJournalPath','Save-XaoRegistryValue','Restore-XaoRegistryJournal')
# END XAO COMMON

$ErrorActionPreference = "Stop"

# Asegurar codificacion UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Elevacion automatica de Administrador
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        if (-not $PSCommandPath) { throw 'La version en memoria requiere abrir PowerShell como Administrador antes de ejecutarla.' }
        $child=Start-Process powershell.exe -ArgumentList "-STA -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs -Wait -PassThru
        exit $child.ExitCode
    } catch {
        Write-Host "No se pudo abrir XaoToolbox con permisos de administrador: $_" -ForegroundColor Red
        exit 1
    }
}

# Cargar librerias de interfaz grafica WPF
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ------------------------------------------------------------------------------
# DEFINICION DEL DISENO VISUAL XAML (ESTILO DARK MODE ELEGANTE)
# ------------------------------------------------------------------------------
$xamlString = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="XaoToolbox v1.2 - Xaoxay Labs"
        Height="760" Width="1100" MinHeight="620" MinWidth="980"
        WindowStartupLocation="CenterScreen"
        Background="#18181b" Foreground="#f4f4f5"
        FontFamily="Segoe UI, Segoe UI Variable Text, Arial">

    <Window.Resources>
        <!-- Estilo de Botones Principales -->
        <Style x:Key="ModernButton" TargetType="Button">
            <Setter Property="Background" Value="#27272a"/>
            <Setter Property="Foreground" Value="#f4f4f5"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="14,8"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="BorderBrush" Value="#3f3f46"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border" Background="{TemplateBinding Background}"
                                BorderBrush="{TemplateBinding BorderBrush}"
                                BorderThickness="{TemplateBinding BorderThickness}"
                                CornerRadius="6" SnapsToDevicePixels="True">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"
                                              Margin="{TemplateBinding Padding}"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsEnabled" Value="False"><Setter TargetName="border" Property="Opacity" Value="0.45"/></Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#3f3f46"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#52525b"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="border" Property="Opacity" Value="0.5"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- Boton de Accion Verde -->
        <Style x:Key="ActionButtonGreen" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#059669"/>
            <Setter Property="BorderBrush" Value="#10b981"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Boton de Accion Celeste/Azul -->
        <Style x:Key="ActionButtonCyan" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#0284c7"/>
            <Setter Property="BorderBrush" Value="#38bdf8"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Boton de Accion Violeta -->
        <Style x:Key="ActionButtonPurple" TargetType="Button" BasedOn="{StaticResource ModernButton}">
            <Setter Property="Background" Value="#7c3aed"/>
            <Setter Property="BorderBrush" Value="#a78bfa"/>
            <Setter Property="Foreground" Value="#ffffff"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>

        <!-- Estilo de Tarjetas (Cards) -->
        <Style x:Key="CardBorder" TargetType="Border">
            <Setter Property="Background" Value="#27272a"/>
            <Setter Property="BorderBrush" Value="#3f3f46"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="CornerRadius" Value="8"/>
            <Setter Property="Padding" Value="14"/>
            <Setter Property="Margin" Value="6"/>
        </Style>

        <!-- Estilo de CheckBoxes -->
        <Style TargetType="CheckBox">
            <Setter Property="Foreground" Value="#f4f4f5"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Margin" Value="0,4,0,4"/>
            <Setter Property="Cursor" Value="Hand"/>
        </Style>

        <!-- Estilo de Pestañas (TabControl) -->
        <Style TargetType="TabItem">
            <Setter Property="Foreground" Value="#a1a1aa"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="18,10"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TabItem">
                        <Border x:Name="tabBorder" Background="Transparent"
                                BorderBrush="Transparent" BorderThickness="0,0,0,3"
                                Margin="4,0" Padding="{TemplateBinding Padding}">
                            <ContentPresenter ContentSource="Header"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsSelected" Value="True">
                                <Setter TargetName="tabBorder" Property="BorderBrush" Value="#06b6d4"/>
                                <Setter Property="Foreground" Value="#22d3ee"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Foreground" Value="#ffffff"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/> <!-- Cabecera / Header -->
            <RowDefinition Height="*"/>    <!-- Contenido de Pestanas -->
            <RowDefinition Height="140"/>  <!-- Consola de Log en vivo -->
            <RowDefinition Height="Auto"/> <!-- Barra de Estado inferior -->
        </Grid.RowDefinitions>

        <!-- CABECERA PRINCIPAL -->
        <Border Grid.Row="0" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,0,0,1" Padding="20,12">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <StackPanel Grid.Column="0" VerticalAlignment="Center">
                    <StackPanel Orientation="Horizontal">
                        <TextBlock Text="XAOWIN TOOLBOX" FontSize="20" FontWeight="Bold" Foreground="#38bdf8"/>
                        <Border Background="#06b6d4" CornerRadius="4" Margin="10,0,0,0" Padding="6,2" VerticalAlignment="Center">
                            <TextBlock Text="v1.2" FontSize="11" FontWeight="Bold" Foreground="#000000"/>
                        </Border>
                    </StackPanel>
                    <TextBlock Text="Xaoxay Labs  •  Instalador de Software, Optimizador &amp; Reparador de Windows"
                               FontSize="12" Foreground="#71717a" Margin="0,2,0,0"/>
                </StackPanel>

                <!-- Resumen rapido del equipo -->
                <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgePCName" Text="Equipo: Windows PC" FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgeRAM" Text="RAM: ..." FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                    <Border Background="#27272a" CornerRadius="6" Padding="10,6" Margin="4,0">
                        <TextBlock x:Name="BadgeDisk" Text="Disco del sistema: ..." FontSize="12" Foreground="#e4e4e7"/>
                    </Border>
                </StackPanel>
            </Grid>
        </Border>

        <!-- PESTANAS (TAB CONTROL) -->
        <TabControl Grid.Row="1" Background="#18181b" BorderThickness="0" Margin="12,6,12,0">

            <!-- PESTANA 1: INSTALAR PROGRAMAS -->
            <TabItem Header="📦 Instalar Programas">
                <Grid Margin="0,10,0,0">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/> <!-- Barra de Presets -->
                        <RowDefinition Height="*"/>    <!-- Tarjetas de Programas -->
                        <RowDefinition Height="Auto"/> <!-- Botones de Accion -->
                    </Grid.RowDefinitions>

                    <!-- Barra de Seleccion Rapida -->
                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="6,0,6,10">
                        <Button x:Name="BtnSelectEssential" Content="⭐ Marcar Pack Basico (Chrome, 7-Zip, VLC, Adobe PDF)"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnSelectAllApps" Content="Seleccionar Todo"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnClearApps" Content="Desmarcar Todo"
                                Style="{StaticResource ModernButton}"/>
                    </StackPanel>

                    <!-- Tarjetas de Categorias (Scrollable) -->
                    <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                        <UniformGrid Columns="3" Margin="0,0,0,10">

                            <!-- Tarjeta 1: Navegadores -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🌐 Navegadores Web" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkChrome" Content="Google Chrome"/>
                                    <CheckBox x:Name="ChkFirefox" Content="Mozilla Firefox"/>
                                    <CheckBox x:Name="ChkBrave" Content="Brave Browser (Anti-Ads)"/>
                                    <CheckBox x:Name="ChkOpera" Content="Opera One"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 2: Compresores y Archivos -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="📦 Compresores &amp; Archivos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="Chk7Zip" Content="7-Zip (Gratis &amp; Liviano)"/>
                                    <CheckBox x:Name="ChkWinRAR" Content="WinRAR"/>
                                    <CheckBox x:Name="ChkNotepadPP" Content="Notepad++ (Editor util)"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 3: Multimedia -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🎬 Multimedia &amp; Musica" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkVLC" Content="VLC Media Player"/>
                                    <CheckBox x:Name="ChkSpotify" Content="Spotify"/>
                                    <CheckBox x:Name="ChkKLite" Content="K-Lite Codec Pack"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 4: Ofimatica y Lectura -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="📄 Documentos &amp; Oficina" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkAdobe" Content="Adobe Acrobat Reader (PDF)"/>
                                    <CheckBox x:Name="ChkLibreOffice" Content="LibreOffice (Ofimatica Gratis)"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 5: Comunicacion -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="💬 Comunicacion &amp; Redes" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkDiscord" Content="Discord"/>
                                    <CheckBox x:Name="ChkTelegram" Content="Telegram Desktop"/>
                                    <CheckBox x:Name="ChkWhatsApp" Content="WhatsApp Desktop"/>
                                    <CheckBox x:Name="ChkZoom" Content="Zoom Workplace"/>
                                </StackPanel>
                            </Border>

                            <!-- Tarjeta 6: Soporte & Gaming -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🎮 Gaming &amp; Soporte Remoto" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkAnyDesk" Content="AnyDesk (Soporte Remoto)"/>
                                    <CheckBox x:Name="ChkRustDesk" Content="RustDesk"/>
                                    <CheckBox x:Name="ChkSteam" Content="Steam"/>
                                    <CheckBox x:Name="ChkVSCode" Content="Visual Studio Code"/>
                                </StackPanel>
                            </Border>

                        </UniformGrid>
                    </ScrollViewer>

                    <!-- Botones de Accion Inferiores -->
                    <Border Grid.Row="2" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="0,10,0,6">
                        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
                            <Button x:Name="BtnUpgradeAll" Content="🔄 ACTUALIZAR TODOS MIS PROGRAMAS"
                                    Style="{StaticResource ActionButtonCyan}" Margin="0,0,10,0"/>
                            <Button x:Name="BtnInstallSelected" Content="🚀 INSTALAR PROGRAMAS MARCADOS"
                                    Style="{StaticResource ActionButtonGreen}"/>
                        </StackPanel>
                    </Border>
                </Grid>
            </TabItem>

            <!-- PESTANA 2: OPTIMIZACIONES & TWEAKS -->
            <TabItem Header="⚡ Optimizaciones (Tweaks)">
                <Grid Margin="0,10,0,0">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/> <!-- Presets -->
                        <RowDefinition Height="*"/>    <!-- Casillas de Tweaks -->
                        <RowDefinition Height="Auto"/> <!-- Boton Aplicar -->
                    </Grid.RowDefinitions>

                    <!-- Botones de Presets -->
                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="6,0,6,10">
                        <Button x:Name="BtnPresetDesktop" Content="💻 Recomendado PC Escritorio"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnPresetLaptop" Content="🔋 Recomendado Notebook"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnPresetGaming" Content="🎮 Ajustes para juegos"
                                Style="{StaticResource ModernButton}" Margin="0,0,8,0"/>
                        <Button x:Name="BtnClearTweaks" Content="Desmarcar Todo"
                                Style="{StaticResource ModernButton}"/>
                    </StackPanel>

                    <!-- Contenedores de Opciones -->
                    <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                        <UniformGrid Columns="3" Margin="0,0,0,10">

                            <!-- Privacidad y Telemetria -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🛡️ Privacidad &amp; Telemetria" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkRestorePoint" Content="Crear Punto de Restauracion previo" IsChecked="True"/>
                                    <CheckBox x:Name="ChkDisableTelemetry" Content="Limitar datos de diagnostico"/>
                                    <CheckBox x:Name="ChkDisableStartAds" Content="Quitar Publicidad del Menu Inicio"/>
                                    <CheckBox x:Name="ChkDisableActivityHistory" Content="Desactivar Historial de Actividad"/>
                                    <CheckBox x:Name="ChkDisableWifiSense" Content="Desactivar Wi-Fi Sense"/>
                                </StackPanel>
                            </Border>

                            <!-- Rendimiento y Juegos -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="⚡ Rendimiento &amp; Juegos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkDisableGameDVR" Content="Desactivar GameDVR (Menos tirones)"/>
                                    <CheckBox x:Name="ChkDisableMouseAccel" Content="Desactivar Aceleracion del Mouse (1:1)"/>
                                    <CheckBox x:Name="ChkNetworkLatency" Content="Ajustar TCP (experimental)"/>
                                    <CheckBox x:Name="ChkMaxPerformancePlan" Content="Activar Plan 'Maximo Rendimiento'"/>
                                    <CheckBox x:Name="ChkDisableHibernation" Content="Desactivar Hibernacion (Libera disco)"/>
                                </StackPanel>
                            </Border>

                            <!-- Limpieza y Servicios -->
                            <Border Style="{StaticResource CardBorder}">
                                <StackPanel>
                                    <TextBlock Text="🧹 Limpieza &amp; Servicios" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                    <CheckBox x:Name="ChkServicesManual" Content="Pasar Servicios Innecesarios a Manual"/>
                                    <CheckBox x:Name="ChkCleanTemp" Content="Limpiar Archivos Temporales de Windows"/>
                                    <CheckBox x:Name="ChkEmptyRecycle" Content="Vaciar Papelera de Reciclaje"/>
                                </StackPanel>
                            </Border>

                        </UniformGrid>
                    </ScrollViewer>

                    <!-- Boton Aplicar -->
                    <Border Grid.Row="2" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="0,10,0,6">
                        <Button x:Name="BtnApplyTweaks" Content="⚡ APLICAR OPTIMIZACIONES SELECCIONADAS"
                                Style="{StaticResource ActionButtonPurple}" HorizontalAlignment="Right"/>
                    </Border>
                </Grid>
            </TabItem>

            <!-- PESTANA 3: REPARACIONES DEL SISTEMA -->
            <TabItem Header="🛠️ Reparaciones (Fixes)">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <UniformGrid Columns="2" Margin="0,0,0,10">

                        <!-- Reparacion DISM / SFC -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🔧 Reparar Archivos de Sistema (DISM + SFC)" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Comprueba y repara la imagen y los archivos protegidos de Windows. El resultado depende del daño encontrado; revise la salida."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixDISM" Content="Ejecutar DISM + SFC" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion Windows Update -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🔄 Reparar Windows Update Trabado" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Detiene los servicios, purga la carpeta SoftwareDistribution de actualizaciones corruptas y reinicia la descarga limpia."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixWindowsUpdate" Content="Reparar Actualizaciones" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion de Red e Internet -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🌐 Reparar Red, Internet &amp; DNS" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Reinicia la pila TCP/IP, resetea el catalogo Winsock, vacia la cache DNS y renueva los adaptadores de red."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixNetwork" Content="Restablecer Red" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparacion Microsoft Store -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🏪 Reparar Microsoft Store &amp; Apps Nativas" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Ejecuta wsreset para reiniciar la tienda oficial y registra nuevamente las aplicaciones del sistema que no abren."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixStore" Content="Reparar Tienda" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Reparar Iconos y Explorer -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🗂️ Reparar Explorador &amp; Cache de Iconos" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Borra la memoria temporal de iconos en blanco, miniaturas corruptas y reinicia el explorador en 1 segundo."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixExplorer" Content="Reparar Iconos" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                        <!-- Desatascar Impresion -->
                        <Border Style="{StaticResource CardBorder}">
                            <Grid>
                                <Grid.RowDefinitions>
                                    <RowDefinition Height="Auto"/>
                                    <RowDefinition Height="*"/>
                                    <RowDefinition Height="Auto"/>
                                </Grid.RowDefinitions>
                                <TextBlock Grid.Row="0" Text="🖨️ Desatascar Cola de Impresion" FontSize="15" FontWeight="Bold" Foreground="#38bdf8"/>
                                <TextBlock Grid.Row="1" Text="Elimina trabajos y documentos trabados en la memoria de la impresora que impiden imprimir nuevos archivos."
                                           TextWrapping="Wrap" Foreground="#a1a1aa" FontSize="12" Margin="0,6,0,12"/>
                                <Button Grid.Row="2" x:Name="BtnFixSpooler" Content="Desatascar Impresora" Style="{StaticResource ModernButton}" HorizontalAlignment="Left"/>
                            </Grid>
                        </Border>

                    </UniformGrid>
                </ScrollViewer>
            </TabItem>

            <!-- PESTANA 4: CONFIGURACION & UTILIDADES -->
            <TabItem Header="⚙️ Configuracion &amp; Accesos">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <StackPanel Margin="0,0,0,10">

                        <!-- Personalizacion Rapida -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🎨 Personalizacion de Windows" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnDarkMode" Content="🌙 Activar Modo Oscuro" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnLightMode" Content="☀️ Activar Modo Claro" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnShowExtensions" Content="👁️ Mostrar Extensiones (.exe, .txt)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnShowHidden" Content="📂 Mostrar Archivos Ocultos" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                        <!-- Componentes Opcionales -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🧩 Componentes de Windows" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnEnableDotNet" Content="📦 Habilitar .NET 3.5" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnEnableWSL" Content="🐧 Habilitar WSL (Linux)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnEnableSandbox" Content="🛡️ Habilitar Windows Sandbox" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                        <Border Style="{StaticResource CardBorder}">
    <StackPanel>
        <TextBlock Text="Copias de ajustes" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
        <TextBlock Text="Se guardan los valores del registro antes de cambiarlos. Estas copias no revierten archivos, programas ni servicios." TextWrapping="Wrap" Foreground="#a1a1aa" Margin="0,0,0,10"/>
        <WrapPanel>
            <Button x:Name="BtnRestoreRegistry" Content="Restaurar valores del registro..." Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
            <Button x:Name="BtnOpenBackups" Content="Abrir carpeta de copias" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
        </WrapPanel>
    </StackPanel>
</Border>
<!-- Accesos Directos Clasicos -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🛠️ Herramientas Administrativas Nativas" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <WrapPanel>
                                    <Button x:Name="BtnToolDevMgmt" Content="Administrador de Dispositivos" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolTaskMgr" Content="Administrador de Tareas" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolNCPA" Content="Conexiones de Red (ncpa.cpl)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolServices" Content="Servicios de Windows" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolRegedit" Content="Editor de Registro (regedit)" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                    <Button x:Name="BtnToolMSConfig" Content="Configuracion de Sistema" Style="{StaticResource ModernButton}" Margin="0,0,8,6"/>
                                </WrapPanel>
                            </StackPanel>
                        </Border>

                    </StackPanel>
                </ScrollViewer>
            </TabItem>

            <!-- PESTANA 5: DIAGNOSTICO DE MI PC -->
            <TabItem Header="📊 Mi PC (Diagnostico)">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,10,0,0">
                    <UniformGrid Columns="2" Margin="0,0,0,10">

                        <!-- Tarjeta Sistema & Chasis -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="💻 Informacion General" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysPC" Text="Equipo: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysOS" Text="Sistema: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysFormFactor" Text="Tipo: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Hardware CPU & RAM -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="⚡ Procesador &amp; Memoria" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysCPU" Text="CPU: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysRAM" Text="RAM: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysSlots" Text="Ranuras de RAM: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Almacenamiento -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="💾 Disco Principal" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysDiskType" Text="Tipo: ..." FontSize="13" Margin="0,3"/>
                                <TextBlock x:Name="LblSysDiskSpace" Text="Espacio: ..." FontSize="13" Margin="0,3"/>
                            </StackPanel>
                        </Border>

                        <!-- Tarjeta Bateria / Energia -->
                        <Border Style="{StaticResource CardBorder}">
                            <StackPanel>
                                <TextBlock Text="🔋 Bateria &amp; Energia" FontSize="15" FontWeight="Bold" Foreground="#38bdf8" Margin="0,0,0,8"/>
                                <TextBlock x:Name="LblSysBattery" Text="Bateria: ..." FontSize="13" Margin="0,3"/>
                                <Button x:Name="BtnBatteryReport" Content="Generar Reporte de Salud de Bateria"
                                        Style="{StaticResource ModernButton}" Margin="0,10,0,0" HorizontalAlignment="Left"/>
                            </StackPanel>
                        </Border>

                    </UniformGrid>
                </ScrollViewer>
            </TabItem>

        </TabControl>

        <!-- CONSOLA DE REGISTRO EN TIEMPO REAL -->
        <Border Grid.Row="2" Background="#09090b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="14,8">
            <Grid>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="*"/>
                </Grid.RowDefinitions>

                <!-- Cabecera de la consola -->
                <Grid Grid.Row="0" Margin="0,0,0,4">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Text=">_ REGISTRO DE ACTIVIDAD EN VIVO" FontSize="11" FontWeight="Bold" Foreground="#71717a" VerticalAlignment="Center"/>
                    <StackPanel Grid.Column="1" Orientation="Horizontal">
                        <Button x:Name="BtnOpenLog" Content="Abrir registro" Style="{StaticResource ModernButton}" Padding="8,2" FontSize="11" Margin="0,0,6,0"/>
                        <Button x:Name="BtnClearLog" Content="Limpiar" Style="{StaticResource ModernButton}" Padding="8,2" FontSize="11" Margin="0,0,6,0"/>
                        <Button x:Name="BtnCopyLog" Content="Copiar" Style="{StaticResource ModernButton}" Padding="8,2" FontSize="11"/>
                    </StackPanel>
                </Grid>

                <!-- Cuadro de Texto de la Consola -->
                <TextBox Grid.Row="1" x:Name="TxtConsoleLog" Background="#09090b" Foreground="#d4d4d8"
                         BorderThickness="0" FontFamily="Consolas, Lucida Console, Courier New" FontSize="12"
                         IsReadOnly="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"
                         TextWrapping="Wrap"/>
            </Grid>
        </Border>

        <!-- BARRA DE ESTADO INFERIOR -->
        <Border Grid.Row="3" Background="#18181b" BorderBrush="#27272a" BorderThickness="0,1,0,0" Padding="14,4">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock x:Name="TxtStatus" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" Text="Listo. Selecciona una opcion para comenzar." FontSize="11" Foreground="#a1a1aa"/>
                <StackPanel Grid.Column="1" Orientation="Horizontal" Margin="12,0,0,0">
                    <ProgressBar x:Name="JobProgress" Width="65" Height="5" Visibility="Collapsed" Margin="0,0,10,0"/>
                    <TextBlock x:Name="TxtElapsed" Text="00:00:00" FontSize="11" Foreground="#d4d4d8" VerticalAlignment="Center" Margin="0,0,10,0"/>
                    <Button x:Name="BtnCancelJob" Content="Detener entre pasos" IsEnabled="False" Style="{StaticResource ModernButton}" FontSize="11" Padding="8,3"
                            ToolTip="Espera a que termine el comando actual. Conserva los cambios ya realizados."/>
                </StackPanel>
            </Grid>
        </Border>
    </Grid>
</Window>
'@

# ------------------------------------------------------------------------------
# PARSEAR XAML Y OBTENER VENTANA
# ------------------------------------------------------------------------------
$script:XaoLogFile = Initialize-XaoLog 'XaoToolbox'
$reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xamlString))
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# ------------------------------------------------------------------------------
# MAPEO AUTOMATICO DE CONTROLES
# ------------------------------------------------------------------------------
$controls = @(
    "BadgePCName", "BadgeRAM", "BadgeDisk",
    "BtnSelectEssential", "BtnSelectAllApps", "BtnClearApps",
    "ChkChrome", "ChkFirefox", "ChkBrave", "ChkOpera",
    "Chk7Zip", "ChkWinRAR", "ChkNotepadPP",
    "ChkVLC", "ChkSpotify", "ChkKLite",
    "ChkAdobe", "ChkLibreOffice",
    "ChkDiscord", "ChkTelegram", "ChkWhatsApp", "ChkZoom",
    "ChkAnyDesk", "ChkRustDesk", "ChkSteam", "ChkVSCode",
    "BtnInstallSelected", "BtnUpgradeAll",
    "BtnPresetDesktop", "BtnPresetLaptop", "BtnPresetGaming", "BtnClearTweaks",
    "ChkRestorePoint", "ChkDisableTelemetry", "ChkDisableStartAds", "ChkDisableActivityHistory", "ChkDisableWifiSense",
    "ChkDisableGameDVR", "ChkDisableMouseAccel", "ChkNetworkLatency", "ChkMaxPerformancePlan", "ChkDisableHibernation",
    "ChkServicesManual", "ChkCleanTemp", "ChkEmptyRecycle",
    "BtnApplyTweaks",
    "BtnFixDISM", "BtnFixWindowsUpdate", "BtnFixNetwork", "BtnFixStore", "BtnFixExplorer", "BtnFixSpooler",
    "BtnDarkMode", "BtnLightMode", "BtnShowExtensions", "BtnShowHidden",
    "BtnEnableDotNet", "BtnEnableWSL", "BtnEnableSandbox", "BtnRestoreRegistry", "BtnOpenBackups",
    "BtnToolDevMgmt", "BtnToolTaskMgr", "BtnToolNCPA", "BtnToolServices", "BtnToolRegedit", "BtnToolMSConfig",
    "LblSysPC", "LblSysOS", "LblSysFormFactor", "LblSysCPU", "LblSysRAM", "LblSysSlots", "LblSysDiskType", "LblSysDiskSpace", "LblSysBattery", "BtnBatteryReport",
    "BtnClearLog", "BtnCopyLog", "BtnOpenLog", "BtnCancelJob", "JobProgress", "TxtElapsed", "TxtConsoleLog", "TxtStatus"
)

$UI = @{}
foreach ($ctrlName in $controls) {
    $UI[$ctrlName] = $window.FindName($ctrlName)
}

# ------------------------------------------------------------------------------
# LOGGING Y ESTADO THREAD-SAFE (DISPATCHER)
# ------------------------------------------------------------------------------
function Log {
    param([string]$Message,[string]$Type='INFO')
    Write-XaoLogRecord -Path $script:XaoLogFile -Message $Message -Type $Type
    $line='[{0}] [{1}] {2}' -f (Get-Date -Format 'HH:mm:ss'),$Type,$Message
    if($line.Length -gt 6000){$line=$line.Substring(0,6000)+' ... (completo en el archivo de registro)'}
    $box=$UI['TxtConsoleLog']
    if($box.Text.Length -gt 120000){$box.Text=$box.Text.Substring($box.Text.Length-80000)}
    $box.AppendText($line+"`r`n");$box.ScrollToEnd()
    $UI['TxtStatus'].Text=$Message
    $UI['TxtStatus'].ToolTip=$Message
    $UI['TxtStatus'].Foreground=switch($Type){'ERROR'{'#fca5a5'} 'WARNING'{'#fcd34d'} 'SUCCESS'{'#86efac'} default{'#d4d4d8'}}
}

# ------------------------------------------------------------------------------
# EJECUCION EN SEGUNDO PLANO PARA NO CONGELAR LA VENTANA
# ------------------------------------------------------------------------------
function Start-XaoWorker {
    param([scriptblock]$Action,[hashtable]$Context=@{})
    $queue=[Collections.Concurrent.ConcurrentQueue[object]]::new()
    $cancel=[Threading.CancellationTokenSource]::new()
    $session=[Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    foreach($name in $script:XaoSharedFunctions){
        $session.Commands.Add([Management.Automation.Runspaces.SessionStateFunctionEntry]::new($name,(Get-Command $name -CommandType Function -ErrorAction Stop).Definition))
    }
    # Function-only harnesses can load the runtime without executing its list assignment.
    if(-not $script:XaoSharedFunctions){
        foreach($fn in Get-Command -CommandType Function | Where-Object Name -match '^(Invoke-Xao|Enter-Xao|Test-Xao|Initialize-Xao|Write-Xao|Get-Xao|Save-Xao|Restore-Xao|Set-Xao|Enable-Xao|Reset-Xao|Clear-Xao|Install-Xao|Update-Xao)'){
            $session.Commands.Add([Management.Automation.Runspaces.SessionStateFunctionEntry]::new($fn.Name,$fn.Definition))
        }
    }
    $runspace=[RunspaceFactory]::CreateRunspace($session)
    $runspace.ApartmentState='STA'; $runspace.ThreadOptions='ReuseThread'
    $ps=[PowerShell]::Create()
    try {
        $runspace.Open()
        foreach($key in $Context.Keys){
            if($key -in @('XaoQueue','XaoCancel','ErrorActionPreference')){throw "Nombre de contexto reservado: $key"}
            $runspace.SessionStateProxy.SetVariable($key,$Context[$key])
        }
        $runspace.SessionStateProxy.SetVariable('XaoQueue',$queue)
        $runspace.SessionStateProxy.SetVariable('XaoCancel',$cancel)
        $ps.Runspace=$runspace
        [void]$ps.AddScript(@'
$ErrorActionPreference='Stop'
function Log {
    param([string]$Message,[string]$Type='INFO')
    $XaoQueue.Enqueue([pscustomobject]@{Message=$Message;Type=$Type})
}
'@)
        [void]$ps.AddScript("Invoke-XaoExclusive {`n"+$Action.ToString()+"`n}")
        $handle=$ps.BeginInvoke()
        [pscustomobject]@{PowerShell=$ps;Runspace=$runspace;Handle=$handle;Queue=$queue;Cancel=$cancel;Started=(Get-Date);InformationIndex=0;WarningIndex=0;ErrorCount=0;WarningCount=0;Name='Operacion'}
    } catch {$ps.Dispose();$runspace.Dispose();$cancel.Dispose();throw}
}

function Set-XaoBusy {
    param([bool]$Busy)
    if($Busy){
        $script:XaoEnabledControls=@{}
        foreach($key in $UI.Keys){
            if(($UI[$key] -is [Windows.Controls.Button] -or $UI[$key] -is [Windows.Controls.CheckBox]) -and $key -notin @('BtnCopyLog','BtnClearLog','BtnOpenLog','BtnCancelJob')){
                $script:XaoEnabledControls[$key]=$UI[$key].IsEnabled
                $UI[$key].IsEnabled=$false
            }
        }
    } else {
        foreach($key in $script:XaoEnabledControls.Keys){$UI[$key].IsEnabled=$script:XaoEnabledControls[$key]}
    }
    $UI['BtnCancelJob'].IsEnabled=$Busy
    $UI['JobProgress'].IsIndeterminate=$Busy
    $UI['JobProgress'].Visibility=$(if($Busy){'Visible'}else{'Collapsed'})
}

function Run-Async {
    param([scriptblock]$Action,[hashtable]$Context=@{},[string]$Name='Operacion')
    if($script:XaoJob){Log 'Espere a que termine la operacion actual.' 'WARNING';return}
    $snapshot=@{}
    foreach($key in $UI.Keys){if($UI[$key] -is [Windows.Controls.CheckBox]){$snapshot[$key]=@{IsChecked=[bool]$UI[$key].IsChecked}}}
    $Context['UI']=$snapshot
    $script:XaoJob=Start-XaoWorker -Action $Action -Context $Context
    $script:XaoJob.Name=$Name
    Set-XaoBusy $true
    Log "$Name iniciada." 'INFO'
    $script:XaoTimer.Start()
}

function Receive-XaoWorker {
    $job=$script:XaoJob
    if(-not $job){return}
    $elapsed=(Get-Date)-$job.Started
    $UI['TxtElapsed'].Text=$elapsed.ToString('hh\:mm\:ss')
    $item=$null
    $limit=0
    while($limit -lt 120 -and $job.Queue.TryDequeue([ref]$item)){
        if($item.Type -eq 'ERROR'){$job.ErrorCount++}
        if($item.Type -eq 'WARNING'){$job.WarningCount++}
        Log $item.Message $item.Type
        $limit++
    }
    # Large native output is drained over multiple dispatcher ticks, without monopolizing the UI.
    if($job.Queue.Count){return}
    while($job.InformationIndex -lt $job.PowerShell.Streams.Information.Count){
        Log ([string]$job.PowerShell.Streams.Information[$job.InformationIndex]) 'INFO'
        $job.InformationIndex++
        if(++$limit -ge 200){return}
    }
    while($job.WarningIndex -lt $job.PowerShell.Streams.Warning.Count){
        Log ([string]$job.PowerShell.Streams.Warning[$job.WarningIndex]) 'WARNING'
        $job.WarningIndex++;$job.WarningCount++
        if(++$limit -ge 200){return}
    }
    if(-not $job.Handle.IsCompleted){return}
    try {
        $output=$job.PowerShell.EndInvoke($job.Handle)
        foreach($line in $output){if($null -ne $line){Log ([string]$line) 'INFO'}}
        # Recheck the final queue: a producer can enqueue after the first drain.
        while($job.Queue.TryDequeue([ref]$item)){
            if($item.Type -eq 'ERROR'){$job.ErrorCount++};if($item.Type -eq 'WARNING'){$job.WarningCount++}
            Log $item.Message $item.Type
        }
        if($job.PowerShell.HadErrors){throw (($job.PowerShell.Streams.Error | ForEach-Object {$_.ToString()}) -join ' | ')}
        if($job.ErrorCount){Log "Finalizada con $($job.ErrorCount) errores y $($job.WarningCount) avisos. Consulte el registro." 'ERROR'}
        elseif($job.WarningCount){Log "Finalizada con $($job.WarningCount) avisos. Consulte el registro." 'WARNING'}
        else {Log 'Operacion finalizada. Consulte los resultados de cada paso.' 'SUCCESS'}
    } catch {
        $exception=$_.Exception
        $cancelled=$false
        while($exception){if($exception -is [OperationCanceledException]){$cancelled=$true;break};$exception=$exception.InnerException}
        if($cancelled){Log 'Detenida entre pasos. Los cambios ya realizados se conservan.' 'WARNING'}
        else {Log "Operacion fallida: $($_.Exception.Message)" 'ERROR'}
    } finally {
        $script:XaoTimer.Stop()
        $job.PowerShell.Dispose();$job.Runspace.Dispose();$job.Cancel.Dispose()
        $script:XaoJob=$null
        Set-XaoBusy $false
    }
}

$script:XaoJob=$null
$script:XaoTimer=[Windows.Threading.DispatcherTimer]::new()
$script:XaoTimer.Interval=[TimeSpan]::FromMilliseconds(150)
$script:XaoTimer.Add_Tick({try{Receive-XaoWorker}catch{Log "Error al mostrar el progreso: $($_.Exception.Message)" 'ERROR'}})
$window.Add_Closing({
    param($sender,$eventArgs)
    if($script:XaoJob){$eventArgs.Cancel=$true;Log 'Hay una tarea en curso. Puede solicitar detenerla al terminar el paso actual.' 'WARNING'}
    else{$script:XaoTimer.Stop()}
})
$UI['BtnCancelJob'].Add_Click({
    if($script:XaoJob){
        $script:XaoJob.Cancel.Cancel()
        $UI['BtnCancelJob'].IsEnabled=$false
        Log 'Detencion solicitada. Se espera al comando actual; no se interrumpira una reparacion en curso.' 'WARNING'
    }
})
$UI['BtnOpenLog'].Add_Click({
    try {if($script:XaoLogFile -and (Test-Path -LiteralPath $script:XaoLogFile)){Start-Process notepad.exe -ArgumentList "`"$script:XaoLogFile`""}}
    catch{Log $_.Exception.Message 'ERROR'}
})


# ------------------------------------------------------------------------------
# DETECCION Y CARGA DE HARDWARE (TAB 5 Y HEADER)
# ------------------------------------------------------------------------------
function Load-HardwareInfo {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
        $drives = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(":")) -ErrorAction Stop
        $diskType=(Get-XaoSystemDisk).MediaType
        $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1

        $totalRAM = [Math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        $freeRAM = [Math]::Round($os.FreePhysicalMemory / 1MB, 1)
        $totalDisk = [Math]::Round(($drives.Used + $drives.Free) / 1GB, 1)
        $freeDisk = [Math]::Round($drives.Free / 1GB, 1)

        $isLaptop = ($cs.PCSystemType -eq 2) -or ($battery -ne $null)
        $chassis = if ($isLaptop) { "Notebook / Laptop" } else { "PC de Escritorio" }

        # Ranuras de memoria
        $memDevices = Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue
        $memArray = Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue
        $slotsUsed = @($memDevices | Where-Object { $_ }).Count
        $slotsTotal = if ($memArray) { ($memArray | Measure-Object -Property MemoryDevices -Sum).Sum } else { "No disponible" }

        # Asignar a la interfaz
        $UI["BadgePCName"].Text = "PC: $($cs.Name)"
        $UI["BadgeRAM"].Text = "RAM: $totalRAM GB ($freeRAM GB libres)"
        $UI["BadgeDisk"].Text = "Disco $env:SystemDrive $freeDisk GB libres"

        $UI["LblSysPC"].Text = "Equipo: $($cs.Name) ($($cs.Manufacturer) $($cs.Model))"
        $UI["LblSysOS"].Text = "Sistema: $($os.Caption) (Build $($os.BuildNumber))"
        $UI["LblSysFormFactor"].Text = "Form Factor: $chassis"
        $UI["LblSysCPU"].Text = "Procesador: $($cpu.Name) ($($cpu.NumberOfCores) Nucleos, $($cpu.NumberOfLogicalProcessors) Hilos)"
        $UI["LblSysRAM"].Text = "Memoria RAM: $totalRAM GB instalados ($freeRAM GB libres)"
        $UI["LblSysSlots"].Text = "Ranuras de RAM: $slotsUsed de $slotsTotal ocupadas"
        $UI["LblSysDiskType"].Text = "Tecnologia de Disco: $diskType"
        $UI["LblSysDiskSpace"].Text = "Espacio Disco $env:SystemDrive $freeDisk GB libres de $totalDisk GB totales"

        if ($battery) {
            $UI["LblSysBattery"].Text = "Bateria: $($battery.EstimatedChargeRemaining)% de carga (Conectado a corriente: $($battery.BatteryStatus -eq 2))"
        } else {
            $UI["LblSysBattery"].Text = "Bateria: Windows no informa una bateria disponible"
        }

        Log "Informacion de hardware cargada exitosamente: $($cs.Name) [$chassis]" "SUCCESS"
    } catch {
        Log "Aviso al cargar info de hardware: $_" "WARNING"
    }
}

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 1: INSTALADOR DE SOFTWARE (WINGET)
# ------------------------------------------------------------------------------
$appMap = @{
    "ChkChrome"      = @{ Id = "Google.Chrome"; Name = "Google Chrome" };
    "ChkFirefox"     = @{ Id = "Mozilla.Firefox"; Name = "Mozilla Firefox" };
    "ChkBrave"       = @{ Id = "Brave.Brave"; Name = "Brave Browser" };
    "ChkOpera"       = @{ Id = "Opera.Opera"; Name = "Opera One" };
    "Chk7Zip"        = @{ Id = "7zip.7zip"; Name = "7-Zip" };
    "ChkWinRAR"      = @{ Id = "RARLab.WinRAR"; Name = "WinRAR" };
    "ChkNotepadPP"   = @{ Id = "Notepad++.Notepad++"; Name = "Notepad++" };
    "ChkVLC"         = @{ Id = "VideoLAN.VLC"; Name = "VLC Media Player" };
    "ChkSpotify"     = @{ Id = "9NCBCSZSJRSB"; Source = "msstore"; Name = "Spotify" };
    "ChkKLite"       = @{ Id = "CodecGuide.K-LiteCodecPack.Standard"; Name = "K-Lite Codec Pack" };
    "ChkAdobe"       = @{ Id = "Adobe.Acrobat.Reader.64-bit"; Name = "Adobe Acrobat Reader" };
    "ChkLibreOffice" = @{ Id = "TheDocumentFoundation.LibreOffice"; Name = "LibreOffice" };
    "ChkDiscord"     = @{ Id = "Discord.Discord"; Name = "Discord" };
    "ChkTelegram"    = @{ Id = "Telegram.TelegramDesktop"; Name = "Telegram Desktop" };
    "ChkWhatsApp"    = @{ Id = "9NKSQGP7F2NH"; Name = "WhatsApp Desktop"; Source = "msstore" };
    "ChkZoom"        = @{ Id = "Zoom.Zoom"; Name = "Zoom Workplace" };
    "ChkAnyDesk"     = @{ Id = "AnyDesk.AnyDesk"; Name = "AnyDesk" };
    "ChkRustDesk"    = @{ Id = "RustDesk.RustDesk"; Name = "RustDesk" };
    "ChkSteam"       = @{ Id = "Valve.Steam"; Name = "Steam" };
    "ChkVSCode"      = @{ Id = "Microsoft.VisualStudioCode"; Name = "Visual Studio Code" }
}

# Boton Marcar Pack Basico
$UI["BtnSelectEssential"].Add_Click({
    try {
    $UI["BtnClearApps"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkChrome"].IsChecked = $true
    $UI["Chk7Zip"].IsChecked = $true
    $UI["ChkVLC"].IsChecked = $true
    $UI["ChkAdobe"].IsChecked = $true
    Log "Pack Basico marcado: Chrome, 7-Zip, VLC, Adobe Acrobat Reader" "INFO"
    } catch { Log $_.Exception.Message "ERROR" }
})

# Boton Seleccionar Todo
$UI["BtnSelectAllApps"].Add_Click({
    try {
    foreach ($k in ($appMap.Keys | Sort-Object)) {
        if ($UI[$k]) { $UI[$k].IsChecked = $true }
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Boton Desmarcar Todo
$UI["BtnClearApps"].Add_Click({
    try {
    foreach ($k in ($appMap.Keys | Sort-Object)) {
        if ($UI[$k]) { $UI[$k].IsChecked = $false }
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Boton Instalar Programas Marcados
$UI["BtnInstallSelected"].Add_Click({
    try {
    $selected = @()
    foreach ($k in ($appMap.Keys | Sort-Object)) {
        if ($UI[$k] -and $UI[$k].IsChecked) {
            $selected += $appMap[$k]
        }
    }

    if ($selected.Count -eq 0) {
        [System.Windows.MessageBox]::Show("Por favor marca al menos un programa para instalar.", "XaoToolbox", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information)
        return
    }

    Run-Async -Name 'Instalacion de programas' -Context @{selected=$selected} -Action {
        Log "Iniciando instalacion por lotes de $($selected.Count) programas..." "INFO"
        $failed=0
        foreach ($app in $selected) {
            Test-XaoCancellation
            Log "Descargando e instalando $($app.Name)..." "INFO"
            try {
                $source = if ($app.Source) { $app.Source } else { 'winget' }
                $result = Install-XaoPackage -Id $app.Id -Source $source
                Log "$($app.Name): $($result.Status)." $(if ($result.Status -eq 'RebootRequired') { 'WARNING' } else { 'SUCCESS' })
            } catch [OperationCanceledException] { throw } catch { $failed++; Log $_.Exception.Message 'ERROR' }
        }
        Log "Lote terminado: $($selected.Count - $failed) correctos; $failed fallidos." $(if ($failed) { "WARNING" } else { "SUCCESS" })
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Boton Actualizar Todos los Programas
$UI["BtnUpgradeAll"].Add_Click({
    try {
    Run-Async -Name 'Actualizacion de programas' {
        Log "Buscando y actualizando TODOS los programas instalados en la PC..." "INFO"
        Update-XaoPackages
        Log "Actualizacion general completada con exito." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 2: OPTIMIZACIONES (TWEAKS)
# ------------------------------------------------------------------------------

# Presets de Tweaks
$UI["BtnPresetDesktop"].Add_Click({
    try {
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkDisableStartAds"].IsChecked = $true
    $UI["ChkDisableActivityHistory"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $false
    $UI["ChkMaxPerformancePlan"].IsChecked = $true
    $UI["ChkDisableHibernation"].IsChecked = $true
    $UI["ChkServicesManual"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $false
    Log "Preset 'PC de Escritorio' seleccionado." "INFO"
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnPresetLaptop"].Add_Click({
    try {
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkDisableStartAds"].IsChecked = $true
    $UI["ChkDisableActivityHistory"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $false
    $UI["ChkServicesManual"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $false
    # Para laptop mantenemos hibernacion activa
    $UI["ChkDisableHibernation"].IsChecked = $false
    Log "Preset 'Notebook' seleccionado (Cuidado de bateria activado)." "INFO"
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnPresetGaming"].Add_Click({
    try {
    $UI["BtnClearTweaks"].RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $UI["ChkRestorePoint"].IsChecked = $true
    $UI["ChkDisableGameDVR"].IsChecked = $true
    $UI["ChkDisableMouseAccel"].IsChecked = $true
    $UI["ChkNetworkLatency"].IsChecked = $false
    $UI["ChkMaxPerformancePlan"].IsChecked = $true
    $UI["ChkDisableTelemetry"].IsChecked = $true
    $UI["ChkCleanTemp"].IsChecked = $false
    Log "Preset 'Modo Gaming' seleccionado (ajustes para juegos; el resultado depende del equipo)." "INFO"
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnClearTweaks"].Add_Click({
    try {
    $tweaksList = @(
        "ChkRestorePoint", "ChkDisableTelemetry", "ChkDisableStartAds", "ChkDisableActivityHistory", "ChkDisableWifiSense",
        "ChkDisableGameDVR", "ChkDisableMouseAccel", "ChkNetworkLatency", "ChkMaxPerformancePlan", "ChkDisableHibernation",
        "ChkServicesManual", "ChkCleanTemp", "ChkEmptyRecycle"
    )
    foreach ($t in $tweaksList) {
        if ($UI[$t]) { $UI[$t].IsChecked = $false }
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Aplicar Optimizaciones Marcadas
$UI["BtnApplyTweaks"].Add_Click({
    try {
    if ($UI['ChkEmptyRecycle'].IsChecked -and [Windows.MessageBox]::Show('Se eliminara el contenido de la papelera. Continuar?', 'Vaciar papelera', 'YesNo', 'Warning') -ne 'Yes') { return }
    Run-Async -Name 'Aplicacion de ajustes' {
        # 1. Punto de Restauracion
        Test-XaoCancellation
        if ($UI["ChkRestorePoint"].IsChecked) {
            Log "Creando punto de restauracion de seguridad..." "INFO"
            try {
                Checkpoint-Computer -Description "XaoToolbox_PreTweaks" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
                Log "Punto de restauracion creado con exito." "SUCCESS"
            } catch {
                Log "Aviso: No se pudo crear punto de restauracion (Restauracion desactivada en Windows)." "WARNING"
            }
        }

        # 2. Telemetria
        Test-XaoCancellation
        if ($UI["ChkDisableTelemetry"].IsChecked) {
            Log "Desactivando telemetria y diagnosticos de Windows..." "INFO"
            Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 1 -Type DWord -Force -ErrorAction Stop
            Stop-Service -Name "DiagTrack" -Force -ErrorAction Stop
            Set-Service -Name "DiagTrack" -StartupType Disabled -ErrorAction Stop
            Log "Politica de datos de diagnostico ajustada. Su alcance depende de la edicion de Windows." "INFO"
        }

        # 3. Publicidad en Inicio
        Test-XaoCancellation
        if ($UI["ChkDisableStartAds"].IsChecked) {
            Log "Quitando sugerencias y publicidad del Menu Inicio..." "INFO"
            Set-XaoRegistryValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SystemPaneSuggestionsEnabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338388Enabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Log "Publicidad del Menu Inicio eliminada." "SUCCESS"
        }

        # 4. Historial de Actividad
        Test-XaoCancellation
        if ($UI["ChkDisableActivityHistory"].IsChecked) {
            Log "Desactivando historial de actividad..." "INFO"
            Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableActivityFeed" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "PublishUserActivities" -Value 0 -Type DWord -Force -ErrorAction Stop
            Log "Historial de actividad desactivado." "SUCCESS"
        }

        # 5. Wi-Fi Sense
        Test-XaoCancellation
        if ($UI["ChkDisableWifiSense"].IsChecked) {
            Log "Desactivando Wi-Fi Sense..." "INFO"
            Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting" -Name "value" -Value 0 -Type DWord -Force -ErrorAction Stop
            Log "Wi-Fi Sense desactivado." "SUCCESS"
        }

        # 6. GameDVR
        Test-XaoCancellation
        if ($UI["ChkDisableGameDVR"].IsChecked) {
            Log "Desactivando GameDVR (Grabacion en segundo plano de juegos)..." "INFO"
            Set-XaoRegistryValue -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -Value 0 -Type DWord -Force -ErrorAction Stop
            Log "Grabacion GameDVR desactivada." "SUCCESS"
        }

        # 7. Aceleracion de Mouse (1:1)
        Test-XaoCancellation
        if ($UI["ChkDisableMouseAccel"].IsChecked) {
            Log "Configurando precision de puntero de mouse 1:1..." "INFO"
            Set-XaoRegistryValue -Path "HKCU:\Control Panel\Mouse" -Name "MouseSpeed" -Value "0" -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold1" -Value "0" -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold2" -Value "0" -Force -ErrorAction Stop
            Log "Precision de mouse optimizada para gaming." "SUCCESS"
        }

        # 8. Latencia de Red (Nagle)
        Test-XaoCancellation
        if ($UI["ChkNetworkLatency"].IsChecked) {
            Log "Optimizando latencia de paquetes TCP de red..." "INFO"
            $interfaces = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" -ErrorAction SilentlyContinue
            foreach ($iface in $interfaces) {
                Set-XaoRegistryValue -Path $iface.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -ErrorAction Stop
                Set-XaoRegistryValue -Path $iface.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -ErrorAction Stop
            }
            Log "Parametros TCP aplicados. El efecto depende de la aplicacion y la red." "SUCCESS"
        }

        # 9. Plan Maximo Rendimiento
        Test-XaoCancellation
        if ($UI["ChkMaxPerformancePlan"].IsChecked) {
            Log "Activando plan de energia de Maximo Rendimiento..." "INFO"
            Enable-XaoUltimatePower
            Log "Plan Maximo Rendimiento activado en el sistema." "SUCCESS"
        }

        # 10. Desactivar Hibernacion
        Test-XaoCancellation
        if ($UI["ChkDisableHibernation"].IsChecked) {
            Log "Desactivando hibernacion para liberar espacio en disco..." "INFO"
            Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('/hibernate','off') | Out-Null
            Log "Hibernacion desactivada. Puede cambiar el inicio rapido de Windows; para revertir: powercfg /hibernate on." "SUCCESS"
        }

        # 11. Servicios a Manual
        Test-XaoCancellation
        if ($UI["ChkServicesManual"].IsChecked) {
            Log "Ajustando servicios innecesarios a inicio manual..." "INFO"
            $services = @("XblAuthManager", "XblGameSave", "XboxNetApiSvc", "MapsBroker", "Fax")
            foreach ($s in $services) {
                if (-not (Get-Service -Name $s -ErrorAction SilentlyContinue)) { Log "Servicio $s no instalado; omitido." "INFO"; continue }
                Set-Service -Name $s -StartupType Manual -ErrorAction Stop
            }
            Log "Servicios ajustados a manual." "SUCCESS"
        }

        # 12. Limpieza de Temporales
        Test-XaoCancellation
        if ($UI["ChkCleanTemp"].IsChecked) {
            Log "Limpiando archivos temporales..." "INFO"
            $result = Clear-XaoTemp
            Log "Temporales: $($result.Removed) eliminados; $($result.Skipped) omitidos; $([math]::Round($result.Bytes/1MB,2)) MB recuperados." 'INFO' 
        }

        # 13. Vaciar Papelera
        Test-XaoCancellation
        if ($UI["ChkEmptyRecycle"].IsChecked) {
            Log "Vaciando papelera de reciclaje..." "INFO"
            try {
                Clear-RecycleBin -Force -ErrorAction Stop
                Log "Papelera vaciada." "SUCCESS"
            } catch [OperationCanceledException] { throw } catch { Log $_.Exception.Message "WARNING" }
        }

        Test-XaoCancellation
        Log "Ajustes procesados. Revise los resultados y avisos de cada operacion." "INFO"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 3: REPARACIONES DEL SISTEMA (FIXES)
# ------------------------------------------------------------------------------

# DISM + SFC
$UI["BtnFixDISM"].Add_Click({
    try {
    Run-Async -Name 'DISM y SFC' {
        Log "Iniciando reparacion de archivos de sistema con DISM y SFC..." "INFO"
        Log "Paso 1/2: Analizando y reparando imagen de Windows (DISM RestoreHealth)..." "INFO"
        Invoke-XaoNative -FilePath 'dism.exe' -ArgumentList @('/Online','/Cleanup-Image','/RestoreHealth','/NoRestart') -SuccessCodes @(0,3010)
        Log "DISM completado. Paso 2/2: Verificando integridad de archivos (SFC Scannow)..." "INFO"
        Invoke-XaoNative -FilePath 'sfc.exe' -ArgumentList @('/scannow')
        Log "Comandos DISM y SFC finalizados. Revise la salida y CBS.log para saber si quedan archivos sin reparar." "INFO"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Windows Update Fix
$UI["BtnFixWindowsUpdate"].Add_Click({
    try {
    Run-Async -Name 'Restablecimiento de Windows Update' {
        Reset-XaoWindowsUpdate
        Log 'Cache restablecida y servicios restaurados. Compruebe Windows Update.' 'SUCCESS' 
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Red e Internet Fix
$UI["BtnFixNetwork"].Add_Click({
    try {
    Run-Async -Name 'Restablecimiento de red' {
        Log "Restableciendo catalogo Winsock..." "INFO"
        Invoke-XaoNative -FilePath 'netsh' -ArgumentList @('winsock','reset') | Out-Null
        Log "Restableciendo protocolo TCP/IP..." "INFO"
        Invoke-XaoNative -FilePath 'netsh' -ArgumentList @('int','ip','reset') | Out-Null
        Log "Vaciando cache de resolucion DNS..." "INFO"
        Invoke-XaoNative -FilePath 'ipconfig' -ArgumentList @('/flushdns') | Out-Null
        Log "Red e Internet restablecidos exitosamente (Se recomienda reiniciar la PC)." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Microsoft Store Fix
$UI["BtnFixStore"].Add_Click({
    try {
    Run-Async -Name 'Cache de Microsoft Store' {
        Log "Reiniciando Microsoft Store (wsreset)..." "INFO"
        Invoke-XaoNative wsreset.exe @()
        Log "Microsoft Store y cache de aplicaciones restablecidas." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Iconos y Explorer Fix
$UI["BtnFixExplorer"].Add_Click({
    try {
    Run-Async -Name 'Cache de iconos' {
        Log "Deteniendo proceso del Explorador de Windows..." "INFO"
        Get-Process -Name explorer -ErrorAction Stop | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } | Stop-Process -Force -ErrorAction Stop
        Start-Sleep -Seconds 1
        try {
            Log "Purgando base de datos de cache de iconos..." "INFO"
            $iconCache = "$env:LOCALAPPDATA\IconCache.db"
            if (Test-Path $iconCache) { Remove-Item -LiteralPath $iconCache -Force -ErrorAction Stop }
        } finally { Start-Process explorer.exe }
        Log "Explorador de Windows e iconos restaurados." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Cola de Impresion Fix
$UI["BtnFixSpooler"].Add_Click({
    try {
    if ([Windows.MessageBox]::Show('Se eliminaran todos los trabajos pendientes de impresion. Continuar?', 'Cola de impresion', 'YesNo', 'Warning') -ne 'Yes') { return }
    Run-Async -Name 'Cola de impresion' {
        Reset-XaoPrintQueue
        Log 'Trabajos de impresion pendientes eliminados; servicio restaurado.' 'SUCCESS' 
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 4: CONFIGURACION Y UTILIDADES
# ------------------------------------------------------------------------------

# Modo Oscuro
$UI["BtnDarkMode"].Add_Click({
    try {
    Set-XaoRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "AppsUseLightTheme" -Value 0 -Type DWord -Force
    Set-XaoRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "SystemUsesLightTheme" -Value 0 -Type DWord -Force
    Log "Modo Oscuro de Windows activado." "SUCCESS"
    } catch { Log $_.Exception.Message "ERROR" }
})

# Modo Claro
$UI["BtnLightMode"].Add_Click({
    try {
    Set-XaoRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "AppsUseLightTheme" -Value 1 -Type DWord -Force
    Set-XaoRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "SystemUsesLightTheme" -Value 1 -Type DWord -Force
    Log "Modo Claro de Windows activado." "SUCCESS"
    } catch { Log $_.Exception.Message "ERROR" }
})

# Mostrar Extensiones
$UI["BtnShowExtensions"].Add_Click({
    try {
    Set-XaoRegistryValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -Value 0 -Type DWord -Force
    Log "Extensiones de archivo visibles (.exe, .pdf, .txt, etc.)." "SUCCESS"
    } catch { Log $_.Exception.Message "ERROR" }
})

# Mostrar Ocultos
$UI["BtnShowHidden"].Add_Click({
    try {
    Set-XaoRegistryValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Hidden" -Value 1 -Type DWord -Force
    Log "Archivos y carpetas ocultas ahora son visibles." "SUCCESS"
    } catch { Log $_.Exception.Message "ERROR" }
})

# Componentes Opcionales
$UI["BtnEnableDotNet"].Add_Click({
    try {
    Run-Async -Name '.NET Framework 3.5' {
        Log "Habilitando .NET Framework 3.5..." "INFO"
        Invoke-XaoNative -FilePath 'dism.exe' -ArgumentList @('/Online','/Enable-Feature','/FeatureName:NetFx3','/All','/NoRestart') -SuccessCodes @(0,3010)
        Log ".NET Framework 3.5 completado." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnEnableWSL"].Add_Click({
    try {
    Run-Async -Name 'Windows Subsystem for Linux' {
        Log "Instalando / Habilitando Windows Subsystem for Linux (WSL)..." "INFO"
        Invoke-XaoNative -FilePath 'wsl' -ArgumentList @('--install','--no-distribution')
        Log "WSL configurado." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnEnableSandbox"].Add_Click({
    try {
    Run-Async -Name 'Windows Sandbox' {
        Log "Habilitando Windows Sandbox..." "INFO"
        Invoke-XaoNative -FilePath 'dism.exe' -ArgumentList @('/Online','/Enable-Feature','/FeatureName:Containers-DisposableClientVM','-All','/NoRestart') -SuccessCodes @(0,3010)
        Log "Windows Sandbox habilitado." "SUCCESS"
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI['BtnRestoreRegistry'].Add_Click({
    try {
        $dialog=[Microsoft.Win32.OpenFileDialog]::new()
        $dialog.Title='Seleccionar copia de valores del registro'
        $dialog.Filter='Copias Xao (*.jsonl)|*.jsonl'
        $dialog.InitialDirectory=Join-Path $env:LOCALAPPDATA 'XaoTools\RegistryBackups'
        if($dialog.ShowDialog($window) -ne $true){return}
        if([Windows.MessageBox]::Show('Se restableceran los valores guardados en esta copia. No se desharan instalaciones, eliminaciones de archivos ni cambios de servicios. Continuar?', 'Restaurar valores del registro', 'YesNo', 'Warning') -ne 'Yes'){return}
        Run-Async -Name 'Restauracion de valores del registro' -Context @{journalPath=$dialog.FileName} -Action {
            Restore-XaoRegistryJournal -Path $journalPath -Confirm:$false
            Log 'Valores de registro restaurados. Algunas preferencias requieren cerrar sesion.' 'SUCCESS'
        }
    } catch {Log $_.Exception.Message 'ERROR'}
})
$UI['BtnOpenBackups'].Add_Click({
    try {
        $folder=Join-Path $env:LOCALAPPDATA 'XaoTools\RegistryBackups'
        if(Test-Path -LiteralPath $folder){Start-Process explorer.exe -ArgumentList "`"$folder`""}
        else{Log 'Todavia no se generaron copias de valores del registro.' 'INFO'}
    } catch {Log $_.Exception.Message 'ERROR'}
})

# Herramientas Clasicas
$UI["BtnToolDevMgmt"].Add_Click({ try { Start-Process "devmgmt.msc" } catch { Log $_.Exception.Message "ERROR" } })
$UI["BtnToolTaskMgr"].Add_Click({ try { Start-Process "taskmgr.exe" } catch { Log $_.Exception.Message "ERROR" } })
$UI["BtnToolNCPA"].Add_Click({ try { Start-Process "ncpa.cpl" } catch { Log $_.Exception.Message "ERROR" } })
$UI["BtnToolServices"].Add_Click({ try { Start-Process "services.msc" } catch { Log $_.Exception.Message "ERROR" } })
$UI["BtnToolRegedit"].Add_Click({ try { Start-Process "regedit.exe" } catch { Log $_.Exception.Message "ERROR" } })
$UI["BtnToolMSConfig"].Add_Click({ try { Start-Process "msconfig.exe" } catch { Log $_.Exception.Message "ERROR" } })

# ------------------------------------------------------------------------------
# LOGICA DE LA PESTANA 5: DIAGNOSTICO Y REPORTE DE BATERIA
# ------------------------------------------------------------------------------
$UI["BtnBatteryReport"].Add_Click({
    try {
    $reportPath = Join-Path $env:TEMP "BatteryReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
    Run-Async -Name 'Informe de bateria' -Context @{reportPath=$reportPath} -Action {
        Log "Generando reporte de salud de bateria..." "INFO"
        Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('/batteryreport','/output',"$reportPath") | Out-Null
        if (Test-Path $reportPath) {
            Log "Reporte de bateria generado: $reportPath" "SUCCESS"
            Start-Process "$reportPath"
        } else {
            Log "No se pudo generar reporte (Solo disponible en Notebooks con bateria)." "WARNING"
        }
    }
    } catch { Log $_.Exception.Message "ERROR" }
})

# Botones de Log
$UI["BtnClearLog"].Add_Click({
    try {
    $UI["TxtConsoleLog"].Clear()
    Log "Vista del registro limpiada; el archivo de la sesion se conserva." "INFO"
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI["BtnCopyLog"].Add_Click({
    try {
    [System.Windows.Clipboard]::SetText($UI["TxtConsoleLog"].Text)
    Log "Registro copiado al portapapeles." "SUCCESS"
    } catch { Log $_.Exception.Message "ERROR" }
})

$UI['ChkDisableWifiSense'].IsEnabled = $false
$UI['ChkDisableWifiSense'].IsChecked = $false
$UI['ChkDisableWifiSense'].ToolTip = 'Wi-Fi Sense no es un ajuste aplicable a las versiones actuales de Windows.'
$workArea=[Windows.SystemParameters]::WorkArea
if($workArea.Height -lt $window.Height){$window.MinHeight=[Math]::Min($window.MinHeight,$workArea.Height);$window.Height=$workArea.Height}
if($workArea.Width -lt $window.Width){$window.MinWidth=[Math]::Min($window.MinWidth,$workArea.Width);$window.Width=$workArea.Width}
# Iniciar carga de info de hardware y mostrar ventana
Load-HardwareInfo
Log "XaoToolbox v1.2 listo. Selecciona una opcion o pestana para comenzar." "SUCCESS"

[void]$window.ShowDialog()
