@echo off
title Iniciando XaoSleep...
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Filter '*.exe' | Unblock-File" 2>nul
start "" "%~dp0XaoSleep.exe"
