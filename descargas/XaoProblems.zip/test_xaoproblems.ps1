﻿<#
.SYNOPSIS
    Suite de pruebas automatizadas para XaoProblems
#>
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$scriptRoot = $PSScriptRoot
$ps1Path = Join-Path $scriptRoot "XaoProblems.ps1"
$batPath = Join-Path $scriptRoot "XaoProblems.bat"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "       SUITE DE PRUEBAS AUTOMATIZADAS: XAO PROBLEMS       " -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan

$passed = 0
$failed = 0

function Assert-Test {
    param(
        [string]$Name,
        [scriptblock]$Condition
    )
    Write-Host -NoNewline " [*] Probando: $Name... "
    try {
        $result = & $Condition
        if ($result -eq $true) {
            Write-Host "[PASO]" -ForegroundColor Green
            $script:passed++
        } else {
            Write-Host "[FALLO]" -ForegroundColor Red
            $script:failed++
        }
    } catch {
        Write-Host "[ERROR]: $_" -ForegroundColor Red
        $script:failed++
    }
}

# 1. Test de Sintaxis de XaoProblems.ps1
Assert-Test "Sintaxis de XaoProblems.ps1" {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($ps1Path, [ref]$tokens, [ref]$errors)
    return ($errors.Count -eq 0)
}

# 2. Test de Sintaxis del híbrido XaoProblems.bat
Assert-Test "Sintaxis de XaoProblems.bat (Hibrido)" {
    $content = [System.IO.File]::ReadAllText($batPath, [System.Text.Encoding]::UTF8)
    $hasHeader = $content.StartsWith("<# :")
    $hasCloser = $content.Contains("exit /b %XAO_EXIT%`r`n#>") -or $content.Contains("exit /b %XAO_EXIT%`n#>")
    return ($hasHeader -and $hasCloser)
}

# Cargar funciones en memoria (sin ejecutar el bucle interactivo)
$psCode = Get-Content -Path $ps1Path -Raw -Encoding UTF8
$functionBlock = $psCode.Substring(0, $psCode.IndexOf('# Inicio del programa'))
. ([scriptblock]::Create($functionBlock))

# 3. Test de Funciones Críticas
$expectedFunctions = @(
    "Get-SystemInfo",
    "Write-Log",
    "Repair-WindowsFiles",
    "Repair-WindowsUpdate",
    "Repair-StoreAndApps",
    "Repair-ExplorerAndIcons",
    "Repair-PrintSpooler",
    "Repair-NetworkStack",
    "Clean-JunkFiles",
    "Clean-WinSxSStore",
    "Optimize-BasicSystem",
    "Manage-LaptopBattery",
    "Manage-DesktopPower",
    "Diagnose-Disks",
    "Run-OneClickMaintenance",
    "Show-QuickTools",
    "Show-MainMenu",
    "Invoke-ProcessWithTimer",
    "Disable-ConsoleQuickEdit"
)

foreach ($fn in $expectedFunctions) {
    Assert-Test "Existencia de funcion '$fn'" {
        return (Get-Command -Name $fn -ErrorAction SilentlyContinue) -ne $null
    }
}

# 4. Test de Obtencion de Informacion del Sistema (Get-SystemInfo)
$sys = $null
Assert-Test "Ejecucion y consistencia de Get-SystemInfo" {
    $script:sys = Get-SystemInfo
    $validOS = $sys.OSName -match "Windows"
    $validCPU = -not [string]::IsNullOrWhiteSpace($sys.CPU)
    $validRAM = $sys.TotalRAM -gt 0 -and $sys.FreeRAM -ge 0
    $validDisk = -not [string]::IsNullOrWhiteSpace($sys.Drive)
    $validChassis = ($sys.IsLaptop -eq $true -or $sys.IsLaptop -eq $false)
    return ($validOS -and $validCPU -and $validRAM -and $validDisk -and $validChassis)
}

# 5. Test del Sistema de Log (Write-Log)
Assert-Test "Escritura en archivo de Log (Write-Log)" {
    $testMsg = "TEST_AUTOMATIZADO_$(Get-Random)"
    Write-Log -Message $testMsg -Type "INFO"
    $logContent = Get-Content -Path $LogFile -Raw -ErrorAction SilentlyContinue
    return ($logContent -match $testMsg)
}

# 6. Test de Rutas de Limpieza Segura
Assert-Test "Resolucion de rutas para Limpieza Segura" {
    $tempUser = [System.IO.Path]::GetFullPath($env:TEMP)
    $tempWin = [System.IO.Path]::GetFullPath("$env:SystemRoot\Temp")
    return ((Test-Path $tempUser) -and (Test-Path $tempWin))
}

# 7. Test de Modulo de Energia / Form Factor
Assert-Test "Compatibilidad de Modulo de Energia con el equipo" {
    if ($sys.IsLaptop) {
        # Para laptop debe existir bateria o chasis portatil
        return ($sys.HasBattery -or $sys.IsLaptop)
    } else {
        # Para escritorio no debe haber bateria obligatoria
        return ($sys.IsLaptop -eq $false)
    }
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " RESULTADOS DE LAS PRUEBAS:" -ForegroundColor Yellow
Write-Host "  Pruebas superadas : $passed" -ForegroundColor Green
Write-Host "  Pruebas fallidas  : $failed" -ForegroundColor $(if ($failed -gt 0) { "Red" } else { "Green" })
Write-Host "==========================================================" -ForegroundColor Cyan

if ($failed -eq 0) {
    Write-Host " [PRUEBAS BASICAS OK] Estas pruebas no certifican instalaciones ni reparaciones reales.`n" -ForegroundColor Green
    exit 0
} else {
    Write-Host " [ALERTA] Se encontraron errores en los tests.`n" -ForegroundColor Red
    exit 1
}
