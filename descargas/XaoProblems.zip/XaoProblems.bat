﻿<# :
@echo off
setlocal EnableDelayedExpansion
title Xao Problems - Inicializando...

:: Comprobar permisos de Administrador
net session >nul 2>&1
if %errorlevel% NEQ 0 (
    echo.
    echo  [!] Solicitando permisos de Administrador para Xao Problems...
    echo.
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \"\"%~dpnx0\"\"' -Verb RunAs"
    exit /b
)

:: Cambiar al directorio del script
cd /d "%~dp0"

:: Ejecutar PowerShell incrustado con Bypass y codificacion UTF-8
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Invoke-Expression ([System.IO.File]::ReadAllText('%~f0', [System.Text.Encoding]::UTF8))"

if %errorlevel% NEQ 0 (
    echo.
    echo  [!] La sesion de Xao Problems ha finalizado.
    pause
)
exit /b
#>
<#
.SYNOPSIS
    XaoProblems - Herramienta integral de reparacion y optimizacion para Windows 10 y 11.
    Apta para PCs de escritorio y Notebooks / Laptops.
.AUTHOR
    Xaoxay Labs
#>

# Asegurar codificacion UTF-8 en la consola
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Xao Problems v1.0 - Reparacion & Optimizacion (Windows 10 / 11)"

# Configuracion de archivo de log
$baseDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$LogFile = Join-Path $baseDir "XaoProblems_Log.txt"

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]$identity
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-AdminPrivileges {
    if (-not (Test-IsAdmin) -and -not $env:XAO_SKIP_ELEVATE) {
        $scriptPath = if ($PSCommandPath) { $PSCommandPath } elseif ($PSScriptRoot) { Join-Path $PSScriptRoot "XaoProblems.ps1" } else { (Join-Path $baseDir "XaoProblems.ps1") }
        if (Test-Path $scriptPath) {
            Write-Host "`n [!] Solicitando permisos de Administrador para Xao Problems..." -ForegroundColor Yellow
            try {
                Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
                exit
            } catch {
                Write-Host " [AVISO] Si una funcion requiere permisos, ejecute PowerShell como Administrador." -ForegroundColor Yellow
            }
        } else {
            Write-Host "`n [!] ATENCION: Xao Problems se esta ejecutando en memoria desde la nube." -ForegroundColor Yellow
            Write-Host " Para que las reparaciones criticas (SFC, DISM, Windows Update) funcionen," -ForegroundColor Yellow
            Write-Host " asegurese de haber abierto PowerShell como Administrador.`n" -ForegroundColor Yellow
            Start-Sleep -Seconds 2
        }
    }
}

function Disable-ConsoleQuickEdit {
    try {
        $sig = @"
        using System;
        using System.Runtime.InteropServices;
        public class ConsoleHelper {
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr GetStdHandle(int nStdHandle);
            [DllImport("kernel32.dll")]
            public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
            [DllImport("kernel32.dll")]
            public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
            public static void FixQuickEdit() {
                try {
                    IntPtr h = GetStdHandle(-10);
                    uint mode;
                    if (GetConsoleMode(h, out mode)) {
                        mode &= ~0x0040u;
                        mode &= ~0x0020u;
                        SetConsoleMode(h, mode);
                    }
                } catch {}
            }
        }
"@
        if (-not ([System.Management.Automation.PSTypeName]'ConsoleHelper').Type) {
            Add-Type -TypeDefinition $sig -ErrorAction SilentlyContinue
        }
        [ConsoleHelper]::FixQuickEdit()
    } catch {}
}

function Write-Log {
    param(
        [string]$Message,
        [string]$Type = "INFO"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] [$Type] $Message"
    try {
        Add-Content -Path $LogFile -Value $logLine -ErrorAction SilentlyContinue
    } catch { }

    switch ($Type) {
        "SUCCESS" { Write-Host " [OK] $Message" -ForegroundColor Green }
        "WARNING" { Write-Host " [AVISO] $Message" -ForegroundColor Yellow }
        "ERROR"   { Write-Host " [ERROR] $Message" -ForegroundColor Red }
        "HEADER"  { Write-Host "`n=== $Message ===" -ForegroundColor Cyan }
        default   { Write-Host " [*] $Message" -ForegroundColor White }
    }
}

# -------------------------------------------------------------
# DETECCION DE HARDWARE Y SISTEMA
# -------------------------------------------------------------
function Get-SystemInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    $proc = Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1
    $enclosure = Get-CimInstance -ClassName Win32_SystemEnclosure
    $batteries = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue

    # Detectar Laptop / Notebook
    $isChassisLaptop = $false
    if ($enclosure.ChassisTypes) {
        $isChassisLaptop = $enclosure.ChassisTypes -match '^(8|9|10|11|12|14|18|21|30|31|32)$'
    }
    $hasBattery = ($null -ne $batteries -and $batteries.Count -gt 0)
    $isLaptop = $isChassisLaptop -or $hasBattery

    # Memoria RAM
    $totalRamGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
    $freeRamGB = [math]::Round($os.FreePhysicalMemory / 1MB, 1)

    # Disco de Arranque
    $systemDrive = $env:SystemDrive
    $driveInfo = Get-PSDrive -Name ($systemDrive.Replace(":", ""))
    $freeDiskGB = [math]::Round($driveInfo.Free / 1GB, 1)
    $usedDiskGB = [math]::Round($driveInfo.Used / 1GB, 1)
    $totalDiskGB = $freeDiskGB + $usedDiskGB

    # Tipo de disco fisico (SSD / HDD)
    $diskType = "Desconocido"
    try {
        $pDisk = Get-PhysicalDisk | Where-Object { $_.DeviceID -eq "0" } -ErrorAction SilentlyContinue
        if ($pDisk) { $diskType = $pDisk.MediaType }
    } catch { }

    return [PSCustomObject]@{
        OSName       = $os.Caption
        OSBuild      = $os.BuildNumber
        ComputerName = $cs.Name
        CPU          = $proc.Name.Trim()
        TotalRAM     = $totalRamGB
        FreeRAM      = $freeRamGB
        IsLaptop     = [bool]$isLaptop
        Drive        = $systemDrive
        DiskType     = $diskType
        FreeDiskGB   = $freeDiskGB
        TotalDiskGB  = $totalDiskGB
        HasBattery   = [bool]$hasBattery
    }
}

# -------------------------------------------------------------
# EJECUCION CON TEMPORIZADOR EN VIVO Y ESTIMACION
# -------------------------------------------------------------
function Invoke-ProcessWithTimer {
    param(
        [string]$Command,
        [string]$Arguments,
        [string]$TaskName,
        [string]$EstimatedTime,
        [switch]$ShowDismNotice
    )

    Write-Host " [⏱️ Tiempo estimado: $EstimatedTime]" -ForegroundColor Cyan
    if ($ShowDismNotice) {
        Write-Host " [!] AVISO IMPORTANTE: En DISM es completamente normal que la barra parezca" -ForegroundColor Yellow
        Write-Host "     detenerse varios minutos en el 62% - 64% mientras analiza el almacen WinSxS." -ForegroundColor Yellow
        Write-Host "     El cronometro en la barra de titulo muestra que el proceso sigue activo.`n" -ForegroundColor Yellow
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Command
    $psi.Arguments = $Arguments
    $psi.UseShellExecute = $false

    $proc = [System.Diagnostics.Process]::Start($psi)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while (-not $proc.HasExited) {
        $elapsed = $sw.Elapsed.ToString("mm\:ss")
        $Host.UI.RawUI.WindowTitle = "Xao Problems - $TaskName [Transcurrido: $elapsed | Estimado: $EstimatedTime]"
        Start-Sleep -Milliseconds 1000
    }

    $proc.WaitForExit()
    $sw.Stop()
    $totalElapsed = $sw.Elapsed.ToString("mm\:ss")
    $Host.UI.RawUI.WindowTitle = "Xao Problems v1.0 - Reparacion & Optimizacion (Windows 10 / 11)"

    if ($proc.ExitCode -eq 0) {
        Write-Log "$TaskName completado con exito en $totalElapsed." -Type "SUCCESS"
    } else {
        Write-Log "$TaskName finalizo en $totalElapsed con codigo: $($proc.ExitCode)" -Type "WARNING"
    }

    return $proc.ExitCode
}

# -------------------------------------------------------------
# MODULO 1: REPARACIONES CRITICAS DEL SISTEMA
# -------------------------------------------------------------
function Repair-WindowsFiles {
    Clear-Host
    Write-Log "Iniciando Diagnostico y Reparacion de Archivos del Sistema" -Type "HEADER"
    Write-Host " Esta operacion utilizara DISM y SFC para verificar y reparar el almacen de componentes." -ForegroundColor Gray
    
    $dismEst = if ($sysInfo.DiskType -eq "SSD") { "~5 a 10 minutos (SSD)" } else { "~15 a 30 minutos (HDD)" }
    $sfcEst = if ($sysInfo.DiskType -eq "SSD") { "~2 a 5 minutos (SSD)" } else { "~5 a 15 minutos (HDD)" }

    Write-Log "Paso 1/2: Ejecutando DISM /Online /Cleanup-Image /RestoreHealth..." -Type "INFO"
    Invoke-ProcessWithTimer -Command "dism.exe" -Arguments "/Online /Cleanup-Image /RestoreHealth" -TaskName "DISM RestoreHealth" -EstimatedTime $dismEst -ShowDismNotice

    Write-Host ""
    Write-Log "Paso 2/2: Ejecutando Comprobador de Archivos (sfc /scannow)..." -Type "INFO"
    Invoke-ProcessWithTimer -Command "sfc.exe" -Arguments "/scannow" -TaskName "SFC Scannow" -EstimatedTime $sfcEst

    Pause-Prompt
}

function Repair-WindowsUpdate {
    Clear-Host
    Write-Log "Reparacion Profunda de Windows Update" -Type "HEADER"
    Write-Host " Se detendran los servicios, se vaciara la cache danada y se reiniciaran.`n" -ForegroundColor Gray

    $services = @("wuauserv", "cryptsvc", "bits", "dosvc", "msiserver")
    foreach ($svc in $services) {
        Write-Log "Deteniendo servicio $svc..." -Type "INFO"
        Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
    }

    $distPath = "$env:SystemRoot\SoftwareDistribution"
    $catPath = "$env:SystemRoot\System32\catroot2"

    if (Test-Path $distPath) {
        Write-Log "Vaciando SoftwareDistribution (archivos temporales de updates descargados)..." -Type "INFO"
        try {
            Rename-Item -Path $distPath -NewName "SoftwareDistribution.old_$(Get-Random)" -Force -ErrorAction SilentlyContinue
        } catch {
            Remove-Item -Path "$distPath\*" -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    if (Test-Path $catPath) {
        Write-Log "Purgando catalogo de firmas catroot2..." -Type "INFO"
        try {
            Rename-Item -Path $catPath -NewName "catroot2.old_$(Get-Random)" -Force -ErrorAction SilentlyContinue
        } catch {
            Remove-Item -Path "$catPath\*" -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    foreach ($svc in $services) {
        Write-Log "Iniciando servicio $svc..." -Type "INFO"
        Start-Service -Name $svc -ErrorAction SilentlyContinue
    }

    Write-Log "Windows Update ha sido reiniciado por completo y la cache purgada." -Type "SUCCESS"
    Pause-Prompt
}

function Repair-StoreAndApps {
    Clear-Host
    Write-Log "Reparacion de Microsoft Store y Aplicaciones UWP" -Type "HEADER"
    Write-Host " 1. Limpiando cache de la tienda (wsreset)..." -ForegroundColor Yellow
    try {
        Start-Process "wsreset.exe" -Wait -NoNewWindow
        Write-Log "wsreset ejecutado." -Type "SUCCESS"
    } catch {
        Write-Log "No se pudo ejecutar wsreset: $_" -Type "ERROR"
    }

    Write-Host " 2. Re-registrando aplicaciones base del sistema para el usuario actual..." -ForegroundColor Yellow
    try {
        Get-AppXPackage -AllUsers -ErrorAction SilentlyContinue | Where-Object { $_.InstallLocation -ne $null } | ForEach-Object {
            Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction SilentlyContinue
        }
        Write-Log "Registro de paquetes AppX completado." -Type "SUCCESS"
    } catch {
        Write-Log "Advertencia al re-registrar AppX: $_" -Type "WARNING"
    }
    Pause-Prompt
}

function Repair-ExplorerAndIcons {
    Clear-Host
    Write-Log "Reparacion de Explorador de Archivos y Cache de Iconos/Miniaturas" -Type "HEADER"
    
    Write-Log "Cerrando proceso explorer.exe temporalmente..." -Type "INFO"
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1

    $iconCache = "$env:LOCALAPPDATA\IconCache.db"
    if (Test-Path $iconCache) {
        Remove-Item -Path $iconCache -Force -ErrorAction SilentlyContinue
        Write-Log "IconCache.db eliminado." -Type "SUCCESS"
    }

    $thumbPath = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
    if (Test-Path $thumbPath) {
        Get-ChildItem -Path $thumbPath -Filter "thumbcache_*.db" -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Get-ChildItem -Path $thumbPath -Filter "iconcache_*.db" -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Log "Caches de miniaturas e iconos locales purgadas." -Type "SUCCESS"
    }

    Write-Log "Reiniciando explorer.exe..." -Type "INFO"
    Start-Process "explorer.exe"
    Write-Log "Explorador e interfaz de escritorio restaurados." -Type "SUCCESS"
    Pause-Prompt
}

function Repair-PrintSpooler {
    Clear-Host
    Write-Log "Desatascar Cola de Impresion (Print Spooler)" -Type "HEADER"
    Write-Log "Deteniendo servicio de Cola de Impresion (Spooler)..." -Type "INFO"
    Stop-Service -Name Spooler -Force -ErrorAction SilentlyContinue

    $spoolPath = "$env:SystemRoot\System32\spool\PRINTERS\*"
    Write-Log "Eliminando trabajos de impresion atascados..." -Type "INFO"
    Remove-Item -Path $spoolPath -Force -Recurse -ErrorAction SilentlyContinue

    Write-Log "Reiniciando servicio Spooler..." -Type "INFO"
    Start-Service -Name Spooler -ErrorAction SilentlyContinue
    Write-Log "Cola de impresion desatascada y servicio activo." -Type "SUCCESS"
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 2: REPARACION DE RED E INTERNET
# -------------------------------------------------------------
function Repair-NetworkStack {
    Clear-Host
    Write-Log "Restablecimiento Completo de Red y Conectividad" -Type "HEADER"
    Write-Host " Soluciona caidas de conexion, 'Sin acceso a Internet', errores de DNS y cuellos de botella.`n" -ForegroundColor Gray

    Write-Log "Restableciendo catalogo Winsock (netsh winsock reset)..." -Type "INFO"
    & netsh winsock reset | Out-Null

    Write-Log "Restableciendo pila TCP/IP (netsh int ip reset)..." -Type "INFO"
    & netsh int ip reset | Out-Null

    Write-Log "Vaciando cache de resolucion DNS (ipconfig /flushdns)..." -Type "INFO"
    & ipconfig /flushdns | Out-Null

    Write-Log "Liberando concesion DHCP (ipconfig /release)..." -Type "INFO"
    & ipconfig /release | Out-Null

    Write-Log "Renovando direccion IP (ipconfig /renew)..." -Type "INFO"
    & ipconfig /renew | Out-Null

    Write-Log "Reiniciando adaptadores de red activos..." -Type "INFO"
    Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | ForEach-Object {
        try {
            Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue
            Write-Log "Adaptador '$($_.Name)' reiniciado." -Type "SUCCESS"
        } catch { }
    }

    Write-Host "`n Probando conectividad..." -ForegroundColor Cyan
    $pingGoogle = Test-Connection -ComputerName 8.8.8.8 -Count 2 -Quiet -ErrorAction SilentlyContinue
    if ($pingGoogle) {
        Write-Log "Prueba de conectividad a Internet (Google DNS 8.8.8.8): EXITOSA." -Type "SUCCESS"
    } else {
        Write-Log "Aviso: No hubo respuesta de ping a 8.8.8.8. Puede requerir reiniciar el router o la PC." -Type "WARNING"
    }

    Write-Log "Proceso de red finalizado. Se recomienda reiniciar el equipo al terminar." -Type "SUCCESS"
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 3: LIMPIEZA PROFUNDA SEGURA
# -------------------------------------------------------------
function Clean-JunkFiles {
    Clear-Host
    Write-Log "Limpieza Profunda y Liberacion de Espacio" -Type "HEADER"
    Write-Host " Eliminando temporales, logs viejos, informes de error y cache de descargas.`n" -ForegroundColor Gray

    $totalCleaned = 0

    $cleanTargets = @(
        "$env:TEMP\*",
        "$env:SystemRoot\Temp\*",
        "$env:SystemRoot\Prefetch\*",
        "$env:ProgramData\Microsoft\Windows\WER\ReportArchive\*",
        "$env:ProgramData\Microsoft\Windows\WER\ReportQueue\*",
        "$env:LOCALAPPDATA\CrashDumps\*",
        "$env:SystemRoot\SoftwareDistribution\DeliveryOptimization\*"
    )

    foreach ($target in $cleanTargets) {
        Write-Log "Limpiando: $target..." -Type "INFO"
        try {
            $files = Get-ChildItem -Path $target -Recurse -Force -ErrorAction SilentlyContinue
            foreach ($f in $files) {
                try {
                    $size = $f.Length
                    Remove-Item -Path $f.FullName -Recurse -Force -ErrorAction SilentlyContinue
                    if ($size) { $totalCleaned += $size }
                } catch { }
            }
        } catch { }
    }

    Write-Log "Vaciando Papelera de Reciclaje..." -Type "INFO"
    try {
        Clear-RecycleBin -Force -ErrorAction SilentlyContinue
        Write-Log "Papelera de reciclaje vaciada." -Type "SUCCESS"
    } catch { }

    $mbCleaned = [math]::Round($totalCleaned / 1MB, 2)
    Write-Log "Limpieza terminada. Se liberaron aproximadamente $mbCleaned MB de archivos temporales." -Type "SUCCESS"
    Pause-Prompt
}

function Clean-WinSxSStore {
    Clear-Host
    Write-Log "Saneamiento Profundo del Almacen de Componentes (WinSxS)" -Type "HEADER"
    Write-Host " Elimina actualizaciones antiguas reemplazadas de Windows para recuperar varios GBs." -ForegroundColor Gray
    
    $sxsEst = if ($sysInfo.DiskType -eq "SSD") { "~3 a 8 minutos (SSD)" } else { "~10 a 20 minutos (HDD)" }
    Invoke-ProcessWithTimer -Command "dism.exe" -Arguments "/Online /Cleanup-Image /StartComponentCleanup /ResetBase" -TaskName "Limpieza WinSxS" -EstimatedTime $sxsEst -ShowDismNotice
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 4: OPTIMIZACION BASICA DEL SISTEMA
# -------------------------------------------------------------
function Optimize-BasicSystem {
    Clear-Host
    Write-Log "Optimizacion Basica y Segura de Windows" -Type "HEADER"
    Write-Host " Ajustes seguros que reducen latencia y consumo de RAM sin romper funciones de Windows.`n" -ForegroundColor Gray

    # 1. Deshabilitar GameDVR (grabacion de fondo continua)
    Write-Log "Desactivando Xbox GameDVR (grabacion continua en segundo plano)..." -Type "INFO"
    try {
        New-Item -Path "HKCU:\System\GameConfigStore" -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord -Force
        New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -Value 0 -Type DWord -Force
        Write-Log "GameDVR desactivado con exito." -Type "SUCCESS"
    } catch { Write-Log "No se pudo modificar GameDVR: $_" -Type "WARNING" }

    # 2. Deshabilitar Sugerencias y Publicidad del Menu Inicio
    Write-Log "Desactivando sugerencias publicitarias de Microsoft en el sistema..." -Type "INFO"
    try {
        $cdm = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
        if (Test-Path $cdm) {
            Set-ItemProperty -Path $cdm -Name "SystemPaneSuggestionsEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $cdm -Name "SubscribedContent-338388Enabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $cdm -Name "SubscribedContent-338389Enabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $cdm -Name "SoftLandingEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            Write-Log "Publicidad y sugerencias del menu inicio desactivadas." -Type "SUCCESS"
        }
    } catch { }

    # 3. Minimizar telemetria y diagnosticos invasivos
    Write-Log "Ajustando nivel de telemetria al minimo permitido..." -Type "INFO"
    try {
        $dataCol = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
        New-Item -Path $dataCol -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path $dataCol -Name "AllowTelemetry" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
        Write-Log "Telemetria limitada a datos de seguridad/basicos." -Type "SUCCESS"
    } catch { }

    # 4. Detener servicio DiagTrack (Experiencias del usuario y telemetria)
    Write-Log "Ajustando servicio DiagTrack..." -Type "INFO"
    try {
        Stop-Service -Name "DiagTrack" -Force -ErrorAction SilentlyContinue
        Set-Service -Name "DiagTrack" -StartupType Manual -ErrorAction SilentlyContinue
        Write-Log "Servicio DiagTrack configurado en Manual." -Type "SUCCESS"
    } catch { }

    # 5. Optimizar efectos visuales (manteniendo suavizado de fuentes)
    Write-Log "Ajustando efectos visuales para respuesta agil..." -Type "INFO"
    try {
        # Mantener fuentes suaves (ClearType) pero quitar animaciones lentas
        Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "UserPreferencesMask" -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name "MinAnimate" -Value "0" -ErrorAction SilentlyContinue
        Write-Log "Efectos visuales optimizados (fuentes suaves preservadas)." -Type "SUCCESS"
    } catch { }

    Write-Log "Optimizacion basica completada correctamente." -Type "SUCCESS"
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 5: ESPECIFICO PARA NOTEBOOKS / BATERIA Y ENERGIA
# -------------------------------------------------------------
function Manage-LaptopBattery {
    Clear-Host
    Write-Log "Modulo de Energia y Salud de Bateria (Notebooks)" -Type "HEADER"

    $batt = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $batt) {
        Write-Log "No se detecto una bateria conectada a este equipo." -Type "WARNING"
        Write-Host " Si es una PC de escritorio, este modulo no aplica." -ForegroundColor Gray
        Pause-Prompt
        return
    }

    Write-Host " Informacion de la Bateria detectada:" -ForegroundColor Cyan
    Write-Host "  Nombre: $($batt.Name)" -ForegroundColor White
    Write-Host "  Estado de carga: $($batt.EstimatedChargeRemaining)%" -ForegroundColor Green
    $statusStr = switch ($batt.BatteryStatus) {
        1 { "Descargando" }
        2 { "Conectada a la corriente (Cargando)" }
        3 { "Completamente cargada" }
        default { "Estado desconocido ($($batt.BatteryStatus))" }
    }
    Write-Host "  Estado actual: $statusStr" -ForegroundColor White

    Write-Host "`n Opciones disponibles:" -ForegroundColor Yellow
    Write-Host "  1. Generar Reporte Completo de Bateria (powercfg /batteryreport)"
    Write-Host "  2. Prevenir suspension de Wi-Fi en bateria (evita cortes de conexion)"
    Write-Host "  3. Configurar Plan de Energia 'Equilibrado' (Recomendado para Notebooks)"
    Write-Host "  0. Volver al menu principal"

    $subChoice = Read-Host "`n Seleccione una opcion (0-3)"
    switch ($subChoice) {
        "1" {
            $reportPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "Reporte_Bateria_$($env:COMPUTERNAME).html"
            Write-Log "Generando reporte de bateria en $reportPath..." -Type "INFO"
            & powercfg /batteryreport /output $reportPath
            if (Test-Path $reportPath) {
                Write-Log "Reporte generado con exito. Abriendo en el navegador..." -Type "SUCCESS"
                Start-Process $reportPath
            } else {
                Write-Log "No se pudo generar el reporte." -Type "ERROR"
            }
            Pause-Prompt
        }
        "2" {
            Write-Log "Configurando adaptadores Wi-Fi para maximo rendimiento (sin cortes de energia)..." -Type "INFO"
            try {
                & powercfg -setacvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9f18-979183604d00 12bbebe6-58d6-4636-95bb-3217ef867c1a 0
                & powercfg -setdcvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9f18-979183604d00 12bbebe6-58d6-4636-95bb-3217ef867c1a 0
                & powercfg -SetActive SCHEME_CURRENT
                Write-Log "Ajuste de energia Wi-Fi aplicado exitosamente (evitara caidas de conexion al suspender o ahorrar bateria)." -Type "SUCCESS"
            } catch {
                Write-Log "No se pudo cambiar el ajuste de energia de red: $_" -Type "WARNING"
            }
            Pause-Prompt
        }
        "3" {
            Write-Log "Restaurando plan Equilibrado para evitar sobrecalentamiento..." -Type "INFO"
            & powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e
            Write-Log "Plan Equilibrado activo." -Type "SUCCESS"
            Pause-Prompt
        }
    }
}

function Manage-DesktopPower {
    Clear-Host
    Write-Log "Modulo de Energia para PC de Escritorio" -Type "HEADER"
    Write-Host " 1. Activar Plan 'Alto Rendimiento' (High Performance)"
    Write-Host " 2. Activar Plan 'Rendimiento Maximo / Definitivo' (Ultimate Performance)"
    Write-Host " 0. Volver"

    $pChoice = Read-Host "`n Seleccione una opcion (0-2)"
    switch ($pChoice) {
        "1" {
            Write-Log "Activando plan Alto Rendimiento..." -Type "INFO"
            & powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
            Write-Log "Plan Alto Rendimiento activado." -Type "SUCCESS"
            Pause-Prompt
        }
        "2" {
            Write-Log "Desbloqueando plan Rendimiento Maximo (Ultimate Performance)..." -Type "INFO"
            & powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
            Write-Log "Plan desbloqueado y activable desde Opciones de Energia." -Type "SUCCESS"
            Pause-Prompt
        }
    }
}

# -------------------------------------------------------------
# MODULO 6: DIAGNOSTICO DE DISCO Y ALMACENAMIENTO
# -------------------------------------------------------------
function Diagnose-Disks {
    Clear-Host
    Write-Log "Diagnostico de Discos y Almacenamiento" -Type "HEADER"

    Write-Host " Discos Fisicos y Estado de Salud (S.M.A.R.T.):" -ForegroundColor Cyan
    try {
        $pDisks = Get-PhysicalDisk
        foreach ($d in $pDisks) {
            $hColor = if ($d.HealthStatus -eq "Healthy") { "Green" } else { "Red" }
            Write-Host "  Disco #$($d.DeviceId): $($d.FriendlyName) | Tipo: $($d.MediaType) | Salud: " -NoNewline
            Write-Host "$($d.HealthStatus)" -ForegroundColor $hColor -NoNewline
            Write-Host " | Tamano: $([math]::Round($d.Size / 1GB, 1)) GB"
        }
    } catch {
        Write-Log "No se pudo obtener datos con Get-PhysicalDisk: $_" -Type "WARNING"
    }

    Write-Host "`n Opciones:" -ForegroundColor Yellow
    Write-Host "  1. Ejecutar escaneo CHKDSK en unidad C: (sin desmontar / solo lectura)"
    Write-Host "  2. Programar reparacion completa de disco para el proximo reinicio (chkdsk /f /r)"
    Write-Host "  3. Enviar comando TRIM a unidades SSD (Optimize-Volume)"
    Write-Host "  0. Volver"

    $dChoice = Read-Host "`n Seleccione una opcion (0-3)"
    switch ($dChoice) {
        "1" {
            Write-Log "Iniciando chkdsk C: /scan..." -Type "INFO"
            & chkdsk C: /scan
            Write-Log "Escaneo de disco completado." -Type "SUCCESS"
            Pause-Prompt
        }
        "2" {
            Write-Log "Programando chkdsk C: /f..." -Type "INFO"
            Write-Host " Ingrese 'S' si Windows le pregunta si desea desmontar o programar para el reinicio:" -ForegroundColor Yellow
            & chkdsk C: /f
            Pause-Prompt
        }
        "3" {
            Write-Log "Ejecutando TRIM en unidades SSD detectadas..." -Type "INFO"
            try {
                Optimize-Volume -DriveLetter C -ReTrim -Verbose
                Write-Log "TRIM enviado a la unidad C: exitosamente." -Type "SUCCESS"
            } catch {
                Write-Log "Error al ejecutar TRIM: $_" -Type "WARNING"
            }
            Pause-Prompt
        }
    }
}

# -------------------------------------------------------------
# MODULO 7: MANTENIMIENTO TOTAL (1-CLIC)
# -------------------------------------------------------------
function Run-OneClickMaintenance {
    Clear-Host
    Write-Log "MANTENIMIENTO TOTAL 1-CLIC (AUTOMATIZADO)" -Type "HEADER"
    Write-Host " Se ejecutara la rutina recomendada completa en secuencia:" -ForegroundColor Gray
    Write-Host "  1. Limpieza de temporales y papelera" -ForegroundColor DarkGray
    Write-Host "  2. Vaciado de cache DNS y reseteo de red" -ForegroundColor DarkGray
    Write-Host "  3. Optimizacion basica (GameDVR, telemetria, efectos)" -ForegroundColor DarkGray
    Write-Host "  4. Reparacion de imagen del sistema (DISM + SFC)" -ForegroundColor DarkGray
    Write-Host "  5. Optimizacion TRIM en SSDs (si aplica)`n" -ForegroundColor DarkGray

    $totalEst = if ($sysInfo.DiskType -eq "SSD") { "~8 a 15 minutos (SSD)" } else { "~25 a 45 minutos (HDD)" }
    Write-Host " [⏱️ Tiempo estimado total para tu equipo: $totalEst]`n" -ForegroundColor Cyan

    $confirm = Read-Host " Desea iniciar el mantenimiento automatico? (S/N)"
    if ($confirm -notmatch '^(s|S|y|Y)$') { return }

    # Paso 1
    Write-Log "[1/5] Ejecutando limpieza segura..." -Type "INFO"
    $cleanTargets = @("$env:TEMP\*", "$env:SystemRoot\Temp\*", "$env:LOCALAPPDATA\CrashDumps\*")
    foreach ($target in $cleanTargets) {
        Remove-Item -Path $target -Recurse -Force -ErrorAction SilentlyContinue
    }
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue

    # Paso 2
    Write-Log "[2/5] Restableciendo conexion y DNS..." -Type "INFO"
    & ipconfig /flushdns | Out-Null
    & netsh winsock reset | Out-Null

    # Paso 3
    Write-Log "[3/5] Aplicando optimizaciones seguras..." -Type "INFO"
    New-Item -Path "HKCU:\System\GameConfigStore" -Force -ErrorAction SilentlyContinue | Out-Null
    Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
    Stop-Service -Name "DiagTrack" -Force -ErrorAction SilentlyContinue
    Set-Service -Name "DiagTrack" -StartupType Manual -ErrorAction SilentlyContinue

    # Paso 4
    Write-Log "[4/5] Escaneo y reparacion del sistema (DISM + SFC)..." -Type "INFO"
    $dismEst = if ($sysInfo.DiskType -eq "SSD") { "~5 a 10 min (SSD)" } else { "~15 a 30 min (HDD)" }
    $sfcEst = if ($sysInfo.DiskType -eq "SSD") { "~2 a 5 min (SSD)" } else { "~5 a 15 min (HDD)" }
    Invoke-ProcessWithTimer -Command "dism.exe" -Arguments "/Online /Cleanup-Image /RestoreHealth" -TaskName "[4/5] DISM RestoreHealth" -EstimatedTime $dismEst -ShowDismNotice
    Invoke-ProcessWithTimer -Command "sfc.exe" -Arguments "/scannow" -TaskName "[4/5] SFC Scannow" -EstimatedTime $sfcEst

    # Paso 5
    Write-Log "[5/5] Enviando orden TRIM a discos SSD..." -Type "INFO"
    try { Optimize-Volume -DriveLetter C -ReTrim -ErrorAction SilentlyContinue } catch { }

    Write-Log "Mantenimiento 1-Clic Finalizado con Exito! Se recomienda reiniciar la PC." -Type "SUCCESS"
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 8: ACCESOS RAPIDOS A HERRAMIENTAS DE WINDOWS
# -------------------------------------------------------------
function Show-QuickTools {
    Clear-Host
    Write-Log "Herramientas Tecnicas Nativas de Windows" -Type "HEADER"
    Write-Host "  1. Administrador de Dispositivos (devmgmt.msc)"
    Write-Host "  2. Administrador de Tareas (taskmgr.exe)"
    Write-Host "  3. Conexiones de Red (ncpa.cpl)"
    Write-Host "  4. Servicios de Windows (services.msc)"
    Write-Host "  5. Visor de Eventos (eventvwr.msc)"
    Write-Host "  6. Editor del Registro (regedit.exe)"
    Write-Host "  7. Configuracion del Sistema / Modo Seguro (msconfig.exe)"
    Write-Host "  8. Informacion del Sistema (msinfo32.exe)"
    Write-Host "  0. Volver"

    $t = Read-Host "`n Seleccione una herramienta para abrir (0-8)"
    switch ($t) {
        "1" { Start-Process "devmgmt.msc" }
        "2" { Start-Process "taskmgr.exe" }
        "3" { Start-Process "ncpa.cpl" }
        "4" { Start-Process "services.msc" }
        "5" { Start-Process "eventvwr.msc" }
        "6" { Start-Process "regedit.exe" }
        "7" { Start-Process "msconfig.exe" }
        "8" { Start-Process "msinfo32.exe" }
    }
}

function Pause-Prompt {
    Write-Host "`n Presione [ENTER] para continuar..." -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}

# -------------------------------------------------------------
# BUCLE PRINCIPAL DEL MENU
# -------------------------------------------------------------
function Show-MainMenu {
    param($sys)

    Clear-Host
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host "                        XAO PROBLEMS - REPARACION & OPTIMIZACION                " -ForegroundColor Yellow
    Write-Host "                                   Xaoxay Labs                                  " -ForegroundColor DarkCyan
    Write-Host "================================================================================" -ForegroundColor Cyan
    
    # Informacion del Sistema
    $formFactor = if ($sys.IsLaptop) { "NOTEBOOK / LAPTOP" } else { "PC DE ESCRITORIO" }
    $ffColor = if ($sys.IsLaptop) { "Magenta" } else { "Green" }

    Write-Host " Equipo: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.ComputerName) " -NoNewline -ForegroundColor White
    Write-Host "[$formFactor]" -ForegroundColor $ffColor

    Write-Host " Sistema: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.OSName) (Build $($sys.OSBuild))" -ForegroundColor White

    Write-Host " CPU: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.CPU)" -ForegroundColor White

    Write-Host " Memoria RAM: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.TotalRAM) GB (Disponible: $($sys.FreeRAM) GB) | Disco $($sys.Drive) ($($sys.DiskType)): $($sys.FreeDiskGB) GB libres de $($sys.TotalDiskGB) GB" -ForegroundColor White
    Write-Host "================================================================================" -ForegroundColor Cyan

    Write-Host " [1] Reparaciones Criticas de Windows (SFC, DISM, WinUpdate, Tienda, Iconos)" -ForegroundColor White
    Write-Host " [2] Reparacion de Red e Internet (Winsock, TCP/IP, Flush DNS, Adaptadores)" -ForegroundColor White
    Write-Host " [3] Limpieza y Liberacion de Espacio (Temporales, Prefetch, Papelera, WinSxS)" -ForegroundColor White
    Write-Host " [4] Optimizacion Basica del Sistema (Servicios, Telemetria, GameDVR, Efectos)" -ForegroundColor White

    if ($sys.IsLaptop) {
        Write-Host " [5] Modulo Notebook: Reporte y Salud de Bateria, Wi-Fi y Energia" -ForegroundColor Yellow
    } else {
        Write-Host " [5] Modulo Escritorio: Planes de Energia (Alto / Maximo Rendimiento)" -ForegroundColor Yellow
    }

    Write-Host " [6] Diagnostico de Almacenamiento (Salud SMART, CHKDSK, TRIM SSD)" -ForegroundColor White
    Write-Host " [7] MANTENIMIENTO TOTAL (1-CLIC) -> Diagnostico + Limpieza + Reparacion" -ForegroundColor Green
    Write-Host " [8] Accesos Rapidos a Herramientas de Windows (Dispositivos, Red, Servicios)" -ForegroundColor White
    Write-Host " [9] Abrir Carpeta de Logs de XaoProblems" -ForegroundColor DarkGray
    Write-Host " [0] Salir" -ForegroundColor Red
    Write-Host "================================================================================" -ForegroundColor Cyan
}

# Inicio del programa
Ensure-AdminPrivileges
Disable-ConsoleQuickEdit
$sysInfo = Get-SystemInfo
Write-Log "Iniciando Xao Problems en $($sysInfo.ComputerName) ($($sysInfo.OSName))" -Type "INFO"

do {
    Show-MainMenu -sys $sysInfo
    $op = Read-Host " Ingrese una opcion (0-9)"

    switch ($op) {
        "1" {
            Clear-Host
            Write-Host "--- REPARACIONES CRITICAS DE WINDOWS ---" -ForegroundColor Cyan
            Write-Host " 1. Ejecutar DISM + SFC (Reparacion completa de archivos de sistema)"
            Write-Host " 2. Reparar Windows Update (Purgar cache y reiniciar servicios)"
            Write-Host " 3. Reparar Microsoft Store y Apps nativas (wsreset)"
            Write-Host " 4. Reparar Explorador de Archivos y Cache de Iconos/Miniaturas"
            Write-Host " 5. Desatascar Cola de Impresion"
            Write-Host " 0. Volver"
            $sub = Read-Host "`n Seleccione (0-5)"
            switch ($sub) {
                "1" { Repair-WindowsFiles }
                "2" { Repair-WindowsUpdate }
                "3" { Repair-StoreAndApps }
                "4" { Repair-ExplorerAndIcons }
                "5" { Repair-PrintSpooler }
            }
        }
        "2" { Repair-NetworkStack }
        "3" {
            Clear-Host
            Write-Host "--- LIMPIEZA Y LIBERACION DE ESPACIO ---" -ForegroundColor Cyan
            Write-Host " 1. Limpieza de Temporales, Papelera, Crashes y Prefetch"
            Write-Host " 2. Limpieza Profunda de WinSxS (Actualizaciones antiguas de Windows)"
            Write-Host " 0. Volver"
            $sub = Read-Host "`n Seleccione (0-2)"
            switch ($sub) {
                "1" { Clean-JunkFiles }
                "2" { Clean-WinSxSStore }
            }
        }
        "4" { Optimize-BasicSystem }
        "5" {
            if ($sysInfo.IsLaptop) {
                Manage-LaptopBattery
            } else {
                Manage-DesktopPower
            }
        }
        "6" { Diagnose-Disks }
        "7" { Run-OneClickMaintenance }
        "8" { Show-QuickTools }
        "9" {
            if (Test-Path $LogFile) {
                Start-Process "notepad.exe" -ArgumentList $LogFile
            } else {
                Write-Host " Aun no se ha generado ningun log." -ForegroundColor Yellow
                Pause-Prompt
            }
        }
    }
} while ($op -ne "0")

Write-Host "`n Gracias por utilizar Xao Problems. Saliendo..." -ForegroundColor Green
Start-Sleep -Seconds 1
