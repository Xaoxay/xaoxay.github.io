<# :
@echo off
setlocal DisableDelayedExpansion
set "XAO_SELF=%~f0"
title XaoProblems v1.2
powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $raw=[IO.File]::ReadAllText($env:XAO_SELF,[Text.Encoding]::UTF8); $body=$raw.Substring($raw.IndexOf('#'+'>')+2); $file=Join-Path ([IO.Path]::GetTempPath()) ('XaoProblems-'+[guid]::NewGuid().ToString('N')+'.ps1'); [IO.File]::WriteAllText($file,$body,[Text.UTF8Encoding]::new($true)); try { & $file } finally { Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue }"
set "XAO_EXIT=%errorlevel%"
if not "%XAO_EXIT%"=="0" (
    echo La herramienta termino con un error. Revise el mensaje anterior.
    pause
)
exit /b %XAO_EXIT%
#>
<#
.SYNOPSIS
    XaoProblems - Herramienta integral de reparacion y optimizacion para Windows 10 y 11.
    Apta para PCs de escritorio y Notebooks / Laptops.
.AUTHOR
    Xaoxay Labs
#>

# BEGIN XAO COMMON
# Xao shared runtime (embedded in every standalone script).
function Invoke-XaoNative {
    param([string]$FilePath,[string[]]$ArgumentList=@(),[int[]]$SuccessCodes=@(0),[switch]$CaptureOutput)
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $exe=Get-Command $FilePath -CommandType Application -ErrorAction Stop | Select-Object -First 1
    & $exe.Source @ArgumentList | ForEach-Object {
        if($CaptureOutput){Write-Output $_}
        elseif($XaoQueue){$XaoQueue.Enqueue([pscustomobject]@{Message=[string]$_;Type='INFO'})}
        else{Write-Host $_;Write-XaoLogRecord -Path $LogFile -Message ([string]$_)}
    }
    $code=$LASTEXITCODE
    if($code -notin $SuccessCodes){throw "$FilePath termino con codigo $code. Consulte la salida y el registro."}
    if($code -eq 3010){Write-Warning 'La operacion requiere reiniciar Windows.'}
    Test-XaoCancellation

    }
}

function Set-XaoRegistryValue {
    [CmdletBinding()]
    param([string]$Path,[string]$Name,$Value,[string]$Type,[switch]$Force)
    Invoke-XaoExclusive {
        $journal=Save-XaoRegistryValue -Path $Path -Name $Name
        if(-not $script:XaoBackupNoticeShown){$script:XaoBackupNoticeShown=$true;Write-Information "Copia de valores de registro: $journal" -InformationAction Continue}
        if(-not (Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force -ErrorAction Stop | Out-Null}
        if($Type){New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null}
        else{Set-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -Force -ErrorAction Stop}
    }
}

function Enable-XaoUltimatePower {
    Invoke-XaoExclusive {

    $template = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
    $target = '64b4b650-61fc-4a85-97c0-cb043335517e'
    $plans = (Invoke-XaoNative powercfg @('/list') -CaptureOutput) -join "`n"
    if ($plans -notmatch $target) { Invoke-XaoNative powercfg @('/duplicatescheme', $template, $target) | Out-Null }
    Invoke-XaoNative powercfg @('/setactive', $target) | Out-Null
    $active = (Invoke-XaoNative powercfg @('/getactivescheme') -CaptureOutput) -join "`n"
    if ($active -notmatch $target) { throw 'Windows no activo el plan solicitado. El equipo puede no admitirlo.' }

    }
}

function Reset-XaoWindowsUpdate {
    Invoke-XaoExclusive {

    $services = @('bits','wuauserv','cryptsvc')
    $running = @()
    $failures = [Collections.Generic.List[string]]::new()
    try {
        foreach ($name in $services) {
            $svc = Get-Service $name -ErrorAction Stop
            if ($svc.Status -ne 'Stopped') {
                $running += $name
                Stop-Service $name -Force -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
            }
        }
        foreach ($path in @("$env:SystemRoot\SoftwareDistribution", "$env:SystemRoot\System32\catroot2")) {
            if (Test-Path -LiteralPath $path) {
                $leaf = (Split-Path $path -Leaf) + '.xao-backup-' + [guid]::NewGuid().ToString('N')
                Rename-Item -LiteralPath $path -NewName $leaf -ErrorAction Stop
            }
        }
    } catch { $failures.Add($_.Exception.Message) }
    finally {
        foreach ($name in $running) {
            try {
                Start-Service $name -ErrorAction Stop
                (Get-Service $name).WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
            } catch { $failures.Add("No se pudo restablecer ${name}: $($_.Exception.Message)") }
        }
    }
    if ($failures.Count) { throw ($failures -join ' | ') }

    }
}

function Reset-XaoPrintQueue {
    Invoke-XaoExclusive {

    $svc = Get-Service Spooler -ErrorAction Stop
    $wasRunning = $svc.Status -eq 'Running'
    try {
        Stop-Service Spooler -Force -ErrorAction Stop
        (Get-Service Spooler).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
        $folder = Join-Path $env:SystemRoot 'System32\spool\PRINTERS'
        # Only pending spool files, never recursively delete a computed directory.
        Get-ChildItem -LiteralPath $folder -File -Force -ErrorAction Stop |
            Where-Object { $_.Extension -in @('.SPL','.SHD') } |
            Remove-Item -Force -ErrorAction Stop
    } finally { if ($wasRunning) { Start-Service Spooler -ErrorAction Stop } }

    }
}

function Clear-XaoTemp {
    param([string[]]$Roots = @($env:TEMP, "$env:SystemRoot\Temp"), [int]$MinimumAgeDays = 7)
    Invoke-XaoExclusive {

    $bytes = 0L; $removed = 0; $skipped = 0
    $cutoff = (Get-Date).AddDays(-[Math]::Max(1, $MinimumAgeDays))
    foreach ($root in ($Roots | Select-Object -Unique)) {
        Test-XaoCancellation
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'Ruta temporal vacia.' }
        $full = [IO.Path]::GetFullPath($root).TrimEnd('\')
        if ($full -eq [IO.Path]::GetPathRoot($full).TrimEnd('\') -or $full -in @($env:USERPROFILE,$env:SystemRoot,$env:ProgramFiles)) {
            throw "Se rechazo una ruta de limpieza demasiado amplia: $full"
        }
        if (-not (Test-Path -LiteralPath $full)) { continue }
        $pending = [Collections.Generic.Stack[string]]::new()
        $pending.Push($full)
        while ($pending.Count) {
            Test-XaoCancellation
            $directory = $pending.Pop()
            try {
                $info = Get-Item -LiteralPath $directory -Force -ErrorAction Stop
                if ($info.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                foreach ($item in Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop) {
                    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skipped++; continue }
                    if ($item.PSIsContainer) { $pending.Push($item.FullName); continue }
                    if ($item.LastWriteTime -ge $cutoff) { continue }
                    try {
                        $length = $item.Length
                        Remove-Item -LiteralPath $item.FullName -Force -ErrorAction Stop
                        $bytes += $length; $removed++
                    } catch { $skipped++ }
                }
            } catch { $skipped++ }
        }
    }
    [pscustomobject]@{ Removed=$removed; Skipped=$skipped; Bytes=$bytes }

    }
}

function Get-XaoRustDeskAsset {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod 'https://api.github.com/repos/rustdesk/rustdesk/releases/latest' -Headers @{'User-Agent'='XaoTools'} -TimeoutSec 30 -ErrorAction Stop
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'aarch64' } elseif ([Environment]::Is64BitOperatingSystem) { 'x86_64' } else { throw 'RustDesk: esta version requiere Windows de 64 bits.' }
    $asset = @($release.assets | Where-Object { $_.name -match "^rustdesk-[0-9.]+-$arch\.msi$" })
    if ($asset.Count -ne 1 -or $asset[0].digest -notmatch '^sha256:[a-fA-F0-9]{64}$') { throw 'No hay un instalador RustDesk con SHA-256 verificable para este equipo.' }
    if ($asset[0].browser_download_url -notmatch '^https://github\.com/rustdesk/rustdesk/releases/download/') { throw 'Origen de RustDesk inesperado.' }
    $asset[0]
}

function Install-XaoRustDesk {
    Invoke-XaoExclusive {

    Test-XaoCancellation
    $asset = Get-XaoRustDeskAsset
    $folder = Join-Path $env:TEMP ('XaoRustDesk-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null
    $file = Join-Path $folder $asset.name
    try {
        Invoke-WebRequest $asset.browser_download_url -OutFile $file -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($hash -ne ($asset.digest -replace '^sha256:','')) { throw 'SHA-256 de RustDesk incorrecto. Se cancelo la instalacion.' }
        $signature=Get-AuthenticodeSignature -LiteralPath $file -ErrorAction Stop
        if($signature.Status -ne 'Valid'){throw "La firma digital de RustDesk no es valida ($($signature.Status)). No se ejecutara el instalador."}
        Test-XaoCancellation
        $msiLog = Join-Path $env:TEMP ('XaoRustDesk-' + (Get-Date -Format yyyyMMddHHmmss) + '.log')
        $process = Start-Process msiexec.exe -ArgumentList "/i `"$file`" /qn /norestart /L*v `"$msiLog`"" -Wait -PassThru -WindowStyle Hidden -ErrorAction Stop
        if ($process.ExitCode -notin @(0,3010)) { throw "RustDesk: MSI termino con codigo $($process.ExitCode). Registro: $msiLog" }
        [pscustomobject]@{ Status= $(if ($process.ExitCode -eq 3010) {'RebootRequired'} else {'Installed'}); Code=$process.ExitCode }
    } finally {
        if (Test-Path -LiteralPath $file) { Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue }
        # Non-recursive: never remove files outside this dedicated download folder.
        Remove-Item -LiteralPath $folder -ErrorAction SilentlyContinue
    }

    }
}

function Install-XaoPackage {
    param([string]$Id, [string]$Source = 'winget')
    Invoke-XaoExclusive {

    Test-XaoCancellation
    if ($Id -eq 'RustDesk.RustDesk') { return Install-XaoRustDesk }
    try { $exe = Get-Command winget.exe -CommandType Application -ErrorAction Stop }
    catch { throw 'Winget no esta disponible. Instale o actualice "Instalador de aplicaciones" desde Microsoft Store y vuelva a abrir la herramienta.' }
    $arguments = @('install','--id',$Id,'--exact','--source',$Source,'--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements')
    & $exe.Source @arguments | ForEach-Object { Write-Host $_ }
    $code = $LASTEXITCODE
    Test-XaoCancellation
    $status = switch ($code) {
        0 { 'Installed' }
        3010 { 'RebootRequired' }
        -1978335189 { 'NoUpdate' }
        -1978335135 { 'AlreadyInstalled' }
        default { throw "Winget no pudo instalar $Id (codigo $code). Revise la salida y los registros de Winget." }
    }
    [pscustomobject]@{ Status=$status; Code=$code }

    }
}

function Update-XaoPackages {
    Invoke-XaoExclusive {

    Invoke-XaoNative winget.exe @('upgrade','--all','--silent','--disable-interactivity','--accept-source-agreements','--accept-package-agreements') -SuccessCodes @(0,3010,-1978335189)

    }
}


function Test-XaoCancellation {
    if ($XaoCancel -and $XaoCancel.IsCancellationRequested) {
        throw [OperationCanceledException]::new('Detenido entre pasos por solicitud del usuario. Los cambios ya realizados se conservan.')
    }
}

function Enter-XaoOperation {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $mutex = [Threading.Mutex]::new($false, "Local\XaoTools.Operations.$sid")
    try {
        try { $acquired = $mutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $acquired = $true }
        if (-not $acquired) { throw 'Otra herramienta Xao esta trabajando en esta sesion. Espere a que termine.' }
        return $mutex
    } catch { $mutex.Dispose(); throw }
}

function Invoke-XaoExclusive {
    param([scriptblock]$Action)
    Test-XaoCancellation
    $mutex = Enter-XaoOperation
    try { & $Action } finally { $mutex.ReleaseMutex(); $mutex.Dispose() }
}

function Initialize-XaoLog {
    param([string]$Tool)
    $folder = Join-Path $env:LOCALAPPDATA 'XaoTools\Logs'
    try { New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null }
    catch { $folder = [IO.Path]::GetTempPath() }
    $path = Join-Path $folder ("{0}-{1}-{2}.log" -f $Tool,(Get-Date -Format 'yyyyMMdd-HHmmss-fff'),$PID)
    try { [IO.File]::WriteAllText($path, "Xao v1.2 | $Tool | $(Get-Date -Format o)`r`n", [Text.UTF8Encoding]::new($false)) }
    catch { Write-Warning "No se pudo crear el registro: $($_.Exception.Message)"; return $null }
    return $path
}

function Write-XaoLogRecord {
    [CmdletBinding()]
    param([string]$Path,[string]$Message,[string]$Type='INFO')
    if (-not $Path) { return }
    try {
        # Console output is bounded in the GUI; the file keeps the complete record.
        $line = '[{0}] [{1}] {2}{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Type,$Message,[Environment]::NewLine
        [IO.File]::AppendAllText($Path,$line,[Text.UTF8Encoding]::new($false))
    } catch {
        # Logging must never recursively call itself or hide the original error.
        if (-not $script:XaoLogWarningShown) { $script:XaoLogWarningShown=$true; Write-Warning "Registro no disponible: $($_.Exception.Message)" }
    }
}

function Get-XaoSystemDisk {
    param([string]$DriveLetter = $env:SystemDrive.TrimEnd(':'))
    $type='Desconocido'; $name='No disponible'; $health='No disponible'
    try {
        $disk = Get-Partition -DriveLetter $DriveLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop | Select-Object -First 1
        if ($disk) {
            $name=$disk.FriendlyName; $health=[string]$disk.HealthStatus
            $physical = @(Get-PhysicalDisk -ErrorAction Stop | Where-Object {
                $_.UniqueId -and $disk.UniqueId -and $_.UniqueId.Trim() -eq $disk.UniqueId.Trim()
            })
            if ($physical.Count -eq 1 -and $physical[0].MediaType -in @('SSD','HDD','SCM')) { $type=[string]$physical[0].MediaType }
        }
    } catch { }
    [pscustomobject]@{ Drive=$DriveLetter+':'; Name=$name; MediaType=$type; HealthStatus=$health }
}

function Get-XaoRegistryJournalPath {
    if (-not $script:XaoRegistryJournal) {
        $folder=Join-Path $env:LOCALAPPDATA 'XaoTools\RegistryBackups'
        New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
        $script:XaoRegistryJournal=Join-Path $folder ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+[guid]::NewGuid().ToString('N')+'.jsonl')
    }
    return $script:XaoRegistryJournal
}

function Save-XaoRegistryValue {
    param([string]$Path,[string]$Name)
    $exists=$false; $kind=$null; $value=$null
    if (Test-Path -LiteralPath $Path) {
        $key=Get-Item -LiteralPath $Path -ErrorAction Stop
        if ($key.GetValueNames() -contains $Name) {
            $exists=$true
            $kind=$key.GetValueKind($Name).ToString()
            $value=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
    }
    $entry=[pscustomobject]@{ Version=1; Time=(Get-Date -Format o); Path=$Path; Name=$Name; Existed=$exists; Kind=$kind; Value=$value }
    $journal=Get-XaoRegistryJournalPath
    # Abort the mutation if its backup cannot be saved.
    [IO.File]::AppendAllText($journal,($entry | ConvertTo-Json -Compress -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
    return $journal
}

function Restore-XaoRegistryJournal {
    [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
    param([Parameter(Mandatory=$true)][string]$Path)
    $records=@(Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Where-Object { $_.Trim() } | ForEach-Object { $_ | ConvertFrom-Json -ErrorAction Stop })
    if (-not $records.Count) { throw 'La copia esta vacia.' }
    foreach ($record in $records) {
        if ($record.Version -ne 1 -or $record.Path -notmatch '^HK(CU|LM):\\' -or [string]::IsNullOrWhiteSpace($record.Name)) { throw 'Formato de copia no valido.' }
        if ($record.Existed -isnot [bool]) { throw 'Estado del valor no valido.' }
        if ($record.Existed -and $record.Kind -notin @('String','ExpandString','Binary','DWord','MultiString','QWord')) { throw 'Tipo de registro no admitido.' }
        if($record.Existed){
            $validated=switch($record.Kind){
                'Binary'{,([byte[]]$record.Value)}
                'MultiString'{,([string[]]$record.Value)}
                'DWord'{[int]$record.Value}
                'QWord'{[long]$record.Value}
                default{[string]$record.Value}
            }
            $record | Add-Member -NotePropertyName RestoredValue -NotePropertyValue $validated -Force
        }
    }
    if (-not $PSCmdlet.ShouldProcess($Path,'Restaurar los valores de registro guardados (no servicios ni archivos)')) { return }
    Invoke-XaoExclusive {
        for ($index=$records.Count-1; $index -ge 0; $index--) {
            $record=$records[$index]
            if ($record.Existed) {
                $value=$record.RestoredValue
                if (-not (Test-Path -LiteralPath $record.Path)) { New-Item -Path $record.Path -Force -ErrorAction Stop | Out-Null }
                New-ItemProperty -LiteralPath $record.Path -Name $record.Name -Value $value -PropertyType $record.Kind -Force -ErrorAction Stop | Out-Null
            } elseif (Test-Path -LiteralPath $record.Path) {
                $key=Get-Item -LiteralPath $record.Path -ErrorAction Stop
                if ($key.GetValueNames() -contains $record.Name) { Remove-ItemProperty -LiteralPath $record.Path -Name $record.Name -ErrorAction Stop }
            }
        }
    }
}

$script:XaoSharedFunctions = @('Invoke-XaoNative','Set-XaoRegistryValue','Enable-XaoUltimatePower','Reset-XaoWindowsUpdate','Reset-XaoPrintQueue','Clear-XaoTemp','Get-XaoRustDeskAsset','Install-XaoRustDesk','Install-XaoPackage','Update-XaoPackages','Test-XaoCancellation','Enter-XaoOperation','Invoke-XaoExclusive','Initialize-XaoLog','Write-XaoLogRecord','Get-XaoSystemDisk','Get-XaoRegistryJournalPath','Save-XaoRegistryValue','Restore-XaoRegistryJournal')
# END XAO COMMON

$ErrorActionPreference = "Stop"

# Asegurar codificacion UTF-8 en la consola
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Xao Problems v1.2 - Reparacion & Optimizacion (Windows 10 / 11)"

# Configuracion de archivo de log
$LogFile = Initialize-XaoLog 'XaoProblems'

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]$identity
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-AdminPrivileges {
    if (Test-IsAdmin) { return }
    if (-not $PSCommandPath) { throw 'Abra PowerShell como Administrador antes de ejecutar la version en memoria.' }
    $child=Start-Process powershell.exe -ArgumentList "-STA -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs -Wait -PassThru -ErrorAction Stop
    exit $child.ExitCode
}

function Disable-ConsoleQuickEdit {
    try {
        $sig = @"
        using System;
        using System.Runtime.InteropServices;
        public class ConsoleHelper {
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr GetStdHandle(int nStdHandle);
            [DllImport("kernel32.dll")]
            public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
            [DllImport("kernel32.dll")]
            public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
            public static void FixQuickEdit() {
                try {
                    IntPtr h = GetStdHandle(-10);
                    uint mode;
                    if (GetConsoleMode(h, out mode)) {
                        mode &= ~0x0040u;
                        mode &= ~0x0020u;
                        SetConsoleMode(h, mode);
                    }
                } catch {}
            }
        }
"@
        if (-not ([System.Management.Automation.PSTypeName]'ConsoleHelper').Type) {
            Add-Type -TypeDefinition $sig -ErrorAction SilentlyContinue
        }
        [ConsoleHelper]::FixQuickEdit()
    } catch {}
}

function Write-Log {
    param([string]$Message,[string]$Type='INFO')
    Write-XaoLogRecord -Path $LogFile -Message $Message -Type $Type
    $color=switch($Type){'ERROR'{'Red'} 'WARNING'{'Yellow'} 'SUCCESS'{'Green'} 'HEADER'{'Cyan'} default{'Gray'}}
    Write-Host "[$Type] $Message" -ForegroundColor $color
}

# -------------------------------------------------------------
# DETECCION DE HARDWARE Y SISTEMA
# -------------------------------------------------------------
function Get-SystemInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    $proc = Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1
    $enclosure = Get-CimInstance -ClassName Win32_SystemEnclosure
    $batteries = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue

    # Detectar Laptop / Notebook
    $isChassisLaptop = $false
    if ($enclosure.ChassisTypes) {
        $isChassisLaptop = $enclosure.ChassisTypes -match '^(8|9|10|11|12|14|18|21|30|31|32)$'
    }
    $hasBattery = ($null -ne $batteries -and @($batteries).Count -gt 0)
    $isLaptop = $isChassisLaptop -or $hasBattery

    # Memoria RAM
    $totalRamGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
    $freeRamGB = [math]::Round($os.FreePhysicalMemory / 1MB, 1)

    # Disco de Arranque
    $systemDrive = $env:SystemDrive
    $driveInfo = Get-PSDrive -Name ($systemDrive.Replace(":", ""))
    $freeDiskGB = [math]::Round($driveInfo.Free / 1GB, 1)
    $usedDiskGB = [math]::Round($driveInfo.Used / 1GB, 1)
    $totalDiskGB = $freeDiskGB + $usedDiskGB

    $diskType=(Get-XaoSystemDisk).MediaType

    return [PSCustomObject]@{
        OSName       = $os.Caption
        OSBuild      = $os.BuildNumber
        ComputerName = $cs.Name
        CPU          = $proc.Name.Trim()
        TotalRAM     = $totalRamGB
        FreeRAM      = $freeRamGB
        IsLaptop     = [bool]$isLaptop
        Drive        = $systemDrive
        DiskType     = $diskType
        FreeDiskGB   = $freeDiskGB
        TotalDiskGB  = $totalDiskGB
        HasBattery   = [bool]$hasBattery
    }
}

# -------------------------------------------------------------
# EJECUCION CON TEMPORIZADOR EN VIVO Y ESTIMACION
# -------------------------------------------------------------
function Invoke-ProcessWithTimer {
    param(
        [string]$Command,
        [string]$Arguments,
        [string]$TaskName,
        [string]$EstimatedTime,
        [switch]$ShowDismNotice
    )
    Invoke-XaoExclusive {


    Write-Host " [⏱️ Tiempo estimado: $EstimatedTime]" -ForegroundColor Cyan
    if ($ShowDismNotice) {
        Write-Host " [!] AVISO IMPORTANTE: En DISM es completamente normal que la barra parezca" -ForegroundColor Yellow
        Write-Host "     detenerse varios minutos en el 62% - 64% mientras analiza el almacen WinSxS." -ForegroundColor Yellow
        Write-Host "     El reloj indica tiempo transcurrido; no confirma por si solo que haya progreso.`n" -ForegroundColor Yellow
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Command
    $psi.Arguments = $Arguments
    $psi.UseShellExecute = $false

    $proc = [System.Diagnostics.Process]::Start($psi)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while (-not $proc.HasExited) {
        $elapsed = $sw.Elapsed.ToString("mm\:ss")
        $Host.UI.RawUI.WindowTitle = "Xao Problems - $TaskName [Transcurrido: $elapsed | Estimado: $EstimatedTime]"
        Start-Sleep -Milliseconds 1000
    }

    $proc.WaitForExit()
    $sw.Stop()
    $totalElapsed = $sw.Elapsed.ToString("mm\:ss")
    $Host.UI.RawUI.WindowTitle = "Xao Problems v1.2 - Reparacion & Optimizacion (Windows 10 / 11)"

    if ($proc.ExitCode -eq 0) {
        Write-Log "$TaskName termino con codigo 0 en $totalElapsed; revise su salida." -Type "INFO"
    } else {
        Write-Log "$TaskName finalizo en $totalElapsed con codigo: $($proc.ExitCode)" -Type "WARNING"
    }

    if ($proc.ExitCode -notin @(0,3010)) { throw "$TaskName fallo (codigo $($proc.ExitCode))." }
    if ($Command -eq 'sfc.exe') { Write-Log 'Consulte el resultado de SFC y CBS.log para conocer si quedan archivos sin reparar.' 'INFO' }
    return $proc.ExitCode

    }
}

# -------------------------------------------------------------
# MODULO 1: REPARACIONES CRITICAS DEL SISTEMA
# -------------------------------------------------------------
function Repair-WindowsFiles {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Iniciando Diagnostico y Reparacion de Archivos del Sistema" -Type "HEADER"
    Write-Host " Esta operacion utilizara DISM y SFC para verificar y reparar el almacen de componentes." -ForegroundColor Gray
    
    $dismEst = if ($sysInfo.DiskType -eq "SSD") { "~5 a 10 minutos (SSD)" } else { "~15 a 30 minutos (HDD)" }
    $sfcEst = if ($sysInfo.DiskType -eq "SSD") { "~2 a 5 minutos (SSD)" } else { "~5 a 15 minutos (HDD)" }

    Write-Log "Paso 1/2: Ejecutando DISM /Online /Cleanup-Image /RestoreHealth..." -Type "INFO"
    Invoke-ProcessWithTimer -Command "dism.exe" -Arguments "/Online /Cleanup-Image /RestoreHealth" -TaskName "DISM RestoreHealth" -EstimatedTime $dismEst -ShowDismNotice

    Write-Host ""
    Write-Log "Paso 2/2: Ejecutando Comprobador de Archivos (sfc /scannow)..." -Type "INFO"
    Invoke-ProcessWithTimer -Command "sfc.exe" -Arguments "/scannow" -TaskName "SFC Scannow" -EstimatedTime $sfcEst

    Pause-Prompt

    }
}

function Repair-WindowsUpdate {
    Clear-Host
    Write-Log 'Restableciendo cache de Windows Update. Se conservaran copias de las carpetas.' 'HEADER'
    Reset-XaoWindowsUpdate
    Write-Log 'Cache restablecida y servicios restaurados. Compruebe la descarga en Windows Update.' 'SUCCESS'
    Pause-Prompt
}

function Repair-StoreAndApps {
    Invoke-XaoExclusive {

    Invoke-XaoNative wsreset.exe @()
    $ok=0; $failed=0
    $packages = @(Get-AppxPackage -ErrorAction Stop | Where-Object { $_.InstallLocation })
    foreach ($package in $packages) {
        $manifest = Join-Path $package.InstallLocation 'AppXManifest.xml'
        if (-not (Test-Path -LiteralPath $manifest)) { continue }
        try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; $ok++ }
        catch { $failed++; Write-Log "$($package.Name): $($_.Exception.Message)" 'WARNING' }
    }
    Write-Log "Registro de aplicaciones del usuario: $ok correctas; $failed fallidas." $(if ($failed) {'WARNING'} else {'INFO'})
    Pause-Prompt

    }
}

function Repair-ExplorerAndIcons {
    Invoke-XaoExclusive {

    Get-Process -Name explorer -ErrorAction Stop | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } | Stop-Process -Force -ErrorAction Stop
    try {
        Start-Sleep -Seconds 1
        $cache = Join-Path $env:LOCALAPPDATA 'IconCache.db'
        if (Test-Path -LiteralPath $cache) { Remove-Item -LiteralPath $cache -Force -ErrorAction Stop }
        $folder = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'
        foreach ($filter in @('iconcache_*.db','thumbcache_*.db')) {
            Get-ChildItem -LiteralPath $folder -Filter $filter -File -ErrorAction Stop | Remove-Item -Force -ErrorAction Stop
        }
    } finally { Start-Process explorer.exe }
    Write-Log 'Cache de iconos eliminada y Explorador reiniciado.' 'SUCCESS'
    Pause-Prompt

    }
}

function Repair-PrintSpooler {
    if ((Read-Host 'Se eliminaran TODOS los trabajos pendientes de impresion. Continuar? (S/N)') -notmatch '^[sSyY]$') { return }
    Reset-XaoPrintQueue
    Write-Log 'Trabajos pendientes eliminados; estado del servicio restaurado.' 'SUCCESS'
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 2: REPARACION DE RED E INTERNET
# -------------------------------------------------------------
function Repair-NetworkStack {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Restablecimiento Completo de Red y Conectividad" -Type "HEADER"
    Write-Host " Soluciona caidas de conexion, 'Sin acceso a Internet', errores de DNS y cuellos de botella.`n" -ForegroundColor Gray

    Write-Log "Restableciendo catalogo Winsock (netsh winsock reset)..." -Type "INFO"
    Invoke-XaoNative -FilePath 'netsh' -ArgumentList @('winsock','reset') | Out-Null

    Write-Log "Restableciendo pila TCP/IP (netsh int ip reset)..." -Type "INFO"
    Invoke-XaoNative -FilePath 'netsh' -ArgumentList @('int','ip','reset') | Out-Null

    Write-Log "Vaciando cache de resolucion DNS (ipconfig /flushdns)..." -Type "INFO"
    Invoke-XaoNative -FilePath 'ipconfig' -ArgumentList @('/flushdns') | Out-Null

    Write-Log 'El restablecimiento de red requiere reiniciar. Se conserva la conexion actual hasta entonces.' 'INFO'

    Write-Host "`n Probando conectividad..." -ForegroundColor Cyan
    $pingGoogle = Test-Connection -ComputerName 8.8.8.8 -Count 2 -Quiet -ErrorAction SilentlyContinue
    if ($pingGoogle) {
        Write-Log "Prueba de conectividad a Internet (Google DNS 8.8.8.8): EXITOSA." -Type "SUCCESS"
    } else {
        Write-Log "Aviso: No hubo respuesta de ping a 8.8.8.8. Puede requerir reiniciar el router o la PC." -Type "WARNING"
    }

    Write-Log "Comandos de red finalizados. Reinicie y compruebe la conexion." -Type "INFO"
    Pause-Prompt

    }
}

# -------------------------------------------------------------
# MODULO 3: LIMPIEZA PROFUNDA SEGURA
# -------------------------------------------------------------
function Clean-JunkFiles {
    $result = Clear-XaoTemp
    Write-Log "Temporales antiguos eliminados: $($result.Removed); espacio recuperado: $([math]::Round($result.Bytes/1MB,2)) MB; omitidos por bloqueo/permisos/enlaces: $($result.Skipped)." 'INFO'
    if ((Read-Host 'Vaciar tambien la papelera? Esta accion elimina su contenido. (S/N)') -match '^[sSyY]$') {
        Clear-RecycleBin -Force -ErrorAction Stop
        Write-Log 'Papelera vaciada.' 'SUCCESS'
    }
    Pause-Prompt
}

function Clean-WinSxSStore {
    Clear-Host
    Write-Log "Saneamiento Profundo del Almacen de Componentes (WinSxS)" -Type "HEADER"
    Write-Host " Elimina actualizaciones antiguas reemplazadas de Windows para recuperar varios GBs." -ForegroundColor Gray
    
    $sxsEst = if ($sysInfo.DiskType -eq "SSD") { "~3 a 8 minutos (SSD)" } else { "~10 a 20 minutos (HDD)" }
    Invoke-ProcessWithTimer -Command "dism.exe" -Arguments "/Online /Cleanup-Image /StartComponentCleanup" -TaskName "Limpieza WinSxS" -EstimatedTime $sxsEst -ShowDismNotice
    Pause-Prompt
}

# -------------------------------------------------------------
# MODULO 4: OPTIMIZACION BASICA DEL SISTEMA
# -------------------------------------------------------------
function Optimize-BasicSystem {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Optimizacion Basica y Segura de Windows" -Type "HEADER"
    Write-Host " Estos ajustes cambian preferencias de Windows; su efecto depende del equipo.`n" -ForegroundColor Gray

    # 1. Deshabilitar GameDVR (grabacion de fondo continua)
    Write-Log "Desactivando Xbox GameDVR (grabacion continua en segundo plano)..." -Type "INFO"
    try {
        New-Item -Path "HKCU:\System\GameConfigStore" -Force -ErrorAction Stop | Out-Null
        Set-XaoRegistryValue -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord -Force
        New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Force -ErrorAction Stop | Out-Null
        Set-XaoRegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -Value 0 -Type DWord -Force
        Write-Log "GameDVR desactivado con exito." -Type "SUCCESS"
    } catch { Write-Log "No se pudo modificar GameDVR: $_" -Type "WARNING" }

    # 2. Deshabilitar Sugerencias y Publicidad del Menu Inicio
    Write-Log "Desactivando sugerencias publicitarias de Microsoft en el sistema..." -Type "INFO"
    try {
        $cdm = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
        if (Test-Path $cdm) {
            Set-XaoRegistryValue -Path $cdm -Name "SystemPaneSuggestionsEnabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path $cdm -Name "SubscribedContent-338388Enabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path $cdm -Name "SubscribedContent-338389Enabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Set-XaoRegistryValue -Path $cdm -Name "SoftLandingEnabled" -Value 0 -Type DWord -Force -ErrorAction Stop
            Write-Log "Publicidad y sugerencias del menu inicio desactivadas." -Type "SUCCESS"
        }
    } catch { Write-Log $_.Exception.Message "WARNING" }

    # 3. Minimizar telemetria y diagnosticos invasivos
    Write-Log "Ajustando nivel de telemetria al minimo permitido..." -Type "INFO"
    try {
        $dataCol = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
        New-Item -Path $dataCol -Force -ErrorAction Stop | Out-Null
        Set-XaoRegistryValue -Path $dataCol -Name "AllowTelemetry" -Value 1 -Type DWord -Force -ErrorAction Stop
        Write-Log "Telemetria limitada a datos de seguridad/basicos." -Type "SUCCESS"
    } catch { Write-Log $_.Exception.Message "WARNING" }

    # 4. Detener servicio DiagTrack (Experiencias del usuario y telemetria)
    Write-Log "Ajustando servicio DiagTrack..." -Type "INFO"
    try {
        Stop-Service -Name "DiagTrack" -Force -ErrorAction Stop
        Set-Service -Name "DiagTrack" -StartupType Manual -ErrorAction Stop
        Write-Log "Servicio DiagTrack configurado en Manual." -Type "SUCCESS"
    } catch { Write-Log $_.Exception.Message "WARNING" }

    # 5. Optimizar efectos visuales (manteniendo suavizado de fuentes)
    Write-Log "Ajustando efectos visuales para respuesta agil..." -Type "INFO"
    try {
        # Mantener fuentes suaves (ClearType) pero quitar animaciones lentas
        Set-XaoRegistryValue -Path "HKCU:\Control Panel\Desktop" -Name "UserPreferencesMask" -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -ErrorAction Stop
        Set-XaoRegistryValue -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name "MinAnimate" -Value "0" -ErrorAction Stop
        Write-Log "Efectos visuales optimizados (fuentes suaves preservadas)." -Type "SUCCESS"
    } catch { Write-Log $_.Exception.Message "WARNING" }

    Write-Log "Ajustes procesados. Revise los avisos de cada operacion." -Type "INFO"
    Pause-Prompt

    }
}

# -------------------------------------------------------------
# MODULO 5: ESPECIFICO PARA NOTEBOOKS / BATERIA Y ENERGIA
# -------------------------------------------------------------
function Manage-LaptopBattery {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Modulo de Energia y Salud de Bateria (Notebooks)" -Type "HEADER"

    $batt = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $batt) {
        Write-Log "No se detecto una bateria conectada a este equipo." -Type "WARNING"
        Write-Host " Si es una PC de escritorio, este modulo no aplica." -ForegroundColor Gray
        Pause-Prompt
        return
    }

    Write-Host " Informacion de la Bateria detectada:" -ForegroundColor Cyan
    Write-Host "  Nombre: $($batt.Name)" -ForegroundColor White
    Write-Host "  Estado de carga: $($batt.EstimatedChargeRemaining)%" -ForegroundColor Green
    $statusStr = switch ($batt.BatteryStatus) {
        1 { "Descargando" }
        2 { "Conectada a la corriente (Cargando)" }
        3 { "Completamente cargada" }
        default { "Estado desconocido ($($batt.BatteryStatus))" }
    }
    Write-Host "  Estado actual: $statusStr" -ForegroundColor White

    Write-Host "`n Opciones disponibles:" -ForegroundColor Yellow
    Write-Host "  1. Generar Reporte Completo de Bateria (powercfg /batteryreport)"
    Write-Host "  2. Prevenir suspension de Wi-Fi en bateria (evita cortes de conexion)"
    Write-Host "  3. Configurar Plan de Energia 'Equilibrado' (Recomendado para Notebooks)"
    Write-Host "  0. Volver al menu principal"

    $subChoice = Read-Host "`n Seleccione una opcion (0-3)"
    switch ($subChoice) {
        "1" {
            $reportPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "Reporte_Bateria_$($env:COMPUTERNAME).html"
            Write-Log "Generando reporte de bateria en $reportPath..." -Type "INFO"
            Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('/batteryreport','/output',$reportPath)
            if (Test-Path $reportPath) {
                Write-Log "Reporte generado con exito. Abriendo en el navegador..." -Type "SUCCESS"
                Start-Process $reportPath
            } else {
                Write-Log "No se pudo generar el reporte." -Type "ERROR"
            }
            Pause-Prompt
        }
        "2" {
            Write-Log "Configurando adaptadores Wi-Fi para maximo rendimiento (sin cortes de energia)..." -Type "INFO"
            try {
                Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('-setacvalueindex','SCHEME_CURRENT','19cbb8fa-5279-450e-9f18-979183604d00','12bbebe6-58d6-4636-95bb-3217ef867c1a',0)
                Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('-setdcvalueindex','SCHEME_CURRENT','19cbb8fa-5279-450e-9f18-979183604d00','12bbebe6-58d6-4636-95bb-3217ef867c1a',0)
                Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('-SetActive','SCHEME_CURRENT')
                Write-Log "Ajuste de energia Wi-Fi aplicado exitosamente (el resultado depende del controlador y del estado de suspension)." -Type "SUCCESS"
            } catch {
                Write-Log "No se pudo cambiar el ajuste de energia de red: $_" -Type "WARNING"
            }
            Pause-Prompt
        }
        "3" {
            Write-Log "Restaurando plan Equilibrado para evitar sobrecalentamiento..." -Type "INFO"
            Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('-setactive','381b4222-f694-41f0-9685-ff5bb260df2e')
            Write-Log "Plan Equilibrado activo." -Type "SUCCESS"
            Pause-Prompt
        }
    }

    }
}

function Manage-DesktopPower {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Modulo de Energia para PC de Escritorio" -Type "HEADER"
    Write-Host " 1. Activar Plan 'Alto Rendimiento' (High Performance)"
    Write-Host " 2. Activar Plan 'Rendimiento Maximo / Definitivo' (Ultimate Performance)"
    Write-Host " 0. Volver"

    $pChoice = Read-Host "`n Seleccione una opcion (0-2)"
    switch ($pChoice) {
        "1" {
            Write-Log "Activando plan Alto Rendimiento..." -Type "INFO"
            Invoke-XaoNative -FilePath 'powercfg' -ArgumentList @('-setactive','8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c')
            Write-Log "Plan Alto Rendimiento activado." -Type "SUCCESS"
            Pause-Prompt
        }
        "2" {
            Write-Log "Desbloqueando plan Rendimiento Maximo (Ultimate Performance)..." -Type "INFO"
            Enable-XaoUltimatePower
            Write-Log "Plan Rendimiento Maximo activado y verificado." -Type "SUCCESS"
            Pause-Prompt
        }
    }

    }
}

# -------------------------------------------------------------
# MODULO 6: DIAGNOSTICO DE DISCO Y ALMACENAMIENTO
# -------------------------------------------------------------
function Diagnose-Disks {
    Invoke-XaoExclusive {

    Clear-Host
    Write-Log "Diagnostico de Discos y Almacenamiento" -Type "HEADER"

    Write-Host " Discos Fisicos y Estado de Salud informado por Windows:" -ForegroundColor Cyan
    try {
        $pDisks = Get-PhysicalDisk
        foreach ($d in $pDisks) {
            $hColor = if ($d.HealthStatus -eq "Healthy") { "Green" } else { "Red" }
            Write-Host "  Disco #$($d.DeviceId): $($d.FriendlyName) | Tipo: $($d.MediaType) | Salud: " -NoNewline
            Write-Host "$($d.HealthStatus)" -ForegroundColor $hColor -NoNewline
            Write-Host " | Tamano: $([math]::Round($d.Size / 1GB, 1)) GB"
        }
    } catch {
        Write-Log "No se pudo obtener datos con Get-PhysicalDisk: $_" -Type "WARNING"
    }

    Write-Host "`n Opciones:" -ForegroundColor Yellow
    Write-Host "  1. Ejecutar escaneo CHKDSK en unidad $env:SystemDrive (analisis en linea; revise la salida)"
    Write-Host "  2. Programar reparacion completa de disco para el proximo reinicio (chkdsk /f)"
    Write-Host " Un estado Healthy no garantiza la ausencia de fallos fisicos." -ForegroundColor Gray
    Write-Host "  3. Enviar comando TRIM a unidades SSD (Optimize-Volume)"
    Write-Host "  0. Volver"

    $dChoice = Read-Host "`n Seleccione una opcion (0-3)"
    switch ($dChoice) {
        "1" {
            Write-Log "Iniciando chkdsk $env:SystemDrive /scan..." -Type "INFO"
            Invoke-XaoNative -FilePath 'chkdsk' -ArgumentList @($env:SystemDrive,'/scan')
            Write-Log "Escaneo de disco completado." -Type "SUCCESS"
            Pause-Prompt
        }
        "2" {
            Write-Log "Programando chkdsk $env:SystemDrive /f..." -Type "INFO"
            Write-Host " Ingrese 'S' si Windows le pregunta si desea desmontar o programar para el reinicio:" -ForegroundColor Yellow
            Invoke-XaoNative -FilePath 'chkdsk' -ArgumentList @($env:SystemDrive,'/f')
            Pause-Prompt
        }
        "3" {
            Write-Log "Ejecutando TRIM en unidades SSD detectadas..." -Type "INFO"
            try {
                $disk=Get-XaoSystemDisk
                if($disk.MediaType -ne 'SSD'){throw 'No se confirmo que el disco del sistema sea SSD; no se enviara TRIM.'}
                Optimize-Volume -DriveLetter ($env:SystemDrive.TrimEnd(':')) -ReTrim -Verbose -ErrorAction Stop
                Write-Log "TRIM enviado a la unidad $env:SystemDrive exitosamente." -Type "SUCCESS"
            } catch {
                Write-Log "Error al ejecutar TRIM: $_" -Type "WARNING"
            }
            Pause-Prompt
        }
    }

    }
}

# -------------------------------------------------------------
# MODULO 7: MANTENIMIENTO TOTAL (1-CLIC)
# -------------------------------------------------------------
function Run-OneClickMaintenance {
    Invoke-XaoExclusive {

    Write-Log 'Mantenimiento: temporales de mas de 7 dias, DNS, DISM y SFC.' 'HEADER'
    if ((Read-Host 'Iniciar mantenimiento? (S/N)') -notmatch '^[sSyY]$') { return }
    $result = Clear-XaoTemp
    Write-Log "Limpieza: $($result.Removed) archivos; $($result.Skipped) omitidos; $([math]::Round($result.Bytes/1MB,2)) MB recuperados." 'INFO'
    Invoke-XaoNative ipconfig.exe @('/flushdns')
    Invoke-ProcessWithTimer -Command 'dism.exe' -Arguments '/Online /Cleanup-Image /RestoreHealth /NoRestart' -TaskName 'DISM' -EstimatedTime 'varios minutos'
    Invoke-ProcessWithTimer -Command 'sfc.exe' -Arguments '/scannow' -TaskName 'SFC' -EstimatedTime 'varios minutos'
    Write-Log 'Comandos de mantenimiento finalizados. Revise el resultado de SFC y los avisos; no todos los problemas requieren estas reparaciones.' 'INFO'
    Pause-Prompt

    }
}

# -------------------------------------------------------------
# MODULO 8: ACCESOS RAPIDOS A HERRAMIENTAS DE WINDOWS
# -------------------------------------------------------------
function Show-QuickTools {
    Clear-Host
    Write-Log "Herramientas Tecnicas Nativas de Windows" -Type "HEADER"
    Write-Host "  1. Administrador de Dispositivos (devmgmt.msc)"
    Write-Host "  2. Administrador de Tareas (taskmgr.exe)"
    Write-Host "  3. Conexiones de Red (ncpa.cpl)"
    Write-Host "  4. Servicios de Windows (services.msc)"
    Write-Host "  5. Visor de Eventos (eventvwr.msc)"
    Write-Host "  6. Editor del Registro (regedit.exe)"
    Write-Host "  7. Configuracion del Sistema / Modo Seguro (msconfig.exe)"
    Write-Host "  8. Informacion del Sistema (msinfo32.exe)"
    Write-Host "  0. Volver"

    $t = Read-Host "`n Seleccione una herramienta para abrir (0-8)"
    switch ($t) {
        "1" { Start-Process "devmgmt.msc" }
        "2" { Start-Process "taskmgr.exe" }
        "3" { Start-Process "ncpa.cpl" }
        "4" { Start-Process "services.msc" }
        "5" { Start-Process "eventvwr.msc" }
        "6" { Start-Process "regedit.exe" }
        "7" { Start-Process "msconfig.exe" }
        "8" { Start-Process "msinfo32.exe" }
    }
}

function Pause-Prompt {
    Write-Host "`n Presione [ENTER] para continuar..." -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}

# -------------------------------------------------------------
# BUCLE PRINCIPAL DEL MENU
# -------------------------------------------------------------
function Show-MainMenu {
    param($sys)

    Clear-Host
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host "                        XAO PROBLEMS - REPARACION & OPTIMIZACION                " -ForegroundColor Yellow
    Write-Host "                                   Xaoxay Labs                                  " -ForegroundColor DarkCyan
    Write-Host "================================================================================" -ForegroundColor Cyan
    
    # Informacion del Sistema
    $formFactor = if ($sys.IsLaptop) { "NOTEBOOK / LAPTOP" } else { "PC DE ESCRITORIO" }
    $ffColor = if ($sys.IsLaptop) { "Magenta" } else { "Green" }

    Write-Host " Equipo: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.ComputerName) " -NoNewline -ForegroundColor White
    Write-Host "[$formFactor]" -ForegroundColor $ffColor

    Write-Host " Sistema: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.OSName) (Build $($sys.OSBuild))" -ForegroundColor White

    Write-Host " CPU: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.CPU)" -ForegroundColor White

    Write-Host " Memoria RAM: " -NoNewline -ForegroundColor Gray
    Write-Host "$($sys.TotalRAM) GB (Disponible: $($sys.FreeRAM) GB) | Disco $($sys.Drive) ($($sys.DiskType)): $($sys.FreeDiskGB) GB libres de $($sys.TotalDiskGB) GB" -ForegroundColor White
    Write-Host "================================================================================" -ForegroundColor Cyan

    Write-Host " [1] Reparaciones Criticas de Windows (SFC, DISM, WinUpdate, Tienda, Iconos)" -ForegroundColor White
    Write-Host " [2] Reparacion de Red e Internet (Winsock, TCP/IP, Flush DNS, Adaptadores)" -ForegroundColor White
    Write-Host " [3] Limpieza y Liberacion de Espacio (Temporales, Prefetch, Papelera, WinSxS)" -ForegroundColor White
    Write-Host " [4] Optimizacion Basica del Sistema (Servicios, Telemetria, GameDVR, Efectos)" -ForegroundColor White

    if ($sys.IsLaptop) {
        Write-Host " [5] Modulo Notebook: Reporte y Salud de Bateria, Wi-Fi y Energia" -ForegroundColor Yellow
    } else {
        Write-Host " [5] Modulo Escritorio: Planes de Energia (Alto / Maximo Rendimiento)" -ForegroundColor Yellow
    }

    Write-Host " [6] Diagnostico de Almacenamiento (Salud SMART, CHKDSK, TRIM SSD)" -ForegroundColor White
    Write-Host " [7] MANTENIMIENTO TOTAL (1-CLIC) -> Diagnostico + Limpieza + Reparacion" -ForegroundColor Green
    Write-Host " [8] Accesos Rapidos a Herramientas de Windows (Dispositivos, Red, Servicios)" -ForegroundColor White
    Write-Host " [9] Abrir Carpeta de Logs de XaoProblems" -ForegroundColor DarkGray
    Write-Host " [0] Salir" -ForegroundColor Red
    Write-Host "================================================================================" -ForegroundColor Cyan
}

# Inicio del programa
Ensure-AdminPrivileges
Disable-ConsoleQuickEdit
$sysInfo = Get-SystemInfo
Write-Log "Iniciando Xao Problems en $($sysInfo.ComputerName) ($($sysInfo.OSName))" -Type "INFO"

do {
    Show-MainMenu -sys $sysInfo
    $op = Read-Host " Ingrese una opcion (0-9)"

    try {
    switch ($op) {
        "0" { }
        default { Write-Log "Opcion no valida." "WARNING"; Start-Sleep -Milliseconds 500 }
        "1" {
            Clear-Host
            Write-Host "--- REPARACIONES CRITICAS DE WINDOWS ---" -ForegroundColor Cyan
            Write-Host " 1. Ejecutar DISM + SFC (Reparacion completa de archivos de sistema)"
            Write-Host " 2. Reparar Windows Update (Purgar cache y reiniciar servicios)"
            Write-Host " 3. Reparar Microsoft Store y Apps nativas (wsreset)"
            Write-Host " 4. Reparar Explorador de Archivos y Cache de Iconos/Miniaturas"
            Write-Host " 5. Desatascar Cola de Impresion"
            Write-Host " 0. Volver"
            $sub = Read-Host "`n Seleccione (0-5)"
            switch ($sub) {
                "1" { Repair-WindowsFiles }
                "2" { Repair-WindowsUpdate }
                "3" { Repair-StoreAndApps }
                "4" { Repair-ExplorerAndIcons }
                "5" { Repair-PrintSpooler }
            }
        }
        "2" { Repair-NetworkStack }
        "3" {
            Clear-Host
            Write-Host "--- LIMPIEZA Y LIBERACION DE ESPACIO ---" -ForegroundColor Cyan
            Write-Host " 1. Limpieza de Temporales, Papelera, Crashes y Prefetch"
            Write-Host " 2. Limpieza Profunda de WinSxS (Actualizaciones antiguas de Windows)"
            Write-Host " 0. Volver"
            $sub = Read-Host "`n Seleccione (0-2)"
            switch ($sub) {
                "1" { Clean-JunkFiles }
                "2" { Clean-WinSxSStore }
            }
        }
        "4" { Optimize-BasicSystem }
        "5" {
            if ($sysInfo.IsLaptop) {
                Manage-LaptopBattery
            } else {
                Manage-DesktopPower
            }
        }
        "6" { Diagnose-Disks }
        "7" { Run-OneClickMaintenance }
        "8" { Show-QuickTools }
        "9" {
            if (Test-Path $LogFile) {
                Start-Process "notepad.exe" -ArgumentList $LogFile
            } else {
                Write-Host " Aun no se ha generado ningun log." -ForegroundColor Yellow
                Pause-Prompt
            }
        }
    }
    } catch { Write-Log $_.Exception.Message "ERROR"; Pause-Prompt }
} while ($op -ne "0")

Write-Host "`n Gracias por utilizar Xao Problems. Saliendo..." -ForegroundColor Green
Start-Sleep -Seconds 1
